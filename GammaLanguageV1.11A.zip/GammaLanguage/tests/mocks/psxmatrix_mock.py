"""PSXMatrix Mock Interop Layer — Hardware-free software mock for CI/CD.

Allows developers to test MIPS assembly patches and VRAM DMA signals
without needing DuckStation or physical consoles.
"""

import struct
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class HWIntChannel(IntEnum):
    NONE = 0x00
    VBLANK = 0x01
    DMA_CH1 = 0x02
    AUDIO_SWAP = 0x03
    RENDER_DONE = 0x04


@dataclass
class PSXHwRegMap:
    dma_ch1_madr: int = 0x1F8010A0
    dma_ch1_bcr: int = 0x1F8010A4
    dma_ch1_chcr: int = 0x1F8010A8
    dma_ch2_madr: int = 0x1F8010B0
    dma_ch2_bcr: int = 0x1F8010B4
    dma_ch2_chcr: int = 0x1F8010B8
    gpu_gp0: int = 0x1F801810
    gpu_gp1: int = 0x1F801814
    i_stat: int = 0x1F801070
    i_mask: int = 0x1F801074


@dataclass
class VRAMRegion:
    base_addr: int
    size: int
    data: bytearray = field(default_factory=lambda: bytearray(0))


class PSXMatrixMock:
    """Mock PSX hardware interop layer for CI/CD testing."""

    def __init__(self):
        self.regs = PSXHwRegMap()
        self.vram = VRAMRegion(base_addr=0, size=1024 * 1024)  # 1MB VRAM
        self.ram = bytearray(2 * 1024 * 1024)  # 2MB main RAM
        self.frame_count = 0
        self.interrupt_log: list[tuple[HWIntChannel, int]] = []
        self.dma_log: list[dict] = []
        self._interrupt_enabled = True

    def dispatch_dma(self, channel: int, madr: int, bcr: int) -> dict:
        """Simulate a DMA channel transfer."""
        entry = {
            "channel": channel,
            "madr": madr,
            "bcr": bcr,
            "frame": self.frame_count,
            "status": "completed",
        }
        self.dma_log.append(entry)

        if channel == 1:  # CD-ROM DMA
            self.regs.dma_ch1_madr = madr
            self.regs.dma_ch1_bcr = bcr
        elif channel == 2:  # GPU DMA
            self.regs.dma_ch2_madr = madr
            self.regs.dma_ch2_bcr = bcr
            # Simulate VRAM write
            transfer_size = (bcr >> 16) * (bcr & 0xFFFF) * 4
            if transfer_size > 0 and transfer_size < len(self.vram.data):
                self.vram.data[:transfer_size] = self.ram[madr:madr + transfer_size]

        return entry

    def trigger_interrupt(self, channel: HWIntChannel):
        """Simulate a hardware interrupt."""
        if not self._interrupt_enabled:
            return
        self.interrupt_log.append((channel, self.frame_count))
        if channel == HWIntChannel.VBLANK:
            self.frame_count += 1

    def read_gpu_gp0(self) -> int:
        """Simulate GPU GP0 read."""
        return 0x00000000  # Idle

    def write_gpu_gp0(self, value: int):
        """Simulate GPU GP0 command write."""
        cmd = (value >> 24) & 0xFF
        if cmd == 0x02:  # Fill rectangle in VRAM
            pass
        elif cmd == 0xA0:  # Copy rectangle to VRAM
            pass

    def read_cp0(self, reg: int) -> int:
        """Simulate CP0 register read."""
        cp0_regs = [0, 0, 0, 0, 0, 0, 0, 0,
                    0x00000000,  # BadVAddr
                    self.frame_count * 1000,  # Count
                    0,  # EntryHi
                    0,  # Compare
                    0x00000000,  # Status
                    0x00000000,  # Cause
                    0x00000000,  # EPC
                    0]  # PRId
        if 0 <= reg < 32:
            return cp0_regs[reg]
        return 0

    def get_stats(self) -> dict:
        """Get mock statistics."""
        return {
            "frame_count": self.frame_count,
            "interrupts": len(self.interrupt_log),
            "dma_transfers": len(self.dma_log),
            "vram_used": len(self.vram.data),
            "ram_size": len(self.ram),
        }

    def reset(self):
        """Reset mock state."""
        self.frame_count = 0
        self.interrupt_log.clear()
        self.dma_log.clear()
        self.vram.data = bytearray(self.vram.size)
        self.ram = bytearray(2 * 1024 * 1024)
