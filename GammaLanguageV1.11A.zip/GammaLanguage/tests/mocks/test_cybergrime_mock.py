"""Tests for CyberGrime mock MIPS assembler."""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from cybergrime_mock import CyberGrimeMock


def test_basic_assembly():
    mock = CyberGrimeMock()
    source = """
    lui $t0, 0x1F80
    addiu $t0, $t0, 0x10A0
    sw $a0, 0($t0)
    nop
    """
    instrs = mock.assemble(source)
    assert len(instrs) == 4
    assert instrs[0].mnemonic == "lui"
    assert instrs[1].mnemonic == "addiu"
    assert instrs[2].mnemonic == "sw"
    assert instrs[3].mnemonic == "nop"
    print("  [PASS] test_basic_assembly")


def test_gamma_directives():
    mock = CyberGrimeMock()
    source = """
    .mips_cp0_map Status HW[0]
    .mips_cp0_map Cause HW[1]
    .gamma_rust_offset DMA_CH1_MADR 0x1F8010A0 REPR_C VOLATILE
    .gamma_peak_sync VBLANK frame_callback
    """
    instrs = mock.assemble(source)
    assert len(instrs) == 4
    assert instrs[0].gamma_directive == "CP0_REG_MAP"
    assert instrs[1].gamma_directive == "CP0_REG_MAP"
    assert instrs[2].gamma_directive == "RUST_OFFSET_LOAD"
    assert instrs[3].gamma_directive == "RUST_FFI_CALL"
    print("  [PASS] test_gamma_directives")


def test_bytecode_emission():
    mock = CyberGrimeMock()
    source = """
    .gamma_emit_bytecode
    lui $t0, 0x1F80
    addiu $t0, $t0, 0x10A0
    sw $a0, 0($t0)
    .gamma_end_bytecode
    """
    mock.assemble(source)
    bytecode = mock.get_bytecode()
    assert len(bytecode) == 3  # 3 MIPS instructions emitted as bytecode
    print("  [PASS] test_bytecode_emission")


def test_cp0_inspection():
    mock = CyberGrimeMock()
    source = """
    .mips_cp0_map Status HW[0]
    .mips_cp0_map EPC HW[2]
    """
    mock.assemble(source)
    cp0 = mock.inspect_cp0()
    assert hasattr(cp0, "status")
    assert hasattr(cp0, "epc")
    print("  [PASS] test_cp0_inspection")


def test_stats():
    mock = CyberGrimeMock()
    source = """
    .mips_cp0_map Status HW[0]
    lui $t0, 0x1F80
    nop
    """
    mock.assemble(source)
    stats = mock.get_stats()
    assert stats["instruction_count"] == 3
    assert stats["gamma_directives"] == 1
    print("  [PASS] test_stats")


if __name__ == "__main__":
    test_basic_assembly()
    test_gamma_directives()
    test_bytecode_emission()
    test_cp0_inspection()
    test_stats()
    print("\nAll CyberGrime mock tests passed!")
