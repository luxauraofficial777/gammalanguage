"""CyberGrime Mock MIPS Assembler — Hardware-free software mock for CI/CD.

Allows developers to test MIPS assembly patches and CP0 register inspection
without needing DuckStation or physical consoles.
"""

import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class MIPSInstruction:
    address: int
    mnemonic: str
    operands: list[str] = field(default_factory=list)
    raw_bytes: bytes = b""
    gamma_directive: Optional[str] = None


@dataclass
class CP0RegisterSet:
    status: int = 0
    cause: int = 0
    epc: int = 0
    bad_vaddr: int = 0
    count: int = 0
    compare: int = 0
    entry_hi: int = 0
    index: int = 0


class CyberGrimeMock:
    """Mock CyberGrime MIPS assembler with GammaLanguage directive support."""

    # Supported MIPS instructions (simplified encoding)
    MIPS_INSTRUCTIONS = {
        "lui": {"format": "I", "opcode": 0x0F},
        "addiu": {"format": "I", "opcode": 0x09},
        "lw": {"format": "I", "opcode": 0x23},
        "sw": {"format": "I", "opcode": 0x2B},
        "jal": {"format": "J", "opcode": 0x03},
        "jr": {"format": "R", "opcode": 0x00, "funct": 0x08},
        "nop": {"format": "R", "opcode": 0x00, "funct": 0x00},
        "andi": {"format": "I", "opcode": 0x0C},
        "ori": {"format": "I", "opcode": 0x0D},
        "j": {"format": "J", "opcode": 0x02},
    }

    # GammaLanguage assembler directives
    GAMMA_DIRECTIVES = {
        ".gamma_rust_offset": "RUST_OFFSET_LOAD",
        ".gamma_peak_sync": "RUST_FFI_CALL",
        ".mips_cp0_map": "CP0_REG_MAP",
        ".gamma_emit_bytecode": "BYTECODE_EMIT",
        ".gamma_end_bytecode": "BYTECODE_END",
    }

    def __init__(self):
        self.instructions: list[MIPSInstruction] = []
        self.cp0 = CP0RegisterSet()
        self.bytecode_output: list[int] = []
        self.base_address = 0x80010000
        self._in_bytecode_block = False

    def assemble(self, source: str) -> list[MIPSInstruction]:
        """Assemble MIPS assembly source with GammaLanguage directives."""
        lines = source.strip().split("\n")
        addr = self.base_address

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            # Check for GammaLanguage directives
            directive_match = None
            for directive, opcode_name in self.GAMMA_DIRECTIVES.items():
                if line.startswith(directive):
                    directive_match = (directive, opcode_name)
                    break

            if directive_match:
                directive, opcode_name = directive_match
                instr = MIPSInstruction(
                    address=addr,
                    mnemonic=directive,
                    operands=self._parse_operands(line[len(directive):]),
                    gamma_directive=opcode_name,
                )
                self.instructions.append(instr)

                if directive == ".gamma_emit_bytecode":
                    self._in_bytecode_block = True
                elif directive == ".gamma_end_bytecode":
                    self._in_bytecode_block = False
                elif directive == ".mips_cp0_map":
                    self._handle_cp0_map(instr.operands)
                elif directive == ".gamma_rust_offset":
                    self._handle_rust_offset(instr.operands)

                addr += 4
                continue

            # Parse MIPS instruction
            parts = re.split(r"[,\s]+", line, maxsplit=1)
            mnemonic = parts[0].lower()
            operands = self._parse_operands(parts[1]) if len(parts) > 1 else []

            if mnemonic in self.MIPS_INSTRUCTIONS:
                raw = self._encode_instruction(mnemonic, operands)
                instr = MIPSInstruction(
                    address=addr,
                    mnemonic=mnemonic,
                    operands=operands,
                    raw_bytes=raw,
                )
                self.instructions.append(instr)

                if self._in_bytecode_block:
                    # Emit as A2A-B bytecode
                    packed = int.from_bytes(raw, "big")
                    self.bytecode_output.append(packed)

                addr += 4

        return self.instructions

    def _parse_operands(self, text: str) -> list[str]:
        """Parse instruction operands."""
        text = text.strip()
        if not text:
            return []
        return [op.strip() for op in re.split(r"[,\s]+", text) if op.strip()]

    def _encode_instruction(self, mnemonic: str, operands: list[str]) -> bytes:
        """Encode a MIPS instruction to bytes (simplified)."""
        info = self.MIPS_INSTRUCTIONS[mnemonic]
        opcode = info["opcode"]

        if mnemonic == "nop":
            return b"\x00\x00\x00\x00"
        elif info["format"] == "I":
            rt = self._parse_register(operands[0]) if operands else 0
            imm = self._parse_immediate(operands[-1]) if operands else 0
            rs = self._parse_register(operands[1]) if len(operands) > 1 else 0
            packed = (opcode << 26) | (rs << 21) | (rt << 16) | (imm & 0xFFFF)
            return struct.pack(">I", packed)
        elif info["format"] == "J":
            target = self._parse_immediate(operands[0]) if operands else 0
            packed = (opcode << 26) | ((target >> 2) & 0x3FFFFFF)
            return struct.pack(">I", packed)
        elif info["format"] == "R":
            if mnemonic == "jr":
                rs = self._parse_register(operands[0]) if operands else 0
                packed = (opcode << 26) | (rs << 21) | (info["funct"])
                return struct.pack(">I", packed)

        return b"\x00\x00\x00\x00"

    def _parse_register(self, text: str) -> int:
        """Parse MIPS register name to number."""
        reg_map = {
            "$zero": 0, "$at": 1, "$v0": 2, "$v1": 3,
            "$a0": 4, "$a1": 5, "$a2": 6, "$a3": 7,
            "$t0": 8, "$t1": 9, "$t2": 10, "$t3": 11,
            "$t4": 12, "$t5": 13, "$t6": 14, "$t7": 15,
            "$s0": 16, "$s1": 17, "$s2": 18, "$s3": 19,
            "$sp": 29, "$fp": 30, "$ra": 31,
        }
        text = text.strip()
        if text in reg_map:
            return reg_map[text]
        if text.startswith("$") and text[1:].isdigit():
            return int(text[1:])
        return 0

    def _parse_immediate(self, text: str) -> int:
        """Parse immediate value (hex or decimal)."""
        text = text.strip()
        if text.startswith("0x") or text.startswith("0X"):
            return int(text, 16)
        try:
            return int(text)
        except ValueError:
            return 0

    def _handle_cp0_map(self, operands: list[str]):
        """Handle .mips_cp0_map directive."""
        if len(operands) >= 2:
            reg_name = operands[0]
            hw_slot = operands[1]
            # Map CP0 register to HW bank
            cp0_map = {
                "Status": "cp0_status",
                "Cause": "cp0_cause",
                "EPC": "cp0_epc",
                "BadVAddr": "cp0_bad_vaddr",
                "Count": "cp0_count",
                "Compare": "cp0_compare",
            }
            if reg_name in cp0_map:
                setattr(self.cp0, cp0_map[reg_name], 0)

    def _handle_rust_offset(self, operands: list[str]):
        """Handle .gamma_rust_offset directive."""
        # Store as bytecode output
        if len(operands) >= 2:
            self.bytecode_output.append(0xA0 << 24)  # RUST_OFFSET_LOAD opcode

    def inspect_cp0(self) -> CP0RegisterSet:
        """Inspect CP0 register state."""
        return self.cp0

    def get_bytecode(self) -> list[int]:
        """Get emitted A2A-B bytecode array."""
        return self.bytecode_output

    def get_stats(self) -> dict:
        return {
            "instruction_count": len(self.instructions),
            "bytecode_count": len(self.bytecode_output),
            "gamma_directives": sum(1 for i in self.instructions if i.gamma_directive),
        }


import struct
