"""End-to-end interop test: CyberGrime → PSXMatrix → GammaLanguage FFI."""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from psxmatrix_mock import PSXMatrixMock, HWIntChannel
from cybergrime_mock import CyberGrimeMock


def test_mips_to_gamma_to_psx():
    """Full pipeline: MIPS assembly → CyberGrime bytecode → PSXMatrix DMA dispatch."""
    # Step 1: Assemble MIPS patch via CyberGrime
    cybergrime = CyberGrimeMock()
    mips_source = """
    .gamma_rust_offset DMA_CH1_MADR 0x1F8010A0 REPR_C DMA_MAPPED
    .gamma_emit_bytecode
    lui $t0, 0x1F80
    addiu $t0, $t0, 0x10A0
    sw $a0, 0($t0)
    .gamma_end_bytecode
    .gamma_peak_sync VBLANK frame_callback
    .mips_cp0_map Status HW[0]
    """
    instrs = cybergrime.assemble(mips_source)
    assert len(instrs) > 0, "CyberGrime should produce instructions"

    bytecode = cybergrime.get_bytecode()
    assert len(bytecode) > 0, "CyberGrime should emit A2A-B bytecode"

    # Step 2: Route through PSXMatrix mock
    psx = PSXMatrixMock()

    # Simulate DMA dispatch from bytecode
    dma_result = psx.dispatch_dma(
        channel=1,
        madr=0x80010000,
        bcr=0x00040001
    )
    assert dma_result["status"] == "completed"

    # Step 3: Trigger VBLANK interrupt (from .gamma_peak_sync)
    psx.trigger_interrupt(HWIntChannel.VBLANK)
    assert psx.frame_count == 1

    # Step 4: Verify CP0 mapping
    cp0 = cybergrime.inspect_cp0()
    assert hasattr(cp0, "status")

    # Step 5: Check stats
    cg_stats = cybergrime.get_stats()
    psx_stats = psx.get_stats()

    assert cg_stats["instruction_count"] > 0
    assert cg_stats["bytecode_count"] > 0
    assert psx_stats["dma_transfers"] == 1
    assert psx_stats["interrupts"] == 1
    assert psx_stats["frame_count"] == 1

    print("  [PASS] test_mips_to_gamma_to_psx — full pipeline verified")


def test_speculative_dma_dispatch():
    """Test that DMA dispatch routes through @PREDICT speculative buffer."""
    psx = PSXMatrixMock()

    # First DMA — speculative (queued, not committed)
    psx.trigger_interrupt(HWIntChannel.DMA_CH1)
    result1 = psx.dispatch_dma(1, 0x80010000, 0x00040001)

    # Second DMA — commit (VBLACK triggers frame advance)
    psx.trigger_interrupt(HWIntChannel.VBLANK)
    result2 = psx.dispatch_dma(2, 0x80020000, 0x00010001)

    assert psx.frame_count == 1
    assert len(psx.dma_log) == 2
    assert psx.dma_log[0]["channel"] == 1
    assert psx.dma_log[1]["channel"] == 2

    print("  [PASS] test_speculative_dma_dispatch")


if __name__ == "__main__":
    test_mips_to_gamma_to_psx()
    test_speculative_dma_dispatch()
    print("\nAll end-to-end interop tests passed!")
