"""Tests for PSXMatrix mock interop layer."""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from psxmatrix_mock import PSXMatrixMock, HWIntChannel


def test_dma_dispatch():
    mock = PSXMatrixMock()
    result = mock.dispatch_dma(channel=1, madr=0x80010000, bcr=0x00040001)
    assert result["status"] == "completed"
    assert result["channel"] == 1
    assert mock.regs.dma_ch1_madr == 0x80010000
    print("  [PASS] test_dma_dispatch")


def test_interrupt():
    mock = PSXMatrixMock()
    mock.trigger_interrupt(HWIntChannel.VBLANK)
    mock.trigger_interrupt(HWIntChannel.DMA_CH1)
    assert mock.frame_count == 1
    assert len(mock.interrupt_log) == 2
    print("  [PASS] test_interrupt")


def test_gpu_write():
    mock = PSXMatrixMock()
    mock.write_gpu_gp0(0x02000000)  # Fill rectangle command
    assert mock.read_gpu_gp0() == 0x00000000
    print("  [PASS] test_gpu_write")


def test_cp0_read():
    mock = PSXMatrixMock()
    mock.frame_count = 10
    count = mock.read_cp0(9)  # CP0 Count
    assert count == 10000
    print("  [PASS] test_cp0_read")


def test_reset():
    mock = PSXMatrixMock()
    mock.trigger_interrupt(HWIntChannel.VBLANK)
    mock.dispatch_dma(1, 0x80010000, 0x00040001)
    mock.reset()
    assert mock.frame_count == 0
    assert len(mock.interrupt_log) == 0
    assert len(mock.dma_log) == 0
    print("  [PASS] test_reset")


def test_stats():
    mock = PSXMatrixMock()
    mock.trigger_interrupt(HWIntChannel.VBLANK)
    mock.dispatch_dma(2, 0x80020000, 0x00010001)
    stats = mock.get_stats()
    assert stats["frame_count"] == 1
    assert stats["dma_transfers"] == 1
    print("  [PASS] test_stats")


if __name__ == "__main__":
    test_dma_dispatch()
    test_interrupt()
    test_gpu_write()
    test_cp0_read()
    test_reset()
    test_stats()
    print("\nAll PSXMatrix mock tests passed!")
