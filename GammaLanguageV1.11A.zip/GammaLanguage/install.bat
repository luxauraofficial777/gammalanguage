@echo off
title Gamma Language (v1.0) Installer
echo ==========================================================================
echo          Gamma Language (Gamma-DSL v1.0) Installer
echo ==========================================================================

powershell -ExecutionPolicy Bypass -File "%~dp0install.ps1"

pause
