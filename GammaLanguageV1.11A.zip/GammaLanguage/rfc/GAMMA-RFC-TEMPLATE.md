# GAMMA-RFC-XXX: [Title]

## Status
- **Proposed** | **Accepted** | **Rejected** | **Implemented** | **Deprecated**
- **Proposed Date:** YYYY-MM-DD
- **Author:** [Name]
- **Reviewer:** [Name]

## Summary
One paragraph explanation of the proposed change.

## Motivation
Why is this change needed? What problem does it solve?

## Detailed Design

### Opcode / Register Bank / Sigil Definition
```
[Exact specification of the new opcode, register bank, or sigil]
```

### Bytecode Encoding
```
[32-bit A2A-B instruction encoding if applicable]
[31:28] Flag | [27:24] ReprType | [23:0] OffsetAddr
```

### Grammar Extension (EBNF)
```
[EBNF production rules]
```

### C++ Struct Changes
```cpp
[Changes to A2AST.h, A2AEvaluator.h, A2ALexer.h]
```

### Rust FFI Impact
```rust
[Changes to gamma_ffi.rs if applicable]
```

## Backwards Compatibility
Does this change break existing .gamma scripts? If so, what migration path is provided?

## Test Plan
- [ ] Unit test: [description]
- [ ] Integration test: [description]
- [ ] Benchmark: [metric to track]
- [ ] Mock interop test: [description]

## Performance Impact
- AST parsing latency: [estimated impact]
- Token reduction ratio: [estimated impact]
- SIMD throughput: [estimated impact]

## Alternatives Considered
What other approaches were considered and why were they rejected?

## References
- [Links to relevant documentation, issues, or discussions]
