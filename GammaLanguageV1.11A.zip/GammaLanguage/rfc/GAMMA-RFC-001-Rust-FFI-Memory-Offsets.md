# GAMMA-RFC-001: Rust FFI Memory Offset Flags & Zero-Copy Bindings

## Status
- **Implemented**
- **Proposed Date:** 2026-08-09
- **Author:** Lux Aura
- **Version:** GammaLanguage v1.1C

## Summary
Introduces `RustOffsetFlags` bitfield encoding in A2A-B bytecode, `repr(C)`/`repr(packed)` memory layout parity between C++ VM and Rust crates, and `&RUST_OFFSET` / `@ALIGN_BOUND` sigil grammar for zero-copy FFI access.

## Motivation
The existing v1.1A-Robust+ bytecode format has no mechanism for expressing Rust struct memory offsets or alignment constraints. This prevents zero-copy data passing between the C++ VM (`A2AEvaluator.h`) and external Rust crates, forcing serialization overhead on every FFI call.

## Detailed Design

### Bitfield Layout
```
RustOffsetFlags (32-bit):
  [31:28] Flag (4 bits)       — RustOffsetFlag enum
  [27:24] ReprType (4 bits)   — RustReprType enum
  [23:0]  OffsetAddr (24 bits) — Byte offset within struct
```

### New Opcodes
| Opcode | Hex | Description |
|--------|-----|-------------|
| RUST_OFFSET_LOAD | 0xA0 | Load struct offset pointer into HW register |
| RUST_FFI_CALL | 0xA1 | Invoke PEAK subsystem via dispatch table |
| ALIGN_BOUND | 0xA2 | Enforce memory alignment boundary |
| CP0_REG_MAP | 0xA3 | CyberGrime CP0 register → HW[0..7] mapping |
| PSX_DMA_DISPATCH | 0xA4 | PSXMatrix DMA channel dispatch via FFI |

### Grammar Extension
```
rust_offset_stmt = "&RUST_OFFSET" "(" struct_name "," field_name "," repr_type "," flags ")" ;
align_bound_stmt = "@ALIGN_BOUND" "(" bytes ")" ;
repr_type = "REPR_C" | "REPR_PACKED" | "REPR_ALIGN" | "REPR_TRANSPARENT" ;
flags = { "READ_ONLY" | "VOLATILE" | "UNSAFE_PTR" | "DMA_MAPPED" } ["|" flags] ;
```

### C++ Struct Changes
- `A2AST.h`: Added `RustReprType`, `RustOffsetFlags`, `RustOffsetFlag`, `RustFFIExport`, `RustFFIDispatchTable`, `CyberGrimeCP0Map`, `PSXHwRegMap`
- `A2AEvaluator.h`: Added AST and bytecode handlers for all 5 new opcodes
- `A2ALexer.h`: Extended `&` and `@` sigil parsers, added `RUST_FFI_CALL`, `CP0_REG_MAP`, `PSX_DMA_DISPATCH` keywords

### Rust FFI Impact
- `gamma_ffi.rs`: Full repr(C) parity types, PEAK-1..5 export wrappers, `SpeculativeScope` RAII guard, `RingBufferIter`, `HwIntBridge`

## Backwards Compatibility
Fully backwards compatible. New opcodes (0xA0-0xA4) do not collide with existing v1.1A opcodes. Existing .gamma scripts continue to work unchanged.

## Test Plan
- [x] Unit test: RustOffsetFlags bitfield packing
- [x] Unit test: QVec cosine similarity identity
- [x] Unit test: Ring buffer wrap arithmetic
- [x] Unit test: PSX hw reg map defaults
- [x] Unit test: Speculative scope rollback on error
- [x] Mock interop: CyberGrime → PSXMatrix → Gamma FFI pipeline

## Performance Impact
- AST parsing latency: +0.3μs per `&RUST_OFFSET` statement (negligible)
- Token reduction: No impact (new syntax is additive)
- SIMD throughput: PEAK-2 QVec SIMD now accelerated via Rust x86_64 SSE2 / ARM NEON

## References
- A2AST.h, A2AEvaluator.h, A2ALexer.h
- gamma_ffi.rs
- GAMMA_LANGUAGE_EBNF_SPEC.md (v1.1C extension)
