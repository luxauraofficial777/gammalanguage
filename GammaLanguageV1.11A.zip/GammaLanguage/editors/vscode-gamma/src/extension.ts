import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as path from 'path';

let diagnosticCollection: vscode.DiagnosticCollection;

export function activate(context: vscode.ExtensionContext) {
    diagnosticCollection = vscode.languages.createDiagnosticCollection('gamma');
    context.subscriptions.push(diagnosticCollection);

    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('gamma.compile', compileCurrentFile),
        vscode.commands.registerCommand('gamma.run', runCurrentFile),
        vscode.commands.registerCommand('gamma.caveman', cavemanCompress),
        vscode.commands.registerCommand('gamma.showBytecode', showBytecode)
    );

    // Register completion provider for .gamma files
    const completionProvider = vscode.languages.registerCompletionItemProvider(
        { scheme: 'file', language: 'gamma' },
        {
            provideCompletionItems(document: vscode.TextDocument, position: vscode.Position) {
                const linePrefix = document.lineAt(position).text.substr(0, position.character);
                const items: vscode.CompletionItem[] = [];

                // Sigil completions
                const sigils: [string, string, string] = [
                    ['!STATE:', 'State declaration', '!STATE: 0x${1:00} [${2:NAME}]'],
                    ['@INVARIANT:', 'Invariant guard', '@INVARIANT: ${1:condition}'],
                    ['@PREDICT:', 'Speculative pipeline', '@PREDICT: {\n  ${1:// body}\n  SPEC_COMMIT;\n}'],
                    ['@ALIGN_BOUND(', 'Memory alignment', '@ALIGN_BOUND(${1:64})'],
                    ['#QVEC[', 'Quantized vector register', '#QVEC[${1:0}]'],
                    ['#VEC[', 'FP16 vector register', '#VEC[${1:0}]'],
                    ['%HW_INT(', 'Hardware interrupt', '%HW_INT(${1:VBLANK})'],
                    ['^EVICT_SLIDING(', 'Sliding eviction', '^EVICT_SLIDING(SPAN=${1:2048}, STRIDE=${2:512})'],
                    ['&RUST_OFFSET(', 'Rust FFI offset', '&RUST_OFFSET(${1:Struct}, ${2:Field}, ${3:REPR_C}, ${4:VOLATILE})'],
                    ['RUST_FFI_CALL', 'Rust FFI dispatch', 'RUST_FFI_CALL ${1:PEAK1}, "${2:Struct,Field}";'],
                    ['CP0_REG_MAP', 'CP0 register map', 'CP0_REG_MAP HW[${1:0}], "${2:Status}";'],
                    ['PSX_DMA_DISPATCH', 'PSX DMA dispatch', 'PSX_DMA_DISPATCH ${1:CH1}, "${2:CDROM_READ}";'],
                    ['#HIVE[', 'Hive partition', '#HIVE["${1:hive_name}"]'],
                    ['$EXEC', 'Execution block', '$EXEC {\n  ${1:// body}\n}'],
                ];

                for (const [trigger, desc, snippet] of sigils) {
                    if (linePrefix.endsWith(trigger.substring(0, trigger.length - 1))) {
                        const item = new vscode.CompletionItem(trigger, vscode.CompletionItemKind.Keyword);
                        item.detail = desc;
                        item.insertText = new vscode.SnippetString(snippet);
                        items.push(item);
                    }
                }

                // Register bank completions
                if (linePrefix.match(/(REG|HW|SKL|#VEC|#QVEC|%SIG|CTX|LCK)\[$/)) {
                    for (let i = 0; i < 16; i++) {
                        const item = new vscode.CompletionItem(`${i}`, vscode.CompletionItemKind.Variable);
                        item.detail = `Register index ${i}`;
                        items.push(item);
                    }
                }

                // PEAK subsystem completions
                if (linePrefix.match(/RUST_FFI_CALL\s+$/)) {
                    for (const peak of ['PEAK1', 'PEAK2', 'PEAK3', 'PEAK4', 'PEAK5']) {
                        const item = new vscode.CompletionItem(peak, vscode.CompletionItemKind.Function);
                        item.detail = `${peak} subsystem FFI dispatch`;
                        items.push(item);
                    }
                }

                // HW interrupt channel completions
                if (linePrefix.match(/%HW_INT\($/)) {
                    for (const ch of ['VBLANK', 'DMA_CH1', 'AUDIO_SWAP', 'RENDER_DONE']) {
                        const item = new vscode.CompletionItem(ch, vscode.CompletionItemKind.EnumMember);
                        item.detail = `Hardware interrupt channel: ${ch}`;
                        items.push(item);
                    }
                }

                // Rust repr type completions
                if (linePrefix.match(/&RUST_OFFSET\([^,]*,[^,]*,$/)) {
                    for (const repr of ['REPR_C', 'REPR_PACKED', 'REPR_ALIGN', 'REPR_TRANSPARENT']) {
                        const item = new vscode.CompletionItem(repr, vscode.CompletionItemKind.EnumMember);
                        item.detail = `Rust representation: ${repr}`;
                        items.push(item);
                    }
                }

                return items;
            }
        },
        '.', '(', '[', '#', '@', '!', '$', '%', '&', '^', '~'
    );
    context.subscriptions.push(completionProvider);

    // Register hover provider for documentation
    const hoverProvider = vscode.languages.registerHoverProvider(
        { scheme: 'file', language: 'gamma' },
        {
            provideHover(document: vscode.TextDocument, position: vscode.Position) {
                const range = document.getWordRangeAtPosition(position);
                if (!range) return null;
                const word = document.getText(range);

                const docs: Record<string, string> = {
                    'REG': '**REG[0..15]** — General-purpose 64-bit integer registers',
                    'HW': '**HW[0..7]** — Hardware system definition registers (GPU/VDP/MMIO)',
                    'SKL': '**SKL[0..3]** — Skill pointer registers',
                    '#VEC': '**#VEC[0..7]** — 1536-element FP16 vector embedding registers',
                    '#QVEC': '**#QVEC[0..7]** — PEAK-2: 8-bit quantized vector registers (75% bandwidth reduction)',
                    '%SIG': '**%SIG[0..7]** — Cross-modulation float registers',
                    'CTX': '**CTX[0..3]** — Context window registers with sliding eviction',
                    'LCK': '**LCK[0..3]** — Mutex lock state registers',
                    '@PREDICT': '**@PREDICT** — PEAK-3: Speculative pipeline branch with commit/rollback',
                    '%HW_INT': '**%HW_INT** — PEAK-4: Hardware interrupt frame-sync dispatch',
                    'RUST_FFI_CALL': '**RUST_FFI_CALL** — v1.1C: Invoke PEAK subsystem via Rust FFI dispatch table',
                    '&RUST_OFFSET': '**&RUST_OFFSET** — v1.1C: Declare Rust FFI memory offset pointer with repr type',
                    '@ALIGN_BOUND': '**@ALIGN_BOUND** — v1.1C: Enforce memory alignment boundary (bytes)',
                    'CP0_REG_MAP': '**CP0_REG_MAP** — v1.1C: CyberGrime CP0 register → HW[0..7] mapping',
                    'PSX_DMA_DISPATCH': '**PSX_DMA_DISPATCH** — v1.1C: PSXMatrix DMA channel dispatch via FFI',
                };

                if (docs[word]) {
                    return new vscode.Hover(new vscode.MarkdownString(docs[word]), range);
                }
                return null;
            }
        }
    );
    context.subscriptions.push(hoverProvider);

    // Diagnostic linting on save
    context.subscriptions.push(
        vscode.workspace.onDidSaveTextDocument(document => {
            if (document.languageId === 'gamma') {
                lintDocument(document);
            }
        })
    );
}

function getCliPath(): string {
    const config = vscode.workspace.getConfiguration('gamma');
    return config.get<string>('cliPath') || 'python';
}

function lintDocument(document: vscode.TextDocument) {
    const config = vscode.workspace.getConfiguration('gamma');
    if (!config.get<boolean>('enableDiagnostics')) return;

    const cliPath = getCliPath();
    const scriptPath = path.join(
        vscode.workspace.rootPath || '',
        'GammaLanguage', 'python', 'gamma_cli.py'
    );

    const args = ['--script', document.fileName, '--json', '--lint-only'];
    const proc = cp.spawn(cliPath, [scriptPath, ...args]);

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => { stdout += data; });
    proc.stderr.on('data', (data) => { stderr += data; });

    proc.on('close', (code) => {
        const diagnostics: vscode.Diagnostic[] = [];

        if (stderr) {
            // Parse error messages with source map tracing
            const lines = stderr.split('\n');
            for (const line of lines) {
                const match = line.match(/Error at line (\d+), col (\d+): (.+)/);
                if (match) {
                    const lineNum = parseInt(match[1]) - 1;
                    const colNum = parseInt(match[2]) - 1;
                    const message = match[3];
                    const range = new vscode.Range(lineNum, colNum, lineNum, colNum + 20);
                    diagnostics.push(new vscode.Diagnostic(
                        range, message, vscode.DiagnosticSeverity.Error
                    ));
                }
            }
        }

        diagnosticCollection.set(document.uri, diagnostics);
    });
}

function compileCurrentFile() {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== 'gamma') {
        vscode.window.showWarningMessage('No .gamma file active');
        return;
    }
    const cliPath = getCliPath();
    const scriptPath = path.join(
        vscode.workspace.rootPath || '',
        'GammaLanguage', 'python', 'gamma_cli.py'
    );
    const proc = cp.spawn(cliPath, [scriptPath, '--script', editor.document.fileName, '--json']);
    let output = '';
    proc.stdout.on('data', (d) => { output += d; });
    proc.on('close', () => {
        try {
            const result = JSON.parse(output);
            vscode.window.showInformationMessage(
                `Compiled: ${result.ast_nodes || 0} AST nodes, ${result.bytecode_count || 0} bytecode instructions`
            );
        } catch {
            vscode.window.showInformationMessage('Compilation complete');
        }
    });
}

function runCurrentFile() {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== 'gamma') {
        vscode.window.showWarningMessage('No .gamma file active');
        return;
    }
    const cliPath = getCliPath();
    const scriptPath = path.join(
        vscode.workspace.rootPath || '',
        'GammaLanguage', 'python', 'gamma_cli.py'
    );
    const terminal = vscode.window.createTerminal('GammaLanguage');
    terminal.show();
    terminal.sendText(`${cliPath} ${scriptPath} --script "${editor.document.fileName}" --run`);
}

function cavemanCompress() {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== 'gamma') {
        vscode.window.showWarningMessage('No .gamma file active');
        return;
    }
    const text = editor.document.getText();
    // Simple caveman compression: strip comments, collapse whitespace
    const compressed = text
        .replace(/\/\/.*$/gm, '')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\n\s*\n/g, '\n')
        .trim();
    vscode.window.showInformationMessage(
        `Caveman: ${text.length} → ${compressed.length} bytes (${Math.round((1 - compressed.length / text.length) * 100)}% reduction)`
    );
}

function showBytecode() {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== 'gamma') {
        vscode.window.showWarningMessage('No .gamma file active');
        return;
    }
    const cliPath = getCliPath();
    const scriptPath = path.join(
        vscode.workspace.rootPath || '',
        'GammaLanguage', 'python', 'gamma_cli.py'
    );
    const proc = cp.spawn(cliPath, [scriptPath, '--script', editor.document.fileName, '--json', '--bytecode']);
    let output = '';
    proc.stdout.on('data', (d) => { output += d; });
    proc.on('close', () => {
        const panel = vscode.window.createWebviewPanel(
            'gammaBytecode', 'A2A-B Bytecode Disassembly',
            vscode.ViewColumn.Beside, { enableScripts: true }
        );
        panel.webview.html = `<html><body style="font-family: monospace; background: #1e1e1e; color: #d4d4d4; padding: 16px;">
            <h2>A2A-B Bytecode Disassembly</h2>
            <pre>${output || 'No bytecode output'}</pre>
        </body></html>`;
    });
}

export function deactivate() {}
