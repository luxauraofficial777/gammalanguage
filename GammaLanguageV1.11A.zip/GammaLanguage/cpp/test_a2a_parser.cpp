#include "A2ALexer.h"
#include "A2AEvaluator.h"
#include <iostream>
#include <chrono>
#include <cassert>

// Global heap allocation tracker for zero-allocation verification
static size_t g_heap_allocations = 0;

void* operator new(size_t size) {
    g_heap_allocations++;
    return std::malloc(size);
}

void operator delete(void* ptr) noexcept {
    std::free(ptr);
}

void operator delete(void* ptr, size_t) noexcept {
    std::free(ptr);
}

int main() {
    std::cout << "[+] Verifying Cache Alignment Constraints..." << std::endl;
    std::cout << "    sizeof(ASTNode) = " << sizeof(A2A::ASTNode) << " (Must be 256)" << std::endl;
    std::cout << "    alignof(RegisterBank) = " << alignof(A2A::RegisterBank) << " (Must be 64)" << std::endl;

    static_assert(sizeof(A2A::ASTNode) == 256, "ASTNode size mismatch!");
    static_assert(sizeof(A2A::ASTNode) % 64 == 0, "ASTNode alignment mismatch!");
    static_assert(alignof(A2A::RegisterBank) == 64, "RegisterBank 64-byte alignment mismatch!");

    const char* sample_script = R"(
// v1.1A-Robust+: Peak performance demo with all 5 additions
|TARGET: [D3DX11]
!STATE: 0x03 [SHADER_COMPILE]
+SKILL["AtlasForge"]
-SKILL["CombatEngine_Logic"]
@INVARIANT: HW[2] == STATE_READY
@ON_ERROR: {
    ~MCP("log", "D3DX11 compilation failed. Triggering GDI+ fallback.");
    !SHIFT_TARGET: [GDI_DIB];
    RETRY(MAX=2);
}
=LOCK="source_Core_X64/CameraControl.cpp"

$EXEC {
  CTX[0] = CAVEMAN_SHRINK("Compile isometric depth dither shader", LEVEL=FULL);
  ^EVICT_SLIDING(SPAN=2048, STRIDE=512);
  #HIVE["render_pipeline_shaders"]

  @PREDICT: {
    ?ZHARK(#HIVE["render_pipeline_shaders"], "Locate VBlank timing offset for DQ4 boot");
    #VEC[0] = LOAD_EMBEDDING(CTX[0]);
    #QVEC[0] = QUANTIZE(#VEC[0]);
    #QVEC[1] = QUANTIZE(#VEC[1]);
    #VEC_DELTA(#QVEC[0], #QVEC[1]);
    SPEC_COMMIT;
  }

  %HW_INT(VBLANK);
  #VEC[1] = QUERY_VECTOR_DB(#VEC[0], TOP_K=5);
  REG[0] = COSINE_SIM(#VEC[0], #VEC[1]);
  ^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048);

  MATCH REG[0] -> {
    0x80: %SIG[0] = 0.95;
          ~MCP("vwforge_shader", CTX[0]);
          EMIT_SIGNAL(0xFF, "HIGH_SIMILARITY_EXECUTE");
    _:    %SIG[0] = 0.10;
          ABORT_TRANSITION(0xE2, "VECTOR_SIMILARITY_BELOW_THRESHOLD");
  };
}

=UNLOCK="source_Core_X64/CameraControl.cpp"

<NATIVE_BRIDGE: CPP>
void FastCompose16BPP(uint16_t* pDest, const uint16_t* pSrc, int count) {
    for(int i = 0; i < count; ++i) {
        if(pSrc[i] & 0x8000) pDest[i] = pSrc[i];
    }
}
</NATIVE_BRIDGE>
)";

    // Reset heap allocation tracker before hotpath execution
    g_heap_allocations = 0;

    std::cout << "\n[+] Parsing Gamma Language v1.1A-Robust+ Stream (Static Arena)..." << std::endl;
    A2A::ASTArena<256> arena;
    A2A::Lexer lexer(sample_script);
    
    bool parse_ok = lexer.ParseIntoArena(arena);
    assert(parse_ok);

    std::cout << "[+] Parsed AST Nodes Count: " << arena.Count << std::endl;

    std::cout << "[+] Executing Gamma Evaluation Engine (Zero-Allocation Hotpath)..." << std::endl;
    alignas(64) A2A::RegisterBank registers{};
    registers.TurboQuantRamUtil = 0.45f;

    A2A::Evaluator evaluator(1000); // 1000 cycle ceiling
    auto result = evaluator.Execute(arena, registers);

    // Assert zero heap allocations during parsing and execution
    std::cout << "[+] Dynamic Heap Allocations During Hotpath: " << g_heap_allocations << std::endl;
    if (g_heap_allocations == 0) {
        std::cout << "    [PASS] ZERO-HEAP ALLOCATION GUARANTEE VERIFIED." << std::endl;
    } else {
        std::cout << "    [WARN] Dynamic heap allocations detected: " << g_heap_allocations << std::endl;
    }

    std::cout << "\n[+] Benchmark Parsing & SIMD Evaluation Throughput..." << std::endl;
    constexpr int ITERATIONS = 100000;
    auto t_start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < ITERATIONS; ++i) {
        A2A::Lexer bench_lexer(sample_script);
        bench_lexer.ParseIntoArena(arena);
        evaluator.Execute(arena, registers);
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double total_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    double ops_per_sec = (ITERATIONS * 1000.0) / total_ms;
    double mb_per_sec = (ITERATIONS * std::strlen(sample_script)) / (total_ms * 1000.0);

    std::cout << "    Iterations: " << ITERATIONS << " in " << total_ms << " ms" << std::endl;
    std::cout << "    Throughput: " << ops_per_sec << " evaluations/sec (" << mb_per_sec << " MB/sec)" << std::endl;

    std::cout << "\n[+] Execution Status: " << (result.Success ? "SUCCESS" : "FAILED") << std::endl;
    std::cout << "    Fault Code: 0x" << std::hex << static_cast<int>(result.Fault) << std::dec << std::endl;
    std::cout << "    Result Message: " << result.Message << std::endl;

    // PEAK-1: Compile AST to A2A-B bytecode and execute via Direct Threaded Code
    std::cout << "\n[+] PEAK-1: Compiling AST to A2A-B 32-bit Bytecode..." << std::endl;
    A2A::BytecodeArena<512> bc_arena;
    size_t bc_count = A2A::BytecodeCompiler::Compile(arena, bc_arena);
    std::cout << "    Bytecode Instructions: " << bc_count << " (4 bytes each = " << (bc_count * 4) << " bytes)" << std::endl;
    std::cout << "    AST Memory: " << (arena.Count * 256) << " bytes vs Bytecode: " << (bc_count * 4) << " bytes" << std::endl;
    std::cout << "    Compression Ratio: " << (static_cast<double>(arena.Count * 256) / (bc_count * 4)) << "x smaller" << std::endl;

    std::cout << "[+] PEAK-1: Executing Bytecode VM (Direct Threaded Code)..." << std::endl;
    alignas(64) A2A::RegisterBank bc_registers{};
    bc_registers.TurboQuantRamUtil = 0.45f;
    auto bc_result = evaluator.ExecuteBytecode(bc_arena, bc_registers);
    std::cout << "    Bytecode VM Status: " << (bc_result.Success ? "SUCCESS" : "FAILED") << std::endl;
    std::cout << "    Instructions Executed: " << bc_result.InstructionsExecuted << std::endl;

    // Benchmark bytecode execution vs AST execution
    std::cout << "\n[+] PEAK-1: Benchmarking Bytecode vs AST Throughput..." << std::endl;
    auto bc_start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < ITERATIONS; ++i) {
        A2A::BytecodeCompiler::Compile(arena, bc_arena);
        evaluator.ExecuteBytecode(bc_arena, bc_registers);
    }
    auto bc_end = std::chrono::high_resolution_clock::now();
    double bc_ms = std::chrono::duration<double, std::milli>(bc_end - bc_start).count();
    double bc_ops = (ITERATIONS * 1000.0) / bc_ms;
    std::cout << "    AST Path:   " << ops_per_sec << " evals/sec (" << total_ms << " ms)" << std::endl;
    std::cout << "    Bytecode:   " << bc_ops << " evals/sec (" << bc_ms << " ms)" << std::endl;
    std::cout << "    Speedup:    " << (bc_ops / ops_per_sec) << "x faster" << std::endl;

    return (result.Success && g_heap_allocations == 0) ? 0 : 1;
}
