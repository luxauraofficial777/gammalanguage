#pragma once
#include "A2AST.h"
#include <string_view>

namespace A2A {

class Lexer {
public:
    explicit Lexer(std::string_view stream);
    
    // Parses entire string stream into static arena without heap allocations
    template <size_t N>
    bool ParseIntoArena(ASTArena<N>& arena) {
        arena.Clear();
        while (m_cursor < m_stream.length()) {
            SkipWhitespaceAndComments();
            if (m_cursor >= m_stream.length()) break;

            char sigil = m_stream[m_cursor];
            ASTNode node{};

            if (sigil == '!') { // State Shift !STATE: 0x01 [NAME] or !SHIFT_TARGET: [NAME]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("SHIFT_TARGET") != std::string_view::npos) {
                    node.op = Opcode::SHIFT_TARGET;
                } else {
                    node.op = Opcode::STATE_DECL;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '@') { // Invariant Guard @INVARIANT:, @ON_ERROR:, @PREDICT, or v1.1C @ALIGN_BOUND
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("ALIGN_BOUND") != std::string_view::npos) {
                    // v1.1C: @ALIGN_BOUND(BYTES) — enforce memory alignment
                    node.op = Opcode::ALIGN_BOUND;
                    // Extract byte value from parentheses
                    size_t parenStart = line.find('(');
                    size_t parenEnd = line.find(')');
                    if (parenStart != std::string_view::npos && parenEnd != std::string_view::npos) {
                        auto numStr = line.substr(parenStart + 1, parenEnd - parenStart - 1);
                        // Skip optional KEY= prefix (e.g. BOUND=16)
                        size_t eqPos = numStr.find('=');
                        if (eqPos != std::string_view::npos) {
                            numStr = numStr.substr(eqPos + 1);
                        }
                        // Parse into a separate accumulator initialized to 0
                        uint32_t bound = 0;
                        bool any_digit = false;
                        for (char c : numStr) {
                            if (c >= '0' && c <= '9') {
                                bound = bound * 10 + static_cast<uint32_t>(c - '0');
                                any_digit = true;
                            } else if (!any_digit) {
                                continue; // skip leading non-digits (e.g. spaces)
                            } else {
                                break;
                            }
                        }
                        // Validate: must be a power of two in sane range [1, 4096]
                        if (any_digit && bound >= 1 && bound <= 4096 &&
                            (bound & (bound - 1)) == 0) {
                            node.int_imm = static_cast<int64_t>(bound);
                        } else {
                            node.int_imm = 64; // default cache-line alignment
                        }
                    }
                } else if (line.find("ON_ERROR") != std::string_view::npos) {
                    node.op = Opcode::ON_ERROR_BLOCK;
                    // Read until closing brace
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') m_cursor++;
                    if (m_cursor < m_stream.length()) m_cursor++; // consume }
                } else if (line.find("PREDICT") != std::string_view::npos) {
                    node.op = Opcode::PREDICT_BLOCK;
                } else {
                    node.op = Opcode::INVARIANT_GUARD;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '&') { // Colibri Directives or v1.1C Rust FFI Offset: &PIN_EXPERT, &RUST_OFFSET
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("RUST_OFFSET") != std::string_view::npos) {
                    // v1.1C: &RUST_OFFSET(STRUCT_NAME, FIELD_OFFSET, REPR_TYPE, FLAGS)
                    node.op = Opcode::RUST_OFFSET_LOAD;
                    // Parse repr type and flags to pack into int_imm
                    uint8_t flag = 0;
                    RustReprType repr = RustReprType::REPR_C;
                    if (line.find("READ_ONLY") != std::string_view::npos) flag |= 0x01;
                    if (line.find("VOLATILE") != std::string_view::npos) flag |= 0x02;
                    if (line.find("UNSAFE_PTR") != std::string_view::npos) flag |= 0x04;
                    if (line.find("DMA_MAPPED") != std::string_view::npos) flag |= 0x08;
                    if (line.find("REPR_PACKED") != std::string_view::npos) repr = RustReprType::REPR_PACKED;
                    else if (line.find("REPR_ALIGN") != std::string_view::npos) repr = RustReprType::REPR_ALIGN;
                    else if (line.find("REPR_TRANSPARENT") != std::string_view::npos) repr = RustReprType::REPR_TRANSPARENT;
                    // Extract offset from payload (simple: use hash of field name as placeholder)
                    uint32_t offset = 0; // Real parser would extract numeric offset
                    RustOffsetFlags rof(flag, repr, offset);
                    node.int_imm = static_cast<int64_t>(rof.packed);
                } else if (line.find("PIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_PIN;
                else if (line.find("UNPIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_UNPIN;
                else if (line.find("SWAP_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_SWAP;
                else node.op = Opcode::COLIBRI_HEARTBEAT;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '|') { // Target Context |TARGET: [NAME] or |TARGET_DEFINE: [NAME] { ... }
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("TARGET_DEFINE") != std::string_view::npos) {
                    node.op = Opcode::TARGET_DEFINE;
                    // Skip past the definition block { ... }
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') m_cursor++;
                    if (m_cursor < m_stream.length()) m_cursor++; // consume }
                    if (m_cursor < m_stream.length() && m_stream[m_cursor] == '\n') m_cursor++;
                } else {
                    node.op = Opcode::TARGET_DECL;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '+') { // Skill Equip +SKILL["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_EQUIP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '-') { // Skill Unload -SKILL["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_UNLOAD;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '*') { // Profile Swap *PROFILE["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::PROFILE_SWAP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '=') { // Sync Guard =LOCK=, =UNLOCK=, =BARRIER=, =SYNC(
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("LOCK=") != std::string_view::npos && line.find("UNLOCK=") == std::string_view::npos)
                    node.op = Opcode::LOCK_ACQUIRE;
                else if (line.find("UNLOCK=") != std::string_view::npos)
                    node.op = Opcode::LOCK_RELEASE;
                else if (line.find("BARRIER=") != std::string_view::npos)
                    node.op = Opcode::BARRIER_WAIT;
                else if (line.find("SYNC(") != std::string_view::npos)
                    node.op = Opcode::SYNC_WAIT;
                else
                    node.op = Opcode::LOCK_ACQUIRE; // default
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '?') { // ZHARK Query ?ZHARK(...)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::ZHARK_QUERY;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (static_cast<unsigned char>(sigil) == 0xC2 && m_cursor + 1 < m_stream.length()
                     && static_cast<unsigned char>(m_stream[m_cursor + 1]) == 0xBF) {
                // FUBBU Sync ¿ (UTF-8: 0xC2 0xBF)
                m_cursor += 2; // Skip 2-byte UTF-8 sequence
                std::string_view line = ReadUntil(';');
                node.op = Opcode::FUBBU_SYNC;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '<') { // Native Bridge <NATIVE_BRIDGE: LANG>
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::NATIVE_BRIDGE;
                // Skip until </NATIVE_BRIDGE>
                while (m_cursor + 16 < m_stream.length()) {
                    if (m_stream[m_cursor] == '<' && m_stream[m_cursor+1] == '/') {
                        // Found closing tag
                        while (m_cursor < m_stream.length() && m_stream[m_cursor] != '\n') m_cursor++;
                        break;
                    }
                    m_cursor++;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '$') { // Exec Block $EXEC { ... }
                m_cursor++;
                ReadUntil('{');
            }
            else if (sigil == '#') { // Vector/Hive/Quantized ops: #VEC, #QVEC, #VEC_DELTA, #HIVE
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("HIVE") != std::string_view::npos) {
                    node.op = Opcode::HIVE_SELECT;
                } else if (line.find("QVEC") != std::string_view::npos && line.find("VEC_DELTA") == std::string_view::npos) {
                    node.op = Opcode::QVEC_LOAD;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                } else if (line.find("VEC_DELTA") != std::string_view::npos) {
                    node.op = Opcode::VEC_DELTA;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                    node.src_reg_a = ParseSecondBracketIndex(line, 8);
                } else if (line.find("LOAD_EMBEDDING") != std::string_view::npos) {
                    node.op = Opcode::VECTOR_LOAD;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                } else if (line.find("QUERY_VECTOR_DB") != std::string_view::npos) {
                    node.op = Opcode::VECTOR_QUERY;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                } else {
                    node.op = Opcode::VECTOR_LOAD;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '%') { // Signal Assignment or HW Interrupt: %SIG[0]=, %HW_INT(
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("HW_INT") != std::string_view::npos) {
                    node.op = Opcode::HW_INTERRUPT;
                } else {
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.target_reg = ParseBracketIndex(line, 0, 8);
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '~') { // MCP Pipe ~MCP("tool", payload)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::MCP_CALL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '^') { // Gigatoken Pack or Eviction: ^GIGATOKEN_PACK, ^EVICT_SLIDING
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("EVICT_SLIDING") != std::string_view::npos) {
                    node.op = Opcode::EVICT_SLIDING;
                } else {
                    node.op = Opcode::GIGATOKEN_PACK;
                    node.target_reg = ParseBracketIndex(line, 0, 4);
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else {
                std::string_view word = ReadWord();
                if (word == "CTX[0]" || word.rfind("CTX", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.target_reg = ParseBracketIndex(word, 0, 4);
                    if (line.find("CAVEMAN_SHRINK") != std::string_view::npos) node.op = Opcode::CAVEMAN_SHRINK;
                    else node.op = Opcode::ASSIGN_STRING;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "REG[0]" || word.rfind("REG", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.target_reg = ParseBracketIndex(word, 0, 16);
                    if (line.find("COSINE_SIM") != std::string_view::npos) node.op = Opcode::COSINE_SIM;
                    else node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "HW[0]" || word.rfind("HW", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.target_reg = ParseBracketIndex(word, 0, 8);
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SKL[0]" || word.rfind("SKL", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.target_reg = ParseBracketIndex(word, 0, 4);
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "LCK[0]" || word.rfind("LCK", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.target_reg = ParseBracketIndex(word, 0, 4);
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "EMIT_SIGNAL") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::EMIT_SIGNAL;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "ABORT_TRANSITION") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ABORT_TRANSITION;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "MATCH") {
                    std::string_view line = ReadUntil('{');
                    node.op = Opcode::MATCH_BEGIN;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SPEC_COMMIT") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::SPEC_COMMIT;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SPEC_ROLLBACK") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::SPEC_ROLLBACK;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "RETRY") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::RETRY;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                // v1.1C: Rust FFI and PSX interop keywords
                else if (word == "RUST_FFI_CALL") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::RUST_FFI_CALL;
                    // Parse PEAK subsystem from payload (PEAK1..PEAK5)
                    if (line.find("PEAK1") != std::string_view::npos) node.target_reg = 0;
                    else if (line.find("PEAK2") != std::string_view::npos) node.target_reg = 1;
                    else if (line.find("PEAK3") != std::string_view::npos) node.target_reg = 2;
                    else if (line.find("PEAK4") != std::string_view::npos) node.target_reg = 3;
                    else if (line.find("PEAK5") != std::string_view::npos) node.target_reg = 4;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "CP0_REG_MAP") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::CP0_REG_MAP;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "PSX_DMA_DISPATCH") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::PSX_DMA_DISPATCH;
                    // Parse DMA channel (CH1 or CH2)
                    if (line.find("CH1") != std::string_view::npos) node.target_reg = 0;
                    else if (line.find("CH2") != std::string_view::npos) node.target_reg = 1;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else {
                    m_cursor++; // Consume character to advance
                }
            }
        }
        return true;
    }

private:
    void SkipWhitespaceAndComments();
    std::string_view ReadUntil(char delimiter);
    std::string_view ReadWord();

    // Parse a bracketed register index from a string_view (e.g. "QVEC[3]" -> 3)
    // Returns 0 if no bracket is found. Clamps to max_val for safety.
    static uint8_t ParseBracketIndex(std::string_view sv, size_t start, uint8_t max_val) {
        size_t bracket = sv.find('[', start);
        if (bracket == std::string_view::npos) return 0;
        size_t end = sv.find(']', bracket);
        if (end == std::string_view::npos) return 0;
        uint8_t idx = 0;
        for (size_t i = bracket + 1; i < end; ++i) {
            if (sv[i] >= '0' && sv[i] <= '9') idx = idx * 10 + static_cast<uint8_t>(sv[i] - '0');
            else break;
        }
        if (idx >= max_val) idx = 0; // out-of-range: reset to 0
        return idx;
    }

    // Parse the second bracketed index (for e.g. #VEC_DELTA(#QVEC[0], #QVEC[1]))
    static uint8_t ParseSecondBracketIndex(std::string_view sv, uint8_t max_val) {
        size_t first_end = sv.find(']');
        if (first_end == std::string_view::npos) return 0;
        return ParseBracketIndex(sv, first_end + 1, max_val);
    }

    std::string_view m_stream;
    size_t m_cursor{0};
};

} // namespace A2A
