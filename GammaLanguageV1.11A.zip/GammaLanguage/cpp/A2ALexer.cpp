#include "A2ALexer.h"
#include <cctype>

namespace A2A {

Lexer::Lexer(std::string_view stream) : m_stream(stream), m_cursor(0) {}

void Lexer::SkipWhitespaceAndComments() {
    while (m_cursor < m_stream.length()) {
        char c = m_stream[m_cursor];
        if (std::isspace(static_cast<unsigned char>(c))) {
            m_cursor++;
        } else if (c == '(' && m_cursor + 1 < m_stream.length() && m_stream[m_cursor + 1] == '*') {
            m_cursor += 2;
            while (m_cursor + 1 < m_stream.length() && !(m_stream[m_cursor] == '*' && m_stream[m_cursor + 1] == ')')) {
                m_cursor++;
            }
            if (m_cursor + 1 < m_stream.length()) m_cursor += 2;
        } else {
            break;
        }
    }
}

std::string_view Lexer::ReadUntil(char delimiter) {
    size_t start = m_cursor;
    while (m_cursor < m_stream.length() && m_stream[m_cursor] != delimiter) {
        m_cursor++;
    }
    std::string_view res = m_stream.substr(start, m_cursor - start);
    if (m_cursor < m_stream.length() && m_stream[m_cursor] == delimiter) {
        m_cursor++; // Consume delimiter
    }
    return res;
}

std::string_view Lexer::ReadWord() {
    SkipWhitespaceAndComments();
    size_t start = m_cursor;
    while (m_cursor < m_stream.length()) {
        char c = m_stream[m_cursor];
        if (std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '.' || c == '-' || c == '[' || c == ']' || c == ':') {
            m_cursor++;
        } else {
            break;
        }
    }
    return m_stream.substr(start, m_cursor - start);
}

} // namespace A2A
