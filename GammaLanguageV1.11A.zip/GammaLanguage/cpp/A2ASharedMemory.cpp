#include "A2ASharedMemory.h"
#include <iostream>

namespace A2A {

SharedMemoryBus::SharedMemoryBus(const std::string& name) : m_name(name) {}

SharedMemoryBus::~SharedMemoryBus() {
#ifdef _WIN32
    if (m_buffer) {
        UnmapViewOfFile(m_buffer);
    }
    if (m_hMapFile) {
        CloseHandle(m_hMapFile);
    }
#endif
}

bool SharedMemoryBus::Initialize(bool create) {
#ifdef _WIN32
    std::string mapName = "Local\\" + m_name;
    size_t size = sizeof(AST_RingBuffer);

    if (create) {
        m_hMapFile = CreateFileMappingA(
            INVALID_HANDLE_VALUE,
            NULL,
            PAGE_READWRITE,
            0,
            static_cast<DWORD>(size),
            mapName.c_str());

        if (m_hMapFile == NULL) return false;

        m_buffer = static_cast<AST_RingBuffer*>(MapViewOfFile(
            m_hMapFile,
            FILE_MAP_ALL_ACCESS,
            0,
            0,
            size));

        if (m_buffer) {
            // Check if we actually created it or opened an existing one
            if (GetLastError() != ERROR_ALREADY_EXISTS) {
                m_buffer->head = 0;
                m_buffer->tail = 0;
            }
        }
    } else {
        m_hMapFile = OpenFileMappingA(
            FILE_MAP_ALL_ACCESS,
            FALSE,
            mapName.c_str());

        if (m_hMapFile == NULL) return false;

        m_buffer = static_cast<AST_RingBuffer*>(MapViewOfFile(
            m_hMapFile,
            FILE_MAP_ALL_ACCESS,
            0,
            0,
            size));
    }

    return m_buffer != nullptr;
#else
    // Stub for non-Windows platforms
    return false;
#endif
}

bool SharedMemoryBus::Write(const ASTNode& node) {
    if (!m_buffer) return false;
    
    // Simple lock-free ring buffer write (single producer expected here)
    // Full implementation requires std::atomic for thread safety
    uint32_t current_head = m_buffer->head;
    uint32_t next_head = (current_head + 1) % RING_BUFFER_CAPACITY;
    
    if (next_head == m_buffer->tail) {
        return false; // Buffer full
    }
    
    m_buffer->nodes[current_head] = node;
    
    m_buffer->head = next_head;
    return true;
}

bool SharedMemoryBus::Read(ASTNode& out_node) {
    if (!m_buffer) return false;
    
    uint32_t current_tail = m_buffer->tail;
    
    if (current_tail == m_buffer->head) {
        return false; // Buffer empty
    }
    
    out_node = m_buffer->nodes[current_tail];
    
    m_buffer->tail = (current_tail + 1) % RING_BUFFER_CAPACITY;
    return true;
}

} // namespace A2A
