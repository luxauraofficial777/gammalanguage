#pragma once
#include <cstdint>
#include <array>
#include <string_view>
#include <cstring>
#include <cstdio>
#include <cstddef>

namespace A2A {

// Fault code masks
enum class FaultCode : uint8_t {
    NONE                    = 0x00,
    SCHEMA_DRIFT            = 0xE0,
    MEMORY_LIMIT_EXCEEDED   = 0xE1,
    INSTRUCTION_BUDGET      = 0xE2,
    VECTOR_SIMILARITY_LOW   = 0xE3,
    NOT_IMPLEMENTED         = 0xE4
};

// Opcode definitions matching Gamma Language v1.1A-Robust spec
enum class Opcode : uint8_t {
    NOP                 = 0x00,
    // v1.0 opcodes
    STATE_DECL          = 0x01,
    INVARIANT_GUARD     = 0x02,
    COLIBRI_PIN         = 0x03,
    COLIBRI_UNPIN       = 0x04,
    COLIBRI_SWAP        = 0x05,
    COLIBRI_HEARTBEAT   = 0x06,

    ASSIGN_SCALAR       = 0x0A,
    ASSIGN_STRING       = 0x0B,

    VECTOR_LOAD         = 0x10,
    VECTOR_QUERY        = 0x11,
    COSINE_SIM          = 0x12,

    CAVEMAN_SHRINK      = 0x20,
    GIGATOKEN_PACK      = 0x30,
    MCP_CALL            = 0x40,

    MATCH_BEGIN         = 0x50,
    MATCH_BRANCH        = 0x51,

    EMIT_SIGNAL         = 0xFE,
    ABORT_TRANSITION    = 0xFF,
    // v1.1A-Robust new opcodes
    TARGET_DECL         = 0x07,
    TARGET_DEFINE       = 0x08,
    SKILL_EQUIP         = 0x09,
    SKILL_UNLOAD        = 0x0C,
    PROFILE_SWAP        = 0x0D,
    HIVE_SELECT         = 0x15,
    ZHARK_QUERY         = 0x16,
    FUBBU_SYNC          = 0x17,
    LOCK_ACQUIRE        = 0x60,
    LOCK_RELEASE        = 0x61,
    BARRIER_WAIT        = 0x62,
    SYNC_WAIT           = 0x63,
    ON_ERROR_BLOCK      = 0x70,
    SHIFT_TARGET        = 0x71,
    RETRY               = 0x72,
    NATIVE_BRIDGE       = 0x80,
    // v1.1A-Robust Peak Performance opcodes
    QVEC_LOAD           = 0x18,   // PEAK-2: Load 8-bit quantized vector
    VEC_DELTA            = 0x19,   // PEAK-2: Differential vector update
    PREDICT_BLOCK        = 0x73,   // PEAK-3: Speculative pipeline branch
    SPEC_COMMIT          = 0x74,   // PEAK-3: Commit speculative buffer
    SPEC_ROLLBACK        = 0x75,   // PEAK-3: Rollback speculative buffer
    HW_INTERRUPT         = 0x90,   // PEAK-4: Hardware interrupt frame-sync
    EVICT_SLIDING        = 0x31,   // PEAK-5: Sliding-window context eviction
    // v1.1C: Rust FFI & memory offset opcodes
    RUST_OFFSET_LOAD     = 0xA0,   // Load Rust struct offset pointer
    RUST_FFI_CALL        = 0xA1,   // Invoke Rust FFI function via dispatch table
    ALIGN_BOUND          = 0xA2,   // Enforce memory alignment boundary
    CP0_REG_MAP          = 0xA3,   // CyberGrime CP0 register → HW[0..7] mapping
    PSX_DMA_DISPATCH     = 0xA4    // PSXMatrix DMA channel dispatch via FFI
};

enum class CavemanLevel : uint8_t {
    LITE = 0,
    FULL = 1,
    ULTRA = 2,
    WENYAN = 3
};

// PEAK-4: Hardware interrupt channels for frame-sync runtimes
enum class HWIntChannel : uint8_t {
    NONE        = 0x00,
    VBLANK      = 0x01,
    DMA_CH1     = 0x02,
    AUDIO_SWAP  = 0x03,
    RENDER_DONE = 0x04
};

// PEAK-3: Speculative execution buffer state
struct SpeculativeBuffer {
    bool Active{false};        // True inside a @PREDICT block
    bool Committed{false};     // True if speculative results were committed
    uint32_t StartPC{0};       // Arena index at @PREDICT entry
    uint32_t SavedRetryCount{0};
    uint8_t SavedTargetIndex{0};
    std::array<uint64_t, 4> SavedLck{};
    std::array<float, 8> SavedSig{};
};

// ===================================================================
// v1.1C: Rust FFI Memory Offset Flags & Zero-Copy Architecture
// ===================================================================

// Rust representation type — controls struct layout parity for FFI
enum class RustReprType : uint8_t {
    REPR_C       = 0x0,   // #[repr(C)] — field order preserved
    REPR_PACKED  = 0x1,   // #[repr(packed)] — no padding
    REPR_ALIGN   = 0x2,   // #[repr(C, align(64))] — cache-line aligned
    REPR_TRANSPARENT = 0x3  // #[repr(transparent)] — single-field wrapper
};

// 32-bit Rust offset flag bitfield packed into A2A-B bytecode
// Layout: [31:28] Flag (4 bits) | [27:24] ReprType (4 bits) | [23:0] OffsetAddr (24 bits)
// This is encoded as the trailing uint32_t after a RUST_OFFSET_LOAD instruction
struct RustOffsetFlags {
    uint32_t packed;

    constexpr RustOffsetFlags() : packed(0) {}
    constexpr RustOffsetFlags(uint8_t flag, RustReprType repr, uint32_t offset)
        : packed((uint32_t(flag & 0x0F) << 28) |
                 (uint32_t(repr) << 24) |
                 (offset & 0x00FFFFFF)) {}

    constexpr uint8_t Flag()       const { return (packed >> 28) & 0x0F; }
    constexpr uint8_t ReprType()   const { return (packed >> 24) & 0x0F; }
    constexpr uint32_t OffsetAddr() const { return packed & 0x00FFFFFF; }
};

static_assert(sizeof(RustOffsetFlags) == 4, "RustOffsetFlags must be 4 bytes for A2A-B trailing word");

// Rust offset flag semantics
enum class RustOffsetFlag : uint8_t {
    NONE         = 0x0,  // No special flag
    READ_ONLY    = 0x1,  // Read-only memory access
    VOLATILE     = 0x2,  // Volatile read/write (MMIO)
    UNSAFE_PTR   = 0x4,  // Raw pointer — requires unsafe block
    DMA_MAPPED   = 0x8   // DMA-mapped memory region (PSX)
};

inline constexpr RustOffsetFlag operator|(RustOffsetFlag a, RustOffsetFlag b) {
    return static_cast<RustOffsetFlag>(static_cast<uint8_t>(a) | static_cast<uint8_t>(b));
}

// Zero-copy FFI export descriptor — passed to Rust as *const pointer
// This struct is repr(C) compatible with the Rust GammaFFIExport struct
struct alignas(16) RustFFIExport {
    const void* DataPtr{nullptr};       // Pointer to exported data (RegisterBank, BytecodeArena, etc.)
    uint32_t DataSize{0};               // Size of exported data in bytes
    uint32_t ElementSize{0};            // Size of each element (for arrays)
    RustReprType Repr{RustReprType::REPR_C};
    RustOffsetFlag Flags{RustOffsetFlag::NONE};
    uint8_t _pad[2]{};                 // Explicit padding for FFI parity with Rust _pad field
    uint32_t OffsetAddr{0};             // Byte offset within the struct
    char StructName[32]{};              // Rust struct name (e.g. "RegisterBank")
    char FieldName[32]{};               // Field name (e.g. "QVec[0]")
};

// Layout: 8(ptr) + 4 + 4 + 1 + 1 + 2(pad) + 4 + 32 + 32 = 88 bytes, alignas(16) → 96 bytes
// Rust: #[repr(C, align(16))] GammaFFIExport must match this size exactly.
static_assert(sizeof(RustFFIExport) == 96, "RustFFIExport must be 96 bytes for FFI parity with Rust GammaFFIExport");

// FFI dispatch table — maps PEAK subsystem to Rust function pointers
struct alignas(64) RustFFIDispatchTable {
    // PEAK-1: Bytecode arena export — *const u32 to Rust DTC jump table
    void (*Peak1_ExportBytecode)(const RustFFIExport* desc) {nullptr};
    // PEAK-2: QVec SIMD wrapper — maps #QVEC[0..7] to x86_64/NEON intrinsics
    void (*Peak2_QVecSimd)(const RustFFIExport* qvec_desc, uint8_t op_type) {nullptr};
    // PEAK-3: Speculative scope — RAII guard for @PREDICT/SPEC_COMMIT/ROLLBACK
    void (*Peak3_SpecScope)(const RustFFIExport* spec_desc, uint8_t action) {nullptr};
    // PEAK-4: HW interrupt bridge — async event loop to HWIntChannel
    void (*Peak4_HwIntBridge)(const RustFFIExport* hw_desc, uint8_t channel) {nullptr};
    // PEAK-5: Ring buffer iterator — wraps CtxWritePos modular arithmetic
    void (*Peak5_RingIter)(const RustFFIExport* ctx_desc, uint16_t span, uint16_t stride) {nullptr};
    // v1.1C: Generic Rust FFI call
    void (*GenericFFI)(const RustFFIExport* desc, uint32_t fn_hash) {nullptr};
};

// ===================================================================
// v1.1C: CyberGrime CP0 Register Map
// ===================================================================
// Maps MIPS CP0 coprocessor registers to Gamma's HW[0..7] bank
struct CyberGrimeCP0Map {
    uint32_t CP0_Status{0};      // CP0 reg 12 — Status register
    uint32_t CP0_Cause{0};       // CP0 reg 13 — Cause register
    uint32_t CP0_EPC{0};         // CP0 reg 14 — Exception PC
    uint32_t CP0_BadVAddr{0};    // CP0 reg 8 — Bad virtual address
    uint32_t CP0_Count{0};       // CP0 reg 9 — Cycle counter
    uint32_t CP0_Compare{0};     // CP0 reg 11 — Timer compare
    uint32_t CP0_EntryHi{0};     // CP0 reg 10 — TLB entry high
    uint32_t CP0_Index{0};       // CP0 reg 0 — TLB index
};

static_assert(sizeof(CyberGrimeCP0Map) == 32, "CyberGrimeCP0Map must be 32 bytes");

// ===================================================================
// v1.1C: PSXMatrix Hardware Register Offset Map
// ===================================================================
// 32-bit hardware register offsets for PSX DMA channels and GPU VRAM
struct PSXHwRegMap {
    // DMA Channel 1 (CD-ROM) — base 0x1F8010A0
    uint32_t DMA_CH1_MADR{0x1F8010A0};   // DMA CH1 Memory Address
    uint32_t DMA_CH1_BCR{0x1F8010A4};    // DMA CH1 Block Control
    uint32_t DMA_CH1_CHCR{0x1F8010A8};   // DMA CH1 Channel Control
    // DMA Channel 2 (GPU) — base 0x1F8010B0
    uint32_t DMA_CH2_MADR{0x1F8010B0};   // DMA CH2 Memory Address (GPU)
    uint32_t DMA_CH2_BCR{0x1F8010B4};    // DMA CH2 Block Control (GPU)
    uint32_t DMA_CH2_CHCR{0x1F8010B8};   // DMA CH2 Channel Control (GPU)
    // GPU VRAM window registers — base 0x1F801000
    uint32_t GPU_GP0{0x1F801810};        // GPU GP0 command/data register
    uint32_t GPU_GP1{0x1F801814};        // GPU GP1 status/control register
    // Interrupt control
    uint32_t I_STAT{0x1F801070};         // Interrupt status register
    uint32_t I_MASK{0x1F801074};         // Interrupt mask register
};

static_assert(sizeof(PSXHwRegMap) == 40, "PSXHwRegMap must be 40 bytes");

// 64-byte aligned register bank to fit L1 cache lines perfectly
// v1.1A-Robust: 7 register banks (added HW, SKL, LCK)
// PEAK-2: Added QVec (8-bit quantized vectors, 75% bandwidth reduction)
struct alignas(64) RegisterBank {
    std::array<int64_t, 16> Reg{};                         // REG[0..15] 128 bytes
    std::array<uint64_t, 8> Hw{};                          // HW[0..7] system defs (GPU/VDP/MMIO)
    std::array<uint64_t, 4> Skl{};                         // SKL[0..3] skill pointers
    std::array<std::array<uint16_t, 1536>, 8> Vec{};        // #VEC[0..7] 24,576 bytes FP16 vector embeddings
    std::array<std::array<uint8_t, 1536>, 8> QVec{};        // PEAK-2: #QVEC[0..7] 12,288 bytes 8-bit quantized vectors
    std::array<float, 8> Sig{};                             // %SIG[0..7] 32 bytes Cross-modulation floats
    std::array<std::array<char, 2048>, 4> Ctx{};            // CTX[0..3] 8,192 bytes Gigatoken context buffers
    std::array<uint64_t, 4> Lck{};                          // LCK[0..3] mutex handles for multi-agent sync
    uint8_t ActiveExpertIndex{0};                           // Currently pinned Colibri expert
    float TurboQuantRamUtil{0.0f};                          // Latest RAM pressure reading
    uint8_t ActiveTargetIndex{0};                           // v1.1A: current target profile index
    uint8_t RetryCount{0};                                  // v1.1A: retry counter for @ON_ERROR
    uint8_t MaxRetries{2};                                  // v1.1A: max retries before abort
    // PEAK-4: Hardware interrupt state
    HWIntChannel PendingInt{HWIntChannel::NONE};            // Current pending hardware interrupt
    uint32_t FrameCount{0};                                 // Frame counter for frame-sync targets
    // PEAK-5: Sliding-window eviction metadata
    uint16_t EvictSpan{2048};                               // Eviction window span in tokens
    uint16_t EvictStride{512};                              // Eviction stride in tokens
    uint16_t CtxWritePos[4]{0, 0, 0, 0};                    // Ring-buffer write positions for CTX[0..3]
    // PEAK-3: Speculative buffer
    SpeculativeBuffer SpecBuf;
    // v1.1C: Rust FFI dispatch table (zero-copy PEAK exports)
    RustFFIDispatchTable FFITable;
    // v1.1C: CyberGrime CP0 register map (mapped to HW[0..7])
    CyberGrimeCP0Map CP0Map;
    // v1.1C: PSXMatrix hardware register offsets
    PSXHwRegMap PSXRegs;
    // v1.1C: Alignment boundary enforcement (bytes)
    uint32_t AlignBound{64};
};

// 256-byte aligned AST node for cache line performance & zero-allocation execution
struct alignas(64) ASTNode {
    Opcode op{Opcode::NOP};
    uint8_t target_reg{0};
    uint8_t src_reg_a{0};
    uint8_t src_reg_b{0};
    CavemanLevel caveman_lvl{CavemanLevel::FULL};
    float scalar_imm{0.0f};
    int64_t int_imm{0};
    char payload_str[228]{};                                // Padded so sizeof(ASTNode) == 256 bytes

    void SetPayload(std::string_view sv) {
        size_t len = (sv.length() < sizeof(payload_str) - 1) ? sv.length() : (sizeof(payload_str) - 1);
        std::memcpy(payload_str, sv.data(), len);
        payload_str[len] = '\0';
    }
};

static_assert(sizeof(ASTNode) == 256, "ASTNode must be exactly 256 bytes for 64-byte alignment");
static_assert(sizeof(ASTNode) % 64 == 0, "ASTNode size must be a multiple of 64 bytes");

// Contiguous memory arena buffer for zero dynamic heap allocation during parsing
template <size_t MaxCapacity = 256>
struct ASTArena {
    std::array<ASTNode, MaxCapacity> Nodes{};
    size_t Count{0};

    bool Push(const ASTNode& node) {
        if (Count >= MaxCapacity) return false;
        Nodes[Count++] = node;
        return true;
    }

    void Clear() {
        Count = 0;
    }
};

// 64-byte aligned structure for AST Memoization (Cross-Module Caching)
struct alignas(64) AST_Memoizer {
    static constexpr size_t CACHE_SIZE = 1024;
    
    struct CacheEntry {
        uint64_t hash_key;
        const ASTNode* node_ptr;
    };
    
    std::array<CacheEntry, CACHE_SIZE> Entries{};
    
    uint64_t HashPayload(std::string_view sv) const {
        uint64_t hash = 5381;
        for (char c : sv) {
            hash = ((hash << 5) + hash) + c;
        }
        return hash;
    }
    
    void CacheNode(std::string_view payload, const ASTNode* node) {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        Entries[index] = {key, node};
    }
    
    const ASTNode* Lookup(std::string_view payload) const {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        if (Entries[index].hash_key == key && Entries[index].node_ptr) {
            return Entries[index].node_ptr;
        }
        return nullptr;
    }
};

// ===================================================================
// PEAK-1: A2A-B Binary Bytecode Format (32-bit packed instructions)
// ===================================================================
//
// While ASCII sigil syntax is ideal for LLM text generation, compiling
// incoming DSL streams into bit-packed arrays at the MCP boundary allows
// the C++ VM to execute via Direct Threaded Code jump tables — completely
// eliminating string lexing overhead on the hot path.
//
// Layout (32 bits):
//   [31:24]  Opcode (8 bits)  — maps 1:1 to enum class Opcode
//   [23:20]  Target Reg (4 bits) — register bank index
//   [19:16]  Src Reg A (4 bits)  — first source register
//   [15:12]  Src Reg B (4 bits)  — second source register
//   [11:8]   Flags (4 bits)      — CavemanLevel, HWIntChannel, etc.
//   [7:0]    Immediate (8 bits)  — small inline constant
//
// For larger immediates, a trailing uint32_t follows the instruction.

struct A2AB_Instruction {
    uint32_t packed;

    constexpr A2AB_Instruction() : packed(0) {}

    constexpr A2AB_Instruction(uint8_t op, uint8_t tgt, uint8_t srcA, uint8_t srcB,
                                uint8_t flags, uint8_t imm)
        : packed((uint32_t(op) << 24) | (uint32_t(tgt) << 20) |
                 (uint32_t(srcA) << 16) | (uint32_t(srcB) << 12) |
                 (uint32_t(flags) << 8) | uint32_t(imm)) {}

    constexpr uint8_t Opcode()     const { return (packed >> 24) & 0xFF; }
    constexpr uint8_t TargetReg()  const { return (packed >> 20) & 0x0F; }
    constexpr uint8_t SrcRegA()    const { return (packed >> 16) & 0x0F; }
    constexpr uint8_t SrcRegB()    const { return (packed >> 12) & 0x0F; }
    constexpr uint8_t Flags()      const { return (packed >> 8)  & 0x0F; }
    constexpr uint8_t Immediate()  const { return  packed        & 0xFF; }
};

static_assert(sizeof(A2AB_Instruction) == 4, "A2AB_Instruction must be exactly 4 bytes");

// Bytecode arena — contiguous array of 32-bit instructions
// Uses 64x less memory than ASTArena (4 bytes/instruction vs 256 bytes/node)
template <size_t MaxCapacity = 512>
struct BytecodeArena {
    std::array<A2AB_Instruction, MaxCapacity> Instrs{};
    size_t Count{0};

    bool Emit(const A2AB_Instruction& instr) {
        if (Count >= MaxCapacity) return false;
        Instrs[Count++] = instr;
        return true;
    }

    void Clear() { Count = 0; }
};

// AST → Bytecode compiler: converts 256-byte ASTNodes into 4-byte instructions
// Called once at the MCP boundary, then the hot path uses BytecodeVM::Execute
struct BytecodeCompiler {
    template <size_t N>
    static size_t Compile(const ASTArena<N>& ast, BytecodeArena<512>& bc) {
        bc.Clear();
        for (size_t i = 0; i < ast.Count; ++i) {
            const ASTNode& node = ast.Nodes[i];
            uint8_t flags = static_cast<uint8_t>(node.caveman_lvl) & 0x0F;
            A2AB_Instruction instr(
                static_cast<uint8_t>(node.op),
                node.target_reg & 0x0F,
                node.src_reg_a & 0x0F,
                node.src_reg_b & 0x0F,
                flags,
                0
            );
            if (!bc.Emit(instr)) break;
        }
        return bc.Count;
    }
};

} // namespace A2A
