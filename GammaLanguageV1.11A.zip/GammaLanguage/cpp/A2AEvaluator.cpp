#include "A2AEvaluator.h"
#include <cmath>
#include <cstring>
#include <string_view>

namespace A2A {

float Evaluator::ComputeCosineSimSIMD(const std::array<uint16_t, 1536>& v1, const std::array<uint16_t, 1536>& v2) {
    // Vectorized SIMD unrolling (8 elements per loop iteration)
    double dot = 0.0;
    double norm1 = 0.0;
    double norm2 = 0.0;

    constexpr size_t VEC_SIZE = 1536;
    constexpr float INV_65535 = 1.0f / 65535.0f;

    // Unroll 8 elements per iteration for auto-vectorization & FMA optimization
    for (size_t i = 0; i < VEC_SIZE; i += 8) {
        float f1_0 = static_cast<float>(v1[i + 0]) * INV_65535;
        float f2_0 = static_cast<float>(v2[i + 0]) * INV_65535;
        float f1_1 = static_cast<float>(v1[i + 1]) * INV_65535;
        float f2_1 = static_cast<float>(v2[i + 1]) * INV_65535;
        float f1_2 = static_cast<float>(v1[i + 2]) * INV_65535;
        float f2_2 = static_cast<float>(v2[i + 2]) * INV_65535;
        float f1_3 = static_cast<float>(v1[i + 3]) * INV_65535;
        float f2_3 = static_cast<float>(v2[i + 3]) * INV_65535;

        float f1_4 = static_cast<float>(v1[i + 4]) * INV_65535;
        float f2_4 = static_cast<float>(v2[i + 4]) * INV_65535;
        float f1_5 = static_cast<float>(v1[i + 5]) * INV_65535;
        float f2_5 = static_cast<float>(v2[i + 5]) * INV_65535;
        float f1_6 = static_cast<float>(v1[i + 6]) * INV_65535;
        float f2_6 = static_cast<float>(v2[i + 6]) * INV_65535;
        float f1_7 = static_cast<float>(v1[i + 7]) * INV_65535;
        float f2_7 = static_cast<float>(v2[i + 7]) * INV_65535;

        dot += (f1_0 * f2_0) + (f1_1 * f2_1) + (f1_2 * f2_2) + (f1_3 * f2_3) +
               (f1_4 * f2_4) + (f1_5 * f2_5) + (f1_6 * f2_6) + (f1_7 * f2_7);

        norm1 += (f1_0 * f1_0) + (f1_1 * f1_1) + (f1_2 * f1_2) + (f1_3 * f1_3) +
                 (f1_4 * f1_4) + (f1_5 * f1_5) + (f1_6 * f1_6) + (f1_7 * f1_7);

        norm2 += (f2_0 * f2_0) + (f2_1 * f2_1) + (f2_2 * f2_2) + (f2_3 * f2_3) +
                 (f2_4 * f2_4) + (f2_5 * f2_5) + (f2_6 * f2_6) + (f2_7 * f2_7);
    }

    if (norm1 == 0.0 || norm2 == 0.0) return 0.0f;
    return static_cast<float>(dot / (std::sqrt(norm1) * std::sqrt(norm2)));
}

bool Evaluator::EvaluateInvariant(const ASTNode& node, RegisterBank& registers) {
    std::string_view payload(node.payload_str);
    if (payload.find("TURBOQUANT_RAM_UTIL") != std::string_view::npos) {
        if (registers.TurboQuantRamUtil > 0.65f) {
            return false;
        }
    }
    return true;
}

float Evaluator::ComputeQVecCosineSim(const std::array<uint8_t, 1536>& v1, const std::array<uint8_t, 1536>& v2) {
    double dot = 0.0;
    double norm1 = 0.0;
    double norm2 = 0.0;
    constexpr float INV_255 = 1.0f / 255.0f;

    for (size_t i = 0; i < 1536; ++i) {
        float f1 = static_cast<float>(v1[i]) * INV_255;
        float f2 = static_cast<float>(v2[i]) * INV_255;
        dot += f1 * f2;
        norm1 += f1 * f1;
        norm2 += f2 * f2;
    }

    if (norm1 == 0.0 || norm2 == 0.0) return 0.0f;
    return static_cast<float>(dot / (std::sqrt(norm1) * std::sqrt(norm2)));
}

} // namespace A2A
