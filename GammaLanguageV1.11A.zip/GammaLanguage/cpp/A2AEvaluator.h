#pragma once
#include "A2AST.h"
#include "A2AGPUCompute.h"

namespace A2A {

struct ExecutionResult {
    bool Success{true};
    FaultCode Fault{FaultCode::NONE};
    uint8_t ExitCode{0};
    char Message[256]{"OK"};
    uint32_t InvariantsChecked{0};
    uint32_t InstructionsExecuted{0};

    void SetMessage(const char* msg) {
        std::strncpy(Message, msg, sizeof(Message) - 1);
        Message[sizeof(Message) - 1] = '\0';
    }
    void SetMessage(const char* prefix, const char* payload) {
        std::snprintf(Message, sizeof(Message), "%s: %s", prefix, payload);
    }
};

class Evaluator {
public:
    explicit Evaluator(uint32_t max_cycles = 1000) : m_max_cycles(max_cycles) {}

    void SetComputeDevice(const GPUDevice& device) {
        // GPU offload not yet implemented — Vulkan initialization is a stub.
        // m_gpu.InitializeVulkan() would set is_initialized=true without
        // actually creating a Vulkan device, so we skip it and use the
        // software fallback path in ComputeCosineSim.
    }

    template <size_t N>
    ExecutionResult Execute(const ASTArena<N>& arena, RegisterBank& registers) {
        ExecutionResult res{};

        for (size_t i = 0; i < arena.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.ExitCode = static_cast<uint8_t>(FaultCode::INSTRUCTION_BUDGET);
                res.SetMessage("Instruction cycle budget limit exceeded");
                return res;
            }

            const ASTNode& node = arena.Nodes[i];

            switch (node.op) {
                case Opcode::STATE_DECL:
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Target declaration
                case Opcode::TARGET_DECL:
                    registers.ActiveTargetIndex = 1; // Mark target as set
                    res.InstructionsExecuted++;
                    break;

                case Opcode::TARGET_DEFINE:
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Skill management
                case Opcode::SKILL_EQUIP:
                    // Mark skill slot as occupied (conceptual)
                    if (registers.Skl[0] == 0) registers.Skl[0] = 1;
                    else if (registers.Skl[1] == 0) registers.Skl[1] = 1;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SKILL_UNLOAD:
                    // Clear last occupied skill slot
                    if (registers.Skl[3] != 0) registers.Skl[3] = 0;
                    else if (registers.Skl[2] != 0) registers.Skl[2] = 0;
                    else if (registers.Skl[1] != 0) registers.Skl[1] = 0;
                    else if (registers.Skl[0] != 0) registers.Skl[0] = 0;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::PROFILE_SWAP:
                    // Reset all skills then mark first as active
                    registers.Skl.fill(0);
                    registers.Skl[0] = 1;
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Hive selection
                case Opcode::HIVE_SELECT:
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Research delegation
                case Opcode::ZHARK_QUERY:
                    // Async research dispatch — non-blocking
                    res.InstructionsExecuted++;
                    break;

                case Opcode::FUBBU_SYNC:
                    // Context compression — conceptual
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Concurrency guards
                case Opcode::LOCK_ACQUIRE:
                    // Acquire mutex on resource (conceptual — store in LCK[0])
                    if (registers.Lck[0] == 0) {
                        registers.Lck[0] = 1; // Locked
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::SCHEMA_DRIFT;
                        res.SetMessage("LOCK_ACQUIRE: Resource already locked");
                        return res;
                    }
                    break;

                case Opcode::LOCK_RELEASE:
                    registers.Lck[0] = 0; // Unlocked
                    res.InstructionsExecuted++;
                    break;

                case Opcode::BARRIER_WAIT:
                case Opcode::SYNC_WAIT:
                    // Non-blocking in single-agent mode — just count
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Error recovery
                case Opcode::ON_ERROR_BLOCK:
                    // Store error block for potential retry — conceptual
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SHIFT_TARGET:
                    // Shift to fallback target
                    registers.ActiveTargetIndex = 2; // GDI_DIB fallback
                    res.InstructionsExecuted++;
                    break;

                case Opcode::RETRY:
                    if (registers.RetryCount < registers.MaxRetries) {
                        registers.RetryCount++;
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::INSTRUCTION_BUDGET;
                        res.SetMessage("RETRY: Max retries exceeded");
                        return res;
                    }
                    break;

                // v1.1A: Native bridge
                case Opcode::NATIVE_BRIDGE:
                    res.InstructionsExecuted++;
                    break;

                // PEAK-2: Quantized vector load (8-bit)
                case Opcode::QVEC_LOAD:
                    // Quantize FP16 vector into 8-bit: scale to [0,255]
                    if (node.target_reg < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            registers.QVec[node.target_reg][j] =
                                static_cast<uint8_t>(registers.Vec[node.target_reg][j] >> 8);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-2: Vector delta update — apply differential to quantized vector
                case Opcode::VEC_DELTA:
                    if (node.target_reg < 8 && node.src_reg_a < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            int32_t delta = static_cast<int32_t>(registers.QVec[node.src_reg_a][j]) -
                                            static_cast<int32_t>(registers.QVec[node.target_reg][j]);
                            registers.QVec[node.target_reg][j] =
                                static_cast<uint8_t>(delta & 0xFF);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-3: Speculative pipeline branching
                case Opcode::PREDICT_BLOCK:
                    // Save checkpoint for potential rollback
                    registers.SpecBuf.Active = true;
                    registers.SpecBuf.Committed = false;
                    registers.SpecBuf.StartPC = static_cast<uint32_t>(i + 1);
                    registers.SpecBuf.SavedRetryCount = registers.RetryCount;
                    registers.SpecBuf.SavedTargetIndex = registers.ActiveTargetIndex;
                    registers.SpecBuf.SavedLck = registers.Lck;
                    registers.SpecBuf.SavedSig = registers.Sig;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_COMMIT:
                    // Speculative results validated — commit them
                    registers.SpecBuf.Active = false;
                    registers.SpecBuf.Committed = true;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_ROLLBACK:
                    // Invariant failed — restore saved state atomically
                    if (registers.SpecBuf.Active) {
                        registers.RetryCount = registers.SpecBuf.SavedRetryCount;
                        registers.ActiveTargetIndex = registers.SpecBuf.SavedTargetIndex;
                        registers.Lck = registers.SpecBuf.SavedLck;
                        registers.Sig = registers.SpecBuf.SavedSig;
                        registers.SpecBuf.Active = false;
                        registers.SpecBuf.Committed = false;
                        res.InstructionsExecuted++;
                        res.SetMessage("SPEC_ROLLBACK: Speculative buffer discarded, state restored");
                    }
                    break;

                // PEAK-4: Hardware interrupt frame-sync
                case Opcode::HW_INTERRUPT:
                    // Map signal to hardware timing channel
                    {
                        std::string_view payload(node.payload_str);
                        if (payload.find("VBLANK") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::VBLANK;
                        else if (payload.find("DMA_CH1") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::DMA_CH1;
                        else if (payload.find("AUDIO_SWAP") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::AUDIO_SWAP;
                        else if (payload.find("RENDER_DONE") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::RENDER_DONE;
                        else
                            registers.PendingInt = HWIntChannel::NONE;
                        registers.FrameCount++;
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-5: Sliding-window context eviction
                case Opcode::EVICT_SLIDING:
                    // Prune stale context from CTX ring buffer
                    {
                        std::string_view payload(node.payload_str);
                        // Parse SPAN= and STRIDE= from payload if present
                        size_t span_pos = payload.find("SPAN=");
                        if (span_pos != std::string_view::npos) {
                            uint16_t val = 0;
                            for (size_t j = span_pos + 5; j < payload.size() && payload[j] >= '0' && payload[j] <= '9'; ++j)
                                val = val * 10 + static_cast<uint16_t>(payload[j] - '0');
                            if (val > 0) registers.EvictSpan = val;
                        }
                        size_t stride_pos = payload.find("STRIDE=");
                        if (stride_pos != std::string_view::npos) {
                            uint16_t val = 0;
                            for (size_t j = stride_pos + 7; j < payload.size() && payload[j] >= '0' && payload[j] <= '9'; ++j)
                                val = val * 10 + static_cast<uint16_t>(payload[j] - '0');
                            if (val > 0) registers.EvictStride = val;
                        }
                        // Advance ring-buffer write position by stride, wrapping at span
                        for (int c = 0; c < 4; ++c) {
                            registers.CtxWritePos[c] = static_cast<uint16_t>(
                                (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::INVARIANT_GUARD:
                    res.InvariantsChecked++;
                    if (!EvaluateInvariant(node, registers)) {
                        res.Success = false;
                        res.Fault = FaultCode::MEMORY_LIMIT_EXCEEDED;
                        res.ExitCode = static_cast<uint8_t>(FaultCode::MEMORY_LIMIT_EXCEEDED);
                        res.SetMessage("Invariant violation: TurboQuant RAM threshold exceeded (0xE1)");
                        return res;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::COLIBRI_PIN:
                    registers.ActiveExpertIndex = 1; // Pinned
                    res.InstructionsExecuted++;
                    break;

                case Opcode::CAVEMAN_SHRINK: {
                    // Not implemented: Caveman compression (filler-word stripping, level-based
                    // reduction) is not yet built in C++. As a passthrough, copy the payload
                    // verbatim to the target CTX register so downstream consumers see real data.
                    // caveman_lvl is parsed by the lexer but not yet applied here.
                    uint8_t target_ctx = (node.target_reg < 4) ? node.target_reg : 0;
                    std::strncpy(registers.Ctx[target_ctx].data(), node.payload_str, registers.Ctx[target_ctx].size() - 1);
                    registers.Ctx[target_ctx][registers.Ctx[target_ctx].size() - 1] = '\0';
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::COSINE_SIM:
                    // PRO OPTIMIZATION: GPU Offload
                    registers.Reg[0] = static_cast<int64_t>(m_gpu.ComputeCosineSim(registers.Vec[0], registers.Vec[1]) * 1000.0f);
                    res.InstructionsExecuted++;
                    break;

                case Opcode::EMIT_SIGNAL:
                    res.InstructionsExecuted++;
                    res.SetMessage("EMIT_SIGNAL", node.payload_str);
                    break;

                case Opcode::ABORT_TRANSITION:
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.ExitCode = static_cast<uint8_t>(FaultCode::SCHEMA_DRIFT);
                    res.SetMessage("ABORT_TRANSITION", node.payload_str);
                    return res;

                // v1.1C: Rust FFI — Load struct offset pointer into HW register
                case Opcode::RUST_OFFSET_LOAD: {
                    RustOffsetFlags rof;
                    rof.packed = static_cast<uint32_t>(node.int_imm);
                    if (node.target_reg < 8) {
                        registers.Hw[node.target_reg] = rof.OffsetAddr();
                    }
                    registers.Reg[0] = static_cast<int64_t>(rof.packed);
                    res.InstructionsExecuted++;
                    break;
                }

                // v1.1C: Rust FFI — Invoke PEAK subsystem via dispatch table
                case Opcode::RUST_FFI_CALL: {
                    RustFFIExport desc{};
                    desc.DataPtr = &registers;
                    desc.DataSize = static_cast<uint32_t>(sizeof(RegisterBank));
                    desc.ElementSize = static_cast<uint32_t>(sizeof(RegisterBank));
                    desc.Repr = RustReprType::REPR_ALIGN;
                    desc.Flags = RustOffsetFlag::UNSAFE_PTR;
                    std::string_view payload(node.payload_str);
                    size_t comma = payload.find(',');
                    if (comma != std::string_view::npos) {
                        size_t len = (comma < sizeof(desc.StructName) - 1) ? comma : sizeof(desc.StructName) - 1;
                        std::memcpy(desc.StructName, payload.data(), len);
                        desc.StructName[len] = '\0';
                        size_t fieldStart = comma + 1;
                        size_t fieldLen = payload.size() - fieldStart;
                        if (fieldLen > sizeof(desc.FieldName) - 1) fieldLen = sizeof(desc.FieldName) - 1;
                        std::memcpy(desc.FieldName, payload.data() + fieldStart, fieldLen);
                        desc.FieldName[fieldLen] = '\0';
                    }
                    // Dispatch to PEAK subsystem based on target_reg
                    switch (node.target_reg) {
                        case 0: // PEAK-1: Bytecode export
                            if (registers.FFITable.Peak1_ExportBytecode)
                                registers.FFITable.Peak1_ExportBytecode(&desc);
                            break;
                        case 1: // PEAK-2: QVec SIMD
                            if (registers.FFITable.Peak2_QVecSimd)
                                registers.FFITable.Peak2_QVecSimd(&desc, static_cast<uint8_t>(node.src_reg_a));
                            break;
                        case 2: // PEAK-3: Speculative scope
                            if (registers.FFITable.Peak3_SpecScope)
                                registers.FFITable.Peak3_SpecScope(&desc, static_cast<uint8_t>(node.src_reg_a));
                            break;
                        case 3: // PEAK-4: HW interrupt bridge
                            if (registers.FFITable.Peak4_HwIntBridge)
                                registers.FFITable.Peak4_HwIntBridge(&desc, static_cast<uint8_t>(node.src_reg_a));
                            break;
                        case 4: // PEAK-5: Ring buffer iterator
                            if (registers.FFITable.Peak5_RingIter)
                                registers.FFITable.Peak5_RingIter(&desc, registers.EvictSpan, registers.EvictStride);
                            break;
                        default: // Generic FFI
                            if (registers.FFITable.GenericFFI)
                                registers.FFITable.GenericFFI(&desc, static_cast<uint32_t>(node.int_imm));
                            break;
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                // v1.1C: Enforce memory alignment boundary
                case Opcode::ALIGN_BOUND: {
                    uint32_t bound = static_cast<uint32_t>(node.int_imm);
                    if (bound == 0) bound = 64; // Default cache-line alignment
                    registers.AlignBound = bound;
                    // Verify HW[target_reg] is aligned to bound
                    if (node.target_reg < 8) {
                        uint64_t addr = registers.Hw[node.target_reg];
                        if (addr % bound != 0) {
                            // Round up to next boundary
                            registers.Hw[node.target_reg] = (addr + bound - 1) & ~(uint64_t)(bound - 1);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                // v1.1C: CyberGrime CP0 register → HW[0..7] mapping
                case Opcode::CP0_REG_MAP: {
                    // src_reg_a selects CP0 register, target_reg selects HW slot
                    std::string_view payload(node.payload_str);
                    if (node.target_reg < 8) {
                        // Parse CP0 register name from payload
                        if (payload.find("Status") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_Status;
                        else if (payload.find("Cause") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_Cause;
                        else if (payload.find("EPC") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_EPC;
                        else if (payload.find("BadVAddr") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_BadVAddr;
                        else if (payload.find("Count") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_Count;
                        else if (payload.find("Compare") != std::string_view::npos)
                            registers.Hw[node.target_reg] = registers.CP0Map.CP0_Compare;
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                // v1.1C: PSXMatrix DMA channel dispatch via FFI
                case Opcode::PSX_DMA_DISPATCH: {
                    // target_reg selects DMA channel (0=CH1_CDROM, 1=CH2_GPU)
                    std::string_view payload(node.payload_str);
                    RustFFIExport dma_desc{};
                    dma_desc.DataPtr = &registers.PSXRegs;
                    dma_desc.DataSize = sizeof(PSXHwRegMap);
                    dma_desc.Repr = RustReprType::REPR_C;
                    dma_desc.Flags = RustOffsetFlag::DMA_MAPPED | RustOffsetFlag::VOLATILE;
                    if (node.target_reg == 0) {
                        // DMA CH1 (CD-ROM) — route through @PREDICT speculative buffer
                        std::memcpy(dma_desc.StructName, "PSXHwRegMap", 11);
                        std::memcpy(dma_desc.FieldName, "DMA_CH1_MADR", 12);
                        dma_desc.OffsetAddr = 0; // Offset into PSXHwRegMap
                        if (registers.SpecBuf.Active) {
                            // Speculative: queue DMA in buffer, don't commit
                            registers.Reg[1] = static_cast<int64_t>(registers.PSXRegs.DMA_CH1_MADR);
                        } else {
                            // Direct dispatch via FFI
                            if (registers.FFITable.Peak4_HwIntBridge)
                                registers.FFITable.Peak4_HwIntBridge(&dma_desc, static_cast<uint8_t>(HWIntChannel::DMA_CH1));
                        }
                    } else if (node.target_reg == 1) {
                        // DMA CH2 (GPU) — VRAM transfer
                        std::memcpy(dma_desc.StructName, "PSXHwRegMap", 11);
                        std::memcpy(dma_desc.FieldName, "DMA_CH2_MADR", 12);
                        dma_desc.OffsetAddr = 12; // Offset to CH2 fields
                        if (registers.FFITable.Peak4_HwIntBridge)
                            registers.FFITable.Peak4_HwIntBridge(&dma_desc, static_cast<uint8_t>(HWIntChannel::VBLANK));
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }

        return res;
    }

private:
    bool EvaluateInvariant(const ASTNode& node, RegisterBank& registers);
    float ComputeCosineSimSIMD(const std::array<uint16_t, 1536>& v1, const std::array<uint16_t, 1536>& v2);
    // PEAK-2: Quantized cosine similarity using 8-bit QVec registers
    float ComputeQVecCosineSim(const std::array<uint8_t, 1536>& v1, const std::array<uint8_t, 1536>& v2);
    
    uint32_t m_max_cycles{1000};
    GPUComputeEngine m_gpu;
    AST_Memoizer m_memoizer;

public:
    // PEAK-1: Direct Threaded Code execution of A2A-B bytecode
    // Eliminates string lexing overhead — operates on 4-byte packed instructions
    ExecutionResult ExecuteBytecode(const BytecodeArena<512>& bc, RegisterBank& registers) {
        ExecutionResult res{};

        // Direct threaded code: function pointer jump table indexed by opcode
        // Each handler is a simple register operation — no string parsing on hot path
        for (size_t i = 0; i < bc.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.SetMessage("Bytecode cycle budget exceeded");
                return res;
            }

            const A2AB_Instruction& instr = bc.Instrs[i];
            uint8_t op = instr.Opcode();

            // Jump table dispatch — compiler can optimize to computed goto
            switch (op) {
                case static_cast<uint8_t>(Opcode::STATE_DECL):
                case static_cast<uint8_t>(Opcode::TARGET_DECL):
                case static_cast<uint8_t>(Opcode::TARGET_DEFINE):
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::INVARIANT_GUARD):
                    res.InvariantsChecked++;
                    // Fast path: check TurboQuant RAM inline
                    if (registers.TurboQuantRamUtil > 0.65f) {
                        res.Success = false;
                        res.Fault = FaultCode::MEMORY_LIMIT_EXCEEDED;
                        res.SetMessage("Bytecode invariant violation (0xE1)");
                        return res;
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::COLIBRI_PIN):
                    registers.ActiveExpertIndex = instr.TargetReg();
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SKILL_EQUIP):
                    if (registers.Skl[0] == 0) registers.Skl[0] = 1;
                    else if (registers.Skl[1] == 0) registers.Skl[1] = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SKILL_UNLOAD):
                    for (int j = 3; j >= 0; --j) {
                        if (registers.Skl[j] != 0) { registers.Skl[j] = 0; break; }
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::QVEC_LOAD):
                    if (instr.TargetReg() < 8) {
                        for (size_t j = 0; j < 1536; ++j)
                            registers.QVec[instr.TargetReg()][j] =
                                static_cast<uint8_t>(registers.Vec[instr.TargetReg()][j] >> 8);
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::VEC_DELTA):
                    if (instr.TargetReg() < 8 && instr.SrcRegA() < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            int32_t delta = static_cast<int32_t>(registers.QVec[instr.SrcRegA()][j]) -
                                            static_cast<int32_t>(registers.QVec[instr.TargetReg()][j]);
                            registers.QVec[instr.TargetReg()][j] = static_cast<uint8_t>(delta & 0xFF);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::COSINE_SIM):
                    // PEAK-2: Use quantized path when possible
                    registers.Reg[0] = static_cast<int64_t>(
                        ComputeQVecCosineSim(registers.QVec[0], registers.QVec[1]) * 1000.0f);
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::PREDICT_BLOCK):
                    registers.SpecBuf.Active = true;
                    registers.SpecBuf.Committed = false;
                    registers.SpecBuf.StartPC = static_cast<uint32_t>(i + 1);
                    registers.SpecBuf.SavedRetryCount = registers.RetryCount;
                    registers.SpecBuf.SavedTargetIndex = registers.ActiveTargetIndex;
                    registers.SpecBuf.SavedLck = registers.Lck;
                    registers.SpecBuf.SavedSig = registers.Sig;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SPEC_COMMIT):
                    registers.SpecBuf.Active = false;
                    registers.SpecBuf.Committed = true;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SPEC_ROLLBACK):
                    if (registers.SpecBuf.Active) {
                        registers.RetryCount = registers.SpecBuf.SavedRetryCount;
                        registers.ActiveTargetIndex = registers.SpecBuf.SavedTargetIndex;
                        registers.Lck = registers.SpecBuf.SavedLck;
                        registers.Sig = registers.SpecBuf.SavedSig;
                        registers.SpecBuf.Active = false;
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::HW_INTERRUPT):
                    registers.PendingInt = static_cast<HWIntChannel>(instr.Flags() & 0x0F);
                    registers.FrameCount++;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EVICT_SLIDING):
                    for (int c = 0; c < 4; ++c) {
                        registers.CtxWritePos[c] = static_cast<uint16_t>(
                            (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan);
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_ACQUIRE):
                    if (registers.Lck[instr.TargetReg() & 0x03] == 0) {
                        registers.Lck[instr.TargetReg() & 0x03] = 1;
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::SCHEMA_DRIFT;
                        res.SetMessage("Bytecode LOCK_ACQUIRE: already locked");
                        return res;
                    }
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_RELEASE):
                    registers.Lck[instr.TargetReg() & 0x03] = 0;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EMIT_SIGNAL):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::ABORT_TRANSITION):
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.SetMessage("Bytecode ABORT_TRANSITION");
                    return res;

                // v1.1C: Rust FFI bytecode handlers
                case static_cast<uint8_t>(Opcode::RUST_OFFSET_LOAD): {
                    RustOffsetFlags rof;
                    rof.packed = instr.Immediate() << 16 | instr.Flags();
                    if (instr.TargetReg() < 8)
                        registers.Hw[instr.TargetReg()] = rof.OffsetAddr();
                    res.InstructionsExecuted++;
                    break;
                }

                case static_cast<uint8_t>(Opcode::RUST_FFI_CALL): {
                    RustFFIExport desc{};
                    desc.DataPtr = &registers;
                    desc.DataSize = static_cast<uint32_t>(sizeof(RegisterBank));
                    desc.Repr = RustReprType::REPR_ALIGN;
                    desc.Flags = RustOffsetFlag::UNSAFE_PTR;
                    switch (instr.TargetReg()) {
                        case 0: if (registers.FFITable.Peak1_ExportBytecode) registers.FFITable.Peak1_ExportBytecode(&desc); break;
                        case 1: if (registers.FFITable.Peak2_QVecSimd) registers.FFITable.Peak2_QVecSimd(&desc, instr.SrcRegA()); break;
                        case 2: if (registers.FFITable.Peak3_SpecScope) registers.FFITable.Peak3_SpecScope(&desc, instr.SrcRegA()); break;
                        case 3: if (registers.FFITable.Peak4_HwIntBridge) registers.FFITable.Peak4_HwIntBridge(&desc, instr.SrcRegA()); break;
                        case 4: if (registers.FFITable.Peak5_RingIter) registers.FFITable.Peak5_RingIter(&desc, registers.EvictSpan, registers.EvictStride); break;
                        default: if (registers.FFITable.GenericFFI) registers.FFITable.GenericFFI(&desc, instr.Immediate()); break;
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case static_cast<uint8_t>(Opcode::ALIGN_BOUND): {
                    uint32_t bound = instr.Immediate();
                    if (bound == 0) bound = 64;
                    registers.AlignBound = bound;
                    if (instr.TargetReg() < 8) {
                        uint64_t addr = registers.Hw[instr.TargetReg()];
                        if (addr % bound != 0)
                            registers.Hw[instr.TargetReg()] = (addr + bound - 1) & ~(uint64_t)(bound - 1);
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case static_cast<uint8_t>(Opcode::CP0_REG_MAP): {
                    if (instr.TargetReg() < 8) {
                        uint8_t cp0_idx = instr.SrcRegA();
                        switch (cp0_idx) {
                            case 0: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_Status; break;
                            case 1: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_Cause; break;
                            case 2: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_EPC; break;
                            case 3: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_BadVAddr; break;
                            case 4: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_Count; break;
                            case 5: registers.Hw[instr.TargetReg()] = registers.CP0Map.CP0_Compare; break;
                        }
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case static_cast<uint8_t>(Opcode::PSX_DMA_DISPATCH): {
                    RustFFIExport dma_desc{};
                    dma_desc.DataPtr = &registers.PSXRegs;
                    dma_desc.DataSize = sizeof(PSXHwRegMap);
                    dma_desc.Repr = RustReprType::REPR_C;
                    dma_desc.Flags = RustOffsetFlag::DMA_MAPPED | RustOffsetFlag::VOLATILE;
                    if (instr.TargetReg() == 0) {
                        if (registers.SpecBuf.Active)
                            registers.Reg[1] = static_cast<int64_t>(registers.PSXRegs.DMA_CH1_MADR);
                        else if (registers.FFITable.Peak4_HwIntBridge)
                            registers.FFITable.Peak4_HwIntBridge(&dma_desc, static_cast<uint8_t>(HWIntChannel::DMA_CH1));
                    } else if (instr.TargetReg() == 1) {
                        if (registers.FFITable.Peak4_HwIntBridge)
                            registers.FFITable.Peak4_HwIntBridge(&dma_desc, static_cast<uint8_t>(HWIntChannel::VBLANK));
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }
        return res;
    }
};

} // namespace A2A
