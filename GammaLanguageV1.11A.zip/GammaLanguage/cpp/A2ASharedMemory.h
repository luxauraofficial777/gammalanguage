#pragma once
#include "A2AST.h"
#include <string>
#include <cstdint>

#ifdef _WIN32
#include <windows.h>
#endif

namespace A2A {

// Ring buffer capacity (number of ASTNodes)
constexpr size_t RING_BUFFER_CAPACITY = 1024;

struct AST_RingBuffer {
    uint32_t head;
    uint32_t tail;
    ASTNode nodes[RING_BUFFER_CAPACITY];
};

class SharedMemoryBus {
public:
    SharedMemoryBus(const std::string& name);
    ~SharedMemoryBus();

    bool Initialize(bool create);
    bool Write(const ASTNode& node);
    bool Read(ASTNode& out_node);

private:
    std::string m_name;
#ifdef _WIN32
    HANDLE m_hMapFile{nullptr};
#endif
    AST_RingBuffer* m_buffer{nullptr};
};

} // namespace A2A
