//! GammaLanguage v1.1C — Rust FFI Binding Layer
//!
//! Zero-copy FFI bridge between the C++ A2A VM (A2AEvaluator.h) and Rust crates.
//! Provides PEAK-1 through PEAK-5 subsystem access with repr(C) parity.
//!
//! ## Architecture
//!
//! The C++ VM exports `RegisterBank` and `BytecodeArena` pointers via
//! `RustFFIExport` descriptors. This crate wraps those raw pointers in
//! safe Rust abstractions, mapping each PEAK subsystem to idiomatic Rust patterns:
//!
//! - PEAK-1: `*const u32` DTC jump table export
//! - PEAK-2: SIMD-accelerated QVec operations (x86_64/NEON)
//! - PEAK-3: `SpeculativeScope` RAII guard (auto commit/rollback on Drop)
//! - PEAK-4: Async hardware interrupt bridge
//! - PEAK-5: Safe ring-buffer iterator with modular wrap arithmetic

#![allow(non_camel_case_types)]

use std::ffi::c_void;
use std::marker::PhantomData;
use std::ptr::NonNull;

// ===================================================================
// repr(C) Parity Types — mirror C++ structs exactly for zero-copy FFI
// ===================================================================

/// Rust representation type — controls struct layout parity
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RustReprType {
    REPR_C = 0x0,
    REPR_PACKED = 0x1,
    REPR_ALIGN = 0x2,
    REPR_TRANSPARENT = 0x3,
}

/// Rust offset flag semantics
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RustOffsetFlag {
    NONE = 0x0,
    READ_ONLY = 0x1,
    VOLATILE = 0x2,
    UNSAFE_PTR = 0x4,
    DMA_MAPPED = 0x8,
}

/// 32-bit Rust offset flag bitfield
/// Layout: [31:28] Flag | [27:24] ReprType | [23:0] OffsetAddr
#[repr(C, packed)]
#[derive(Debug, Clone, Copy)]
pub struct RustOffsetFlags {
    pub packed: u32,
}

impl RustOffsetFlags {
    pub const fn new(flag: u8, repr: RustReprType, offset: u32) -> Self {
        Self {
            packed: ((flag as u32 & 0x0F) << 28)
                | ((repr as u32) << 24)
                | (offset & 0x00FFFFFF),
        }
    }

    #[inline]
    pub const fn flag(&self) -> u8 {
        ((self.packed >> 28) & 0x0F) as u8
    }

    #[inline]
    pub const fn repr_type(&self) -> u8 {
        ((self.packed >> 24) & 0x0F) as u8
    }

    #[inline]
    pub const fn offset_addr(&self) -> u32 {
        self.packed & 0x00FFFFFF
    }
}

/// Zero-copy FFI export descriptor — passed from C++ as *const pointer
/// Must match `struct alignas(16) RustFFIExport` in A2AST.h (96 bytes)
/// Layout: 8(ptr) + 4 + 4 + 1 + 1 + 2(pad) + 4 + 32 + 32 = 88, align(16) → 96
#[repr(C, align(16))]
#[derive(Debug, Clone, Copy)]
pub struct GammaFFIExport {
    pub data_ptr: *const c_void,
    pub data_size: u32,
    pub element_size: u32,
    pub repr: u8,    // RustReprType as raw u8
    pub flags: u8,   // RustOffsetFlag as raw u8
    pub _pad: [u8; 2],
    pub offset_addr: u32,
    pub struct_name: [u8; 32],
    pub field_name: [u8; 32],
}

const _: () = assert!(std::mem::size_of::<GammaFFIExport>() == 96);

impl GammaFFIExport {
    /// Get the struct name as a Rust string slice
    pub fn struct_name_str(&self) -> &str {
        let end = self.struct_name.iter().position(|&b| b == 0).unwrap_or(32);
        std::str::from_utf8(&self.struct_name[..end]).unwrap_or("<invalid>")
    }

    /// Get the field name as a Rust string slice
    pub fn field_name_str(&self) -> &str {
        let end = self.field_name.iter().position(|&b| b == 0).unwrap_or(32);
        std::str::from_utf8(&self.field_name[..end]).unwrap_or("<invalid>")
    }
}

// ===================================================================
// FFI Dispatch Table — mirrors C++ RustFFIDispatchTable
// ===================================================================

/// Type for PEAK-1 bytecode export callback
pub type Peak1ExportBytecodeFn = extern "C" fn(*const GammaFFIExport);
/// Type for PEAK-2 QVec SIMD callback
pub type Peak2QVecSimdFn = extern "C" fn(*const GammaFFIExport, u8);
/// Type for PEAK-3 speculative scope callback
pub type Peak3SpecScopeFn = extern "C" fn(*const GammaFFIExport, u8);
/// Type for PEAK-4 HW interrupt bridge callback
pub type Peak4HwIntBridgeFn = extern "C" fn(*const GammaFFIExport, u8);
/// Type for PEAK-5 ring buffer iterator callback
pub type Peak5RingIterFn = extern "C" fn(*const GammaFFIExport, u16, u16);
/// Type for generic FFI callback
pub type GenericFFIFn = extern "C" fn(*const GammaFFIExport, u32);

/// FFI dispatch table — maps PEAK subsystem to function pointers
#[repr(C, align(64))]
#[derive(Debug, Clone, Copy)]
pub struct RustFFIDispatchTable {
    pub peak1_export_bytecode: Option<Peak1ExportBytecodeFn>,
    pub peak2_qvec_simd: Option<Peak2QVecSimdFn>,
    pub peak3_spec_scope: Option<Peak3SpecScopeFn>,
    pub peak4_hw_int_bridge: Option<Peak4HwIntBridgeFn>,
    pub peak5_ring_iter: Option<Peak5RingIterFn>,
    pub generic_ffi: Option<GenericFFIFn>,
}

// ===================================================================
// PEAK-1: A2A-B Bytecode Arena Export
// ===================================================================

/// Safe wrapper around a bytecode arena exported from C++
pub struct BytecodeArenaView<'a> {
    ptr: NonNull<u32>,
    count: usize,
    _marker: PhantomData<&'a [u32]>,
}

impl<'a> BytecodeArenaView<'a> {
    /// Create from an FFI export descriptor
    pub unsafe fn from_ffi(desc: &GammaFFIExport) -> Option<Self> {
        if desc.data_ptr.is_null() || desc.element_size != 4 {
            return None;
        }
        let ptr = NonNull::new(desc.data_ptr as *mut u32)?;
        let count = (desc.data_size / desc.element_size) as usize;
        Some(Self {
            ptr,
            count,
            _marker: PhantomData,
        })
    }

    /// Get the bytecode instructions as a slice
    pub fn instructions(&self) -> &[u32] {
        unsafe { std::slice::from_raw_parts(self.ptr.as_ptr(), self.count) }
    }

    /// Direct pointer for Rust DTC jump table construction
    pub fn as_ptr(&self) -> *const u32 {
        self.ptr.as_ptr()
    }

    /// Decode a single A2A-B instruction
    pub fn decode(&self, index: usize) -> Option<A2ABDecoded> {
        let instrs = self.instructions();
        if index >= instrs.len() {
            return None;
        }
        let packed = instrs[index];
        Some(A2ABDecoded {
            opcode: ((packed >> 24) & 0xFF) as u8,
            target_reg: ((packed >> 20) & 0x0F) as u8,
            src_reg_a: ((packed >> 16) & 0x0F) as u8,
            src_reg_b: ((packed >> 12) & 0x0F) as u8,
            flags: ((packed >> 8) & 0x0F) as u8,
            immediate: (packed & 0xFF) as u8,
        })
    }
}

/// Decoded A2A-B instruction
#[derive(Debug, Clone, Copy)]
pub struct A2ABDecoded {
    pub opcode: u8,
    pub target_reg: u8,
    pub src_reg_a: u8,
    pub src_reg_b: u8,
    pub flags: u8,
    pub immediate: u8,
}

// ===================================================================
// PEAK-2: QVec SIMD Wrapper Functions
// ===================================================================

/// QVec operation types for SIMD dispatch
#[repr(u8)]
#[derive(Debug, Clone, Copy)]
pub enum QVecOp {
    Load = 0,
    Delta = 1,
    CosineSim = 2,
    DotProduct = 3,
}

/// QVec register — 1536 bytes of 8-bit quantized values
pub const QVEC_SIZE: usize = 1536;
pub type QVec = [u8; QVEC_SIZE];

/// Quantize a FP16 vector (u16) into 8-bit QVec
#[inline]
pub fn quantize_fp16_to_qvec(fp16_vec: &[u16; QVEC_SIZE]) -> QVec {
    let mut qvec = [0u8; QVEC_SIZE];
    for i in 0..QVEC_SIZE {
        qvec[i] = (fp16_vec[i] >> 8) as u8;
    }
    qvec
}

/// Compute differential delta between two QVec registers
#[inline]
pub fn qvec_delta(a: &QVec, b: &QVec) -> QVec {
    let mut result = [0u8; QVEC_SIZE];
    for i in 0..QVEC_SIZE {
        let delta = a[i] as i32 - b[i] as i32;
        result[i] = (delta & 0xFF) as u8;
    }
    result
}

/// SIMD-accelerated cosine similarity for QVec registers (x86_64 SSE2)
#[cfg(target_arch = "x86_64")]
#[inline]
pub fn qvec_cosine_sim_x86_64(a: &QVec, b: &QVec) -> f32 {
    use core::arch::x86_64::*;
    unsafe {
        let mut dot_sum = _mm_setzero_ps();
        let mut norm_a = _mm_setzero_ps();
        let mut norm_b = _mm_setzero_ps();

        let zero = _mm_set1_epi8(0);
        for i in (0..QVEC_SIZE).step_by(16) {
            let va = _mm_loadu_si128(a[i..].as_ptr() as *const __m128i);
            let vb = _mm_loadu_si128(b[i..].as_ptr() as *const __m128i);

            // Unpack low 8 bytes to 16-bit, then to 32-bit floats
            let va_lo = _mm_unpacklo_epi8(va, zero);
            let vb_lo = _mm_unpacklo_epi8(vb, zero);
            let va_f = _mm_cvtepi32_ps(_mm_unpacklo_epi16(va_lo, zero));
            let vb_f = _mm_cvtepi32_ps(_mm_unpacklo_epi16(vb_lo, zero));

            dot_sum = _mm_add_ps(dot_sum, _mm_mul_ps(va_f, vb_f));
            norm_a = _mm_add_ps(norm_a, _mm_mul_ps(va_f, va_f));
            norm_b = _mm_add_ps(norm_b, _mm_mul_ps(vb_f, vb_f));
        }

        let dot = _mm_cvtss_f32(_mm_hadd_ps(dot_sum, dot_sum));
        let na = _mm_cvtss_f32(_mm_hadd_ps(norm_a, norm_a));
        let nb = _mm_cvtss_f32(_mm_hadd_ps(norm_b, norm_b));

        if na == 0.0 || nb == 0.0 {
            0.0
        } else {
            dot / (na.sqrt() * nb.sqrt())
        }
    }
}

/// ARM NEON-accelerated cosine similarity for QVec registers
#[cfg(target_arch = "aarch64")]
#[inline]
pub fn qvec_cosine_sim_neon(a: &QVec, b: &QVec) -> f32 {
    use core::arch::aarch64::*;
    unsafe {
        let mut dot = vdupq_n_f32(0.0);
        let mut na = vdupq_n_f32(0.0);
        let mut nb = vdupq_n_f32(0.0);

        let zero = vdupq_n_u8(0);
        for i in (0..QVEC_SIZE).step_by(16) {
            let va = vld1q_u8(&a[i]);
            let vb = vld1q_u8(&b[i]);

            let va_lo = vmovl_u8(vget_low_u8(va));
            let vb_lo = vmovl_u8(vget_low_u8(vb));
            let va_f = vcvtq_f32_u32(vmovl_u16(vget_low_u16(va_lo)));
            let vb_f = vcvtq_f32_u32(vmovl_u16(vget_low_u16(vb_lo)));

            dot = vaddq_f32(dot, vmulq_f32(va_f, vb_f));
            na = vaddq_f32(na, vmulq_f32(va_f, va_f));
            nb = vaddq_f32(nb, vmulq_f32(vb_f, vb_f));
        }

        let d = vaddvq_f32(dot);
        let na_val = vaddvq_f32(na).sqrt();
        let nb_val = vaddvq_f32(nb).sqrt();

        if na_val == 0.0 || nb_val == 0.0 {
            0.0
        } else {
            d / (na_val * nb_val)
        }
    }
}

/// Scalar fallback cosine similarity
#[inline]
pub fn qvec_cosine_sim_scalar(a: &QVec, b: &QVec) -> f32 {
    let mut dot: f32 = 0.0;
    let mut na: f32 = 0.0;
    let mut nb: f32 = 0.0;
    for i in 0..QVEC_SIZE {
        let af = a[i] as f32;
        let bf = b[i] as f32;
        dot += af * bf;
        na += af * af;
        nb += bf * bf;
    }
    if na == 0.0 || nb == 0.0 {
        0.0
    } else {
        dot / (na.sqrt() * nb.sqrt())
    }
}

/// Dispatch to the best available SIMD implementation
#[inline]
pub fn qvec_cosine_sim(a: &QVec, b: &QVec) -> f32 {
    #[cfg(target_arch = "x86_64")]
    { qvec_cosine_sim_x86_64(a, b) }
    #[cfg(target_arch = "aarch64")]
    { qvec_cosine_sim_neon(a, b) }
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    { qvec_cosine_sim_scalar(a, b) }
}

// ===================================================================
// PEAK-3: SpeculativeScope RAII Guard
// ===================================================================

/// Action types for speculative scope
#[repr(u8)]
#[derive(Debug, Clone, Copy)]
pub enum SpecAction {
    Enter = 0,  // @PREDICT entry
    Commit = 1, // SPEC_COMMIT
    Rollback = 2, // SPEC_ROLLBACK
}

/// RAII guard that automatically executes SPEC_COMMIT or SPEC_ROLLBACK
/// based on the Rust `Result<T, E>` type when the guard is dropped.
pub struct SpeculativeScope<'a, T, E> {
    result: Option<Result<T, E>>,
    callback: Option<Peak3SpecScopeFn>,
    desc: &'a GammaFFIExport,
    committed: bool,
}

impl<'a, T, E> SpeculativeScope<'a, T, E> {
    /// Create a new speculative scope — calls @PREDICT entry
    pub fn new(desc: &'a GammaFFIExport, callback: Option<Peak3SpecScopeFn>) -> Self {
        if let Some(cb) = callback {
            cb(desc, SpecAction::Enter as u8);
        }
        Self {
            result: None,
            callback,
            desc,
            committed: false,
        }
    }

    /// Set the result — will determine commit vs rollback on Drop
    pub fn set_result(&mut self, result: Result<T, E>) {
        self.result = Some(result);
    }

    /// Explicitly commit the speculative scope
    pub fn commit(&mut self) {
        if !self.committed {
            if let Some(cb) = self.callback {
                cb(self.desc, SpecAction::Commit as u8);
            }
            self.committed = true;
        }
    }

    /// Explicitly rollback the speculative scope
    pub fn rollback(&mut self) {
        if !self.committed {
            if let Some(cb) = self.callback {
                cb(self.desc, SpecAction::Rollback as u8);
            }
            self.committed = true;
        }
    }
}

impl<'a, T, E> Drop for SpeculativeScope<'a, T, E> {
    fn drop(&mut self) {
        if !self.committed {
            if let Some(cb) = self.callback {
                let action = match &self.result {
                    Some(Ok(_)) => SpecAction::Commit as u8,
                    Some(Err(_)) => SpecAction::Rollback as u8,
                    None => SpecAction::Rollback as u8, // Default to rollback if no result set
                };
                cb(self.desc, action);
            }
        }
    }
}

// ===================================================================
// PEAK-4: Hardware Interrupt Signal Dispatch Bridge
// ===================================================================

/// Hardware interrupt channels — mirrors C++ HWIntChannel enum
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HWIntChannel {
    NONE = 0x00,
    VBLANK = 0x01,
    DMA_CH1 = 0x02,
    AUDIO_SWAP = 0x03,
    RENDER_DONE = 0x04,
}

/// Async hardware interrupt bridge — maps Rust async event loops to HWIntChannel
pub struct HwIntBridge {
    callback: Option<Peak4HwIntBridgeFn>,
    frame_count: u32,
}

impl HwIntBridge {
    pub fn new(callback: Option<Peak4HwIntBridgeFn>) -> Self {
        Self {
            callback,
            frame_count: 0,
        }
    }

    /// Dispatch a hardware interrupt signal
    pub fn dispatch(&mut self, desc: &GammaFFIExport, channel: HWIntChannel) {
        if let Some(cb) = self.callback {
            cb(desc, channel as u8);
        }
        if channel == HWIntChannel::VBLANK {
            self.frame_count += 1;
        }
    }

    /// Get the current frame count
    pub fn frame_count(&self) -> u32 {
        self.frame_count
    }
}

// ===================================================================
// PEAK-5: Safe Ring-Buffer Iterator
// ===================================================================

/// Safe Rust ring-buffer iterator wrapping CtxWritePos modular wrap arithmetic
pub struct RingBufferIter {
    write_pos: u16,
    span: u16,
    stride: u16,
    remaining: u16,
}

impl RingBufferIter {
    pub fn new(write_pos: u16, span: u16, stride: u16) -> Self {
        Self {
            write_pos,
            span: if span == 0 { 2048 } else { span },
            stride: if stride == 0 { 512 } else { stride },
            remaining: span / stride,
        }
    }

    /// Advance the write position by stride, wrapping at span
    #[inline]
    pub fn advance(&mut self) -> u16 {
        self.write_pos = (self.write_pos + self.stride) % self.span;
        self.write_pos
    }

    /// Get the current write position
    #[inline]
    pub fn position(&self) -> u16 {
        self.write_pos
    }
}

impl Iterator for RingBufferIter {
    type Item = u16;

    fn next(&mut self) -> Option<Self::Item> {
        if self.remaining == 0 {
            return None;
        }
        self.remaining -= 1;
        Some(self.advance())
    }
}

// ===================================================================
// CyberGrime CP0 Register Map (repr(C) parity)
// ===================================================================

/// Maps MIPS CP0 coprocessor registers — mirrors C++ CyberGrimeCP0Map
#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct CyberGrimeCP0Map {
    pub cp0_status: u32,    // CP0 reg 12
    pub cp0_cause: u32,     // CP0 reg 13
    pub cp0_epc: u32,       // CP0 reg 14
    pub cp0_bad_vaddr: u32, // CP0 reg 8
    pub cp0_count: u32,     // CP0 reg 9
    pub cp0_compare: u32,   // CP0 reg 11
    pub cp0_entry_hi: u32,  // CP0 reg 10
    pub cp0_index: u32,     // CP0 reg 0
}

const _: () = assert!(std::mem::size_of::<CyberGrimeCP0Map>() == 32);

// ===================================================================
// PSXMatrix Hardware Register Offset Map (repr(C) parity)
// ===================================================================

/// PSX DMA channels and GPU VRAM register offsets
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct PSXHwRegMap {
    pub dma_ch1_madr: u32,   // 0x1F8010A0
    pub dma_ch1_bcr: u32,    // 0x1F8010A4
    pub dma_ch1_chcr: u32,   // 0x1F8010A8
    pub dma_ch2_madr: u32,   // 0x1F8010B0
    pub dma_ch2_bcr: u32,    // 0x1F8010B4
    pub dma_ch2_chcr: u32,   // 0x1F8010B8
    pub gpu_gp0: u32,        // 0x1F801810
    pub gpu_gp1: u32,        // 0x1F801814
    pub i_stat: u32,         // 0x1F801070
    pub i_mask: u32,         // 0x1F801074
}

const _: () = assert!(std::mem::size_of::<PSXHwRegMap>() == 40);

impl Default for PSXHwRegMap {
    fn default() -> Self {
        Self {
            dma_ch1_madr: 0x1F8010A0,
            dma_ch1_bcr: 0x1F8010A4,
            dma_ch1_chcr: 0x1F8010A8,
            dma_ch2_madr: 0x1F8010B0,
            dma_ch2_bcr: 0x1F8010B4,
            dma_ch2_chcr: 0x1F8010B8,
            gpu_gp0: 0x1F801810,
            gpu_gp1: 0x1F801814,
            i_stat: 0x1F801070,
            i_mask: 0x1F801074,
        }
    }
}

// ===================================================================
// C-ABI Export Functions — called from C++ RustFFIDispatchTable
// ===================================================================

/// PEAK-1: Export bytecode arena to Rust DTC jump table
#[no_mangle]
pub extern "C" fn gamma_peak1_export_bytecode(desc: *const GammaFFIExport) {
    if desc.is_null() {
        return;
    }
    let desc = unsafe { &*desc };
    if let Some(view) = unsafe { BytecodeArenaView::from_ffi(desc) } {
        // In production: construct DTC jump table from bytecode instructions
        let _instrs = view.instructions();
    }
}

/// PEAK-2: QVec SIMD wrapper
#[no_mangle]
pub extern "C" fn gamma_peak2_qvec_simd(desc: *const GammaFFIExport, op_type: u8) {
    if desc.is_null() {
        return;
    }
    let desc = unsafe { &*desc };
    let op = match op_type {
        0 => QVecOp::Load,
        1 => QVecOp::Delta,
        2 => QVecOp::CosineSim,
        _ => QVecOp::DotProduct,
    };
    // In production: dispatch to SIMD functions based on op
    let _ = (desc, op);
}

/// PEAK-3: Speculative scope callback
#[no_mangle]
pub extern "C" fn gamma_peak3_spec_scope(desc: *const GammaFFIExport, action: u8) {
    if desc.is_null() {
        return;
    }
    let desc = unsafe { &*desc };
    match action {
        0 => { /* @PREDICT entry — save checkpoint */ }
        1 => { /* SPEC_COMMIT — commit speculative results */ }
        2 => { /* SPEC_ROLLBACK — restore saved state */ }
        _ => {}
    }
    let _ = desc;
}

/// PEAK-4: Hardware interrupt bridge
#[no_mangle]
pub extern "C" fn gamma_peak4_hw_int_bridge(desc: *const GammaFFIExport, channel: u8) {
    if desc.is_null() {
        return;
    }
    let desc = unsafe { &*desc };
    let _ch = match channel {
        0x01 => HWIntChannel::VBLANK,
        0x02 => HWIntChannel::DMA_CH1,
        0x03 => HWIntChannel::AUDIO_SWAP,
        0x04 => HWIntChannel::RENDER_DONE,
        _ => HWIntChannel::NONE,
    };
    let _ = desc;
}

/// PEAK-5: Ring buffer iterator
#[no_mangle]
pub extern "C" fn gamma_peak5_ring_iter(desc: *const GammaFFIExport, span: u16, stride: u16) {
    if desc.is_null() {
        return;
    }
    let desc = unsafe { &*desc };
    let iter = RingBufferIter::new(0, span, stride);
    for pos in iter {
        let _ = pos; // In production: write to CTX ring buffer
    }
    let _ = desc;
}

// ===================================================================
// High-Level Safe API — for Rust application code
// ===================================================================

/// High-level Gamma FFI context — wraps the raw C++ VM state
pub struct GammaFFIContext {
    pub hw_bridge: HwIntBridge,
    pub psx_regs: PSXHwRegMap,
    pub cp0_map: CyberGrimeCP0Map,
}

impl GammaFFIContext {
    pub fn new() -> Self {
        Self {
            hw_bridge: HwIntBridge::new(None),
            psx_regs: PSXHwRegMap::default(),
            cp0_map: CyberGrimeCP0Map::default(),
        }
    }

    /// Execute a speculative scope with automatic commit/rollback
    pub fn speculative<F, T, E>(&mut self, desc: &GammaFFIExport, f: F) -> Result<T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        let mut scope = SpeculativeScope::new(desc, None);
        let result = f();
        scope.set_result(result.clone());
        // Drop automatically commits or rolls back
        result
    }

    /// Dispatch a PSX DMA transfer via the hardware interrupt bridge
    pub fn dispatch_dma(&mut self, channel: HWIntChannel, desc: &GammaFFIExport) {
        self.hw_bridge.dispatch(desc, channel);
    }
}

impl Default for GammaFFIContext {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_rust_offset_flags() {
        let rof = RustOffsetFlags::new(0x04, RustReprType::REPR_C, 0x1234);
        assert_eq!(rof.flag(), 0x04);
        assert_eq!(rof.repr_type(), 0x0);
        assert_eq!(rof.offset_addr(), 0x1234);
    }

    #[test]
    fn test_qvec_cosine_sim_identity() {
        let a = [128u8; QVEC_SIZE];
        let sim = qvec_cosine_sim(&a, &a);
        assert!((sim - 1.0).abs() < 0.01);
    }

    #[test]
    fn test_ring_buffer_wrap() {
        let mut iter = RingBufferIter::new(0, 2048, 512);
        assert_eq!(iter.advance(), 512);
        assert_eq!(iter.advance(), 1024);
        assert_eq!(iter.advance(), 1536);
        assert_eq!(iter.advance(), 0); // Wraps
    }

    #[test]
    fn test_psx_hw_reg_map_defaults() {
        let regs = PSXHwRegMap::default();
        assert_eq!(regs.dma_ch1_madr, 0x1F8010A0);
        assert_eq!(regs.gpu_gp0, 0x1F801810);
    }

    #[test]
    fn test_speculative_scope_rollback_on_error() {
        // Simulate: scope drops with Err -> should rollback
        let desc = GammaFFIExport {
            data_ptr: std::ptr::null(),
            data_size: 0,
            element_size: 0,
            repr: 0,
            flags: 0,
            _pad: [0; 2],
            offset_addr: 0,
            struct_name: [0; 32],
            field_name: [0; 32],
        };
        let mut scope: SpeculativeScope<i32, &str> = SpeculativeScope::new(&desc, None);
        scope.set_result(Err("test error"));
        // Drop happens here — would call rollback in production
    }
}
