# GammaLanguage CMake FetchContent Module
#
# Usage in your CMakeLists.txt:
#
#   include(FetchContent)
#   FetchContent_Declare(
#       gammalanguage
#       GIT_REPOSITORY https://github.com/luxauraofficial777/gammalanguage.git
#       GIT_TAG        v1.1C
#   )
#   FetchContent_MakeAvailable(gammalanguage)
#
#   target_link_libraries(your_target PRIVATE gamma::core gamma::evaluator)

cmake_minimum_required(VERSION 3.20)

set(GAMMA_LANGUAGE_VERSION "1.1.0")

# Header-only library — zero-compile integration
add_library(gamma_core INTERFACE)
add_library(gamma::core ALIAS gamma_core)

target_include_directories(gamma_core INTERFACE
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/../cpp>
    $<INSTALL_INTERFACE:include/gammalanguage>
)

target_compile_features(gamma_core INTERFACE cxx_std_17)

# Evaluator library (header-only, requires C++17)
add_library(gamma_evaluator INTERFACE)
add_library(gamma::evaluator ALIAS gamma_evaluator)

target_link_libraries(gamma_evaluator INTERFACE gamma::core)

target_include_directories(gamma_evaluator INTERFACE
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/../cpp>
    $<INSTALL_INTERFACE:include/gammalanguage>
)

# Rust FFI integration (optional)
option(GAMMA_ENABLE_RUST_FFI "Enable Rust FFI bindings" OFF)
if(GAMMA_ENABLE_RUST_FFI)
    find_package(Cargo REQUIRED)
    add_custom_target(gamma_rust_ffi ALL
        COMMAND cargo build --release --manifest-path ${CMAKE_CURRENT_SOURCE_DIR}/../rust/Cargo.toml
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/../rust
        COMMENT "Building GammaLanguage Rust FFI crate"
    )
    add_library(gamma_rust STATIC IMPORTED)
    set_target_properties(gamma_rust PROPERTIES
        IMPORTED_LOCATION ${CMAKE_CURRENT_SOURCE_DIR}/../rust/target/release/libgamma_ffi.a
    )
    add_dependencies(gamma_rust gamma_rust_ffi)
endif()

# Install rules
include(GNUInstallDirs)

install(
    DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/../cpp/
    DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}/gammalanguage
    FILES_MATCHING PATTERN "*.h"
)

install(
    DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/../examples/
    DESTINATION ${CMAKE_INSTALL_DATADIR}/gammalanguage/examples
    FILES_MATCHING PATTERN "*.gamma"
)

# pkg-config file
configure_file(
    "${CMAKE_CURRENT_SOURCE_DIR}/gammalanguage.pc.in"
    "${CMAKE_CURRENT_BINARY_DIR}/gammalanguage.pc"
    @ONLY
)

install(
    FILES "${CMAKE_CURRENT_BINARY_DIR}/gammalanguage.pc"
    DESTINATION ${CMAKE_INSTALL_LIBDIR}/pkgconfig
)
