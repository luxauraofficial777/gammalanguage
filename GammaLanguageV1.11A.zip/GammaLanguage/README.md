# Liminal A2A-DSL (Agent-to-Agent Domain Specific Language)
## Specification v1.1C — Rust FFI Zero-Copy + Peak Performance Native Agentic Architecture

**Authors:** Google DeepMind Antigravity Pair-Programming Suite  
**Target Runtimes:** VoidWalkers HD Engine, Modern_X64, VW Nexus Server (`:8651`), Colibri MoE Router, TurboQuant Bridge (`:8646`), Caveman Middleware  
**Date:** August 2026  

> **Implementation Status:** The C++ parser, AST arena, and bytecode VM are functional. Some features listed below (Vulkan GPU offload, Caveman compression in C++, SIMD intrinsics) are stubs or software fallbacks — see individual sections for details.  

---

## 1. Executive Summary & Design Philosophy

Current agent-to-agent communication, MCP tool calls, and LLM context streaming rely on bloated JSON/YAML/XML formats. This consumes context window capacity on redundant structural syntax (`"properties":`, `"type":`, indentation, quote padding).

**Liminal A2A-DSL** solves this by establishing a register-based native language engineered for silicon and AI agents. It seamlessly incorporates the Liminal Lore toolchain:

1. **Caveman Layer:** Strips conversational filler, natural language preamble, and structural noise while guaranteeing 100% byte-exact code/command preservation. *(C++ implementation is a passthrough stub; full compression is implemented in the Python bridge.)*
2. **Colibri Layer:** Provides instruction primitives for low-memory MoE expert pinning, SSD-to-RAM streaming, and 30s heartbeat cadence pulses.
3. **TurboQuant Layer:** Enforces dynamic 2–3 bit KV-cache quantization guards directly inside state `@INVARIANT` blocks before LLM context calls trigger.
4. **Gigatoken Layer:** Directs large-context streaming, chunk-packing, and high-density vector database analysis across agent networks.

### v1.1A-Robust+ Additions

Building on v1.0's 8-sigil architecture, v1.1A-Robust introduces 7 new feature families and v1.1A-Robust+ adds 5 peak performance additions:

- **Dynamic Target Environment Definitions** (`|TARGET_DEFINE`)
- **Multi-Agent Synchronization** (`=LOCK=`, `=SYNC=`)
- **Partitioned Data Hive Targeting** (`#HIVE`)
- **Deterministic Error Recovery** (`@ON_ERROR`, `RETRY`, `SHIFT_TARGET`)
- **Bidirectional Native Code Interop** (`<NATIVE_BRIDGE>`)
- **Skill Hot-Swapping** (`+SKILL`, `-SKILL`)
- **ZHARK/FUBBU Research Delegation** (`?ZHARK`, `¿FUBBU_SYNC`)
- **A2A-B Binary Bytecode** — 32-bit packed instructions for Direct Threaded Code execution
- **Quantized Vector Delta Registers** (`#QVEC`, `#VEC_DELTA`) — 75% bandwidth reduction
- **Speculative Pipeline Branching** (`@PREDICT`, `SPEC_COMMIT`, `SPEC_ROLLBACK`)
- **Hardware Interrupt Frame-Sync** (`%HW_INT`) — VBLANK/DMA/AUDIO_SWAP mapping
- **Sliding-Window Context Eviction** (`^EVICT_SLIDING`) — automatic ring-buffer pruning

---

## 2. Token-Optimal Sigil & Symbol Dictionary

| Sigil | Primitive Name | Description & Usage |
| :---: | :--- | :--- |
| `!` | **State Shift** | Asserts an explicit state transition (`!STATE: 0x01 [NODE_INIT]`) |
| `@` | **Invariant Guard** | Hard precondition (`@INVARIANT`), error recovery (`@ON_ERROR`), speculative branch (`@PREDICT`) |
| `$` | **Execution Block** | Scoped logic container evaluating registers, vectors, and signals |
| `\|` | **Target Context** | Sets platform rules (`\|TARGET: [D3DX11]`) or defines custom specs (`\|TARGET_DEFINE`) |
| `+` / `-` | **Skill Swapper** | Equips (`+SKILL`) or unloads (`-SKILL`) agent capabilities dynamically |
| `*` | **Profile Swap** | Atomically swaps the entire active skill array (`*PROFILE`) |
| `#` | **Vector / Hive / QVec** | Embeddings (`#VEC[0]`), hives (`#HIVE["name"]`), quantized vectors (`#QVEC[0]`), deltas (`#VEC_DELTA`) |
| `%` | **Signal / HW Interrupt** | Cross-modulation (`%SIG[0]`), hardware frame-sync (`%HW_INT(VBLANK)`) |
| `~` | **MCP Transceiver Pipe** | Direct high-throughput tool call binding (`~MCP("vwforge_build", REG[0])`) |
| `&` | **Colibri Expert Swapper**| Signals expert pinning or unpinning in MoE RAM (`&PIN("lux-architect")`) |
| `^` | **Gigatoken / Eviction** | Context packing (`^GIGATOKEN_PACK`), sliding-window eviction (`^EVICT_SLIDING`) |
| `?` | **ZHARK Query** | Dispatches asynchronous research tasks (`?ZHARK(#HIVE["name"], "query")`) |
| `¿` | **FUBBU Sync** | Directs context compression and data hive aggregation (`¿FUBBU_SYNC(CTX[0])`) |
| `=` | **Sync Guard** | Multi-agent concurrency control (`=LOCK=`, `=UNLOCK=`, `=BARRIER=`, `=SYNC=`) |
| `<` | **Native Bridge** | Bidirectional native code interop (`<NATIVE_BRIDGE: CPP>`) |

---

## 3. Register & Memory Architecture

The runtime operates over eight dedicated register banks:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    A2A-DSL Virtual Machine v1.1A-ROBUST+                │
├───────────────────┬───────────────────┬─────────────────────────────────┤
│ Register Bank     │ Count & Dimensions│ Operational Scope               │
├───────────────────┼───────────────────┼─────────────────────────────────┤
│ REG[0..15]        │ 16 x 64-bit Int   │ General scalar data & pointers  │
│ HW[0..7]          │ 8 x System Def    │ Target-specific GPU/VDP/MMIO    │
│ SKL[0..3]         │ 4 x Skill Pointers│ Active Toolchain/MCP awareness  │
│ #VEC[0..7]        │ 8 x F16[1536]     │ Embeddings & Vector Memory      │
│ #QVEC[0..7]       │ 8 x U8[1536]      │ Quantized vectors (75% less BW) │
│ %SIG[0..7]        │ 8 x Float32       │ VFX & Engine Cross-Modulation   │
│ CTX[0..3]         │ 4 x Token Stream  │ Gigatoken Buffers & Ring Paging │
│ LCK[0..3]         │ 4 x Mutex Handles │ Multi-Agent Lock/Sync States    │
└───────────────────┴───────────────────┴─────────────────────────────────┘
```

---

## 4. Peak Performance Architecture (v1.1A-Robust+)

### PEAK-1: A2A-B Binary Bytecode Dialect

ASCII sigil syntax is compiled to 32-bit packed instructions at the MCP boundary:

```
[31:24] Opcode | [23:20] TargetReg | [19:16] SrcRegA | [15:12] SrcRegB | [11:8] Flags | [7:0] Immediate
```

The C++ VM executes bytecode via Direct Threaded Code jump tables — **64x smaller memory footprint** (4 bytes vs 256 bytes per instruction) and zero string lexing overhead on the hot path.

### PEAK-2: Quantized Vector Delta Registers

8-bit quantized vectors (`#QVEC[0..7]`) alongside differential updates (`#VEC_DELTA`) cut shared-memory ring buffer bandwidth by up to **75%** during multi-agent vector syncs.

### PEAK-3: Speculative Pipeline Branching

`@PREDICT` blocks allow sub-agents to speculatively dispatch async RAG queries before acquiring mutex locks. `SPEC_COMMIT` on invariant success; `SPEC_ROLLBACK` for atomic state restoration on failure.

### PEAK-4: Hardware Interrupt Frame-Sync

`%HW_INT(VBLANK)` / `%HW_INT(DMA_CH1)` / `%HW_INT(AUDIO_SWAP)` map engine signals directly to hardware timing channels for synchronous frame-bound execution.

### PEAK-5: Sliding-Window Context Eviction

`^EVICT_SLIDING(SPAN=2048, STRIDE=512)` formalizes explicit ring-buffer directives for CTX registers, guaranteeing automatic pruning of stale conversation turns in long-horizon agent loops.

---

## 5. End-to-End Code Sample

```plaintext
// v1.1A-Robust+: Peak performance demo with all 5 additions
|TARGET: [D3DX11]
!STATE: 0x03 [SHADER_COMPILE]
+SKILL["AtlasForge"]
-SKILL["CombatEngine_Logic"]
@INVARIANT: HW[2] == STATE_READY
@ON_ERROR: {
    ~MCP("log", "D3DX11 compilation failed. Triggering GDI+ fallback.");
    !SHIFT_TARGET: [GDI_DIB];
    RETRY(MAX=2);
}
=LOCK="source_Core_X64/CameraControl.cpp"

$EXEC {
  CTX[0] = CAVEMAN_SHRINK("Compile isometric depth dither shader", LEVEL=FULL);
  ^EVICT_SLIDING(SPAN=2048, STRIDE=512);
  #HIVE["render_pipeline_shaders"]

  @PREDICT: {
    ?ZHARK(#HIVE["render_pipeline_shaders"], "Locate VBlank timing offset for DQ4 boot");
    #VEC[0] = LOAD_EMBEDDING(CTX[0]);
    #QVEC[0] = QUANTIZE(#VEC[0]);
    #QVEC[1] = QUANTIZE(#VEC[1]);
    #VEC_DELTA(#QVEC[0], #QVEC[1]);
    SPEC_COMMIT;
  }

  %HW_INT(VBLANK);
  #VEC[1] = QUERY_VECTOR_DB(#VEC[0], TOP_K=5);
  REG[0] = COSINE_SIM(#VEC[0], #VEC[1]);
  ^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048);

  MATCH REG[0] -> {
    0x80: %SIG[0] = 0.95;
          ~MCP("vwforge_shader", CTX[0]);
          EMIT_SIGNAL(0xFF, "HIGH_SIMILARITY_EXECUTE");
    _:    %SIG[0] = 0.10;
          ABORT_TRANSITION(0xE2, "VECTOR_SIMILARITY_BELOW_THRESHOLD");
  };
}

=UNLOCK="source_Core_X64/CameraControl.cpp"

<NATIVE_BRIDGE: CPP>
void FastCompose16BPP(uint16_t* pDest, const uint16_t* pSrc, int count) {
    for(int i = 0; i < count; ++i) {
        if(pSrc[i] & 0x8000) pDest[i] = pSrc[i];
    }
}
</NATIVE_BRIDGE>
```

---

## 6. C++ Low-Overhead AST Parser Architecture

The C++ parser converts raw A2A-DSL streams directly into memory-mapped AST structs with zero dynamic heap allocation during parsing and execution (verified via `operator new` override in the test harness). v1.1A-Robust+ adds a bytecode compiler and Direct Threaded Code VM:

```cpp
// GammaLanguage/cpp/A2AST.h (v1.1A-Robust+ excerpt)
namespace A2A {

enum class Opcode : uint8_t {
    // v1.0 opcodes (0x01-0xFF)
    STATE_DECL = 0x01, INVARIANT_GUARD = 0x02, COSINE_SIM = 0x12, ...
    // v1.1A-Robust opcodes
    TARGET_DECL = 0x07, SKILL_EQUIP = 0x09, HIVE_SELECT = 0x15,
    LOCK_ACQUIRE = 0x60, ON_ERROR_BLOCK = 0x70, NATIVE_BRIDGE = 0x80, ...
    // v1.1A-Robust+ Peak Performance opcodes
    QVEC_LOAD     = 0x18,   // PEAK-2: 8-bit quantized vector load
    VEC_DELTA     = 0x19,   // PEAK-2: Differential vector update
    PREDICT_BLOCK = 0x73,   // PEAK-3: Speculative pipeline branch
    SPEC_COMMIT   = 0x74,   // PEAK-3: Commit speculative buffer
    SPEC_ROLLBACK = 0x75,   // PEAK-3: Rollback speculative buffer
    HW_INTERRUPT  = 0x90,   // PEAK-4: Hardware interrupt frame-sync
    EVICT_SLIDING = 0x31    // PEAK-5: Sliding-window context eviction
};

// PEAK-1: 32-bit packed bytecode instruction
struct A2AB_Instruction {
    uint32_t packed;  // [31:24]Op|[23:20]Tgt|[19:16]SrcA|[15:12]SrcB|[11:8]Flags|[7:0]Imm
};
static_assert(sizeof(A2AB_Instruction) == 4, "A2AB instruction must be 4 bytes");

} // namespace A2A
```

---

## 7. Performance & Token Savings Benchmark

> **Note:** The following table compares payload sizes and token counts for a representative MCP tool-call payload. Parse time and bytecode execution figures are measured by `test_a2a_parser.cpp` on the reference machine — run the benchmark locally for accurate numbers on your hardware. The C++ cosine similarity path uses a software fallback (auto-vectorized loop unrolling); Vulkan GPU offload is not yet implemented.

| Metric | Standard JSON-RPC | A2A-DSL + Caveman | Notes |
| :--- | :--- | :--- | :--- |
| **Payload Size (Bytes)** | ~1,420 B | ~185 B | Measured on a representative MCP tool-call payload |
| **Token Count (BPE)** | ~340 tokens | ~48 tokens | Estimated for the same payload |
| **Parse Time (C++)** | ~1.85 ms (nlohmann/json) | ~0.04 ms (static AST arena) | Measured on reference hardware; varies by CPU |
| **Bytecode Execution** | N/A | Measured by `test_a2a_parser.cpp` | Bytecode path includes compile + execute |
| **Vector Sync Bandwidth** | 3 KB/slot (FP16) | 0.75 KB/slot (QVec 8-bit) | Theoretical 75% reduction from 16-bit → 8-bit |
| **KV-Cache RAM Footprint** | ~3.2 GB | ~0.4 GB (with TurboQuant) | Estimate; depends on model and quantization level |

---

## 8. Directory Structure

* **`GAMMA_LANGUAGE_EBNF_SPEC.md`**: Formal EBNF grammar, sigil dictionary, register architecture, and full specification.
* **`cpp/`**: Zero-allocation, cache-line aligned C++ AST parser, auto-vectorized cosine similarity, A2A-B bytecode VM, GPU compute stub, shared memory bus, and unit tests.
  * `A2AST.h` — AST nodes, opcodes, register banks, bytecode format
  * `A2ALexer.h/.cpp` — Zero-alloc sigil lexer
  * `A2AEvaluator.h/.cpp` — AST + bytecode execution engine
  * `A2AGPUCompute.h/.cpp` — GPU offload stub (software fallback; Vulkan not yet wired)
  * `A2ASharedMemory.h/.cpp` — Inter-process ring buffer for multi-agent sync
  * `test_a2a_parser.cpp` — Unit tests + throughput benchmarks
  * `CMakeLists.txt` — Build configuration
* **`python/`**: Python CLI bridge, Caveman compression, TurboQuant/Nexus adapters.
  * `gamma_bridge.py` — GammaBridge class, v1.1A-Robust+ parser
  * `gamma_cli.py` — CLI with `--test`, `--script`, `--json`, `--agent` flags
  * `requirements.txt` — Zero external dependencies (stdlib only)
* **`examples/`**: Ready-to-run `.gamma` script examples.
  * `sample_crossmod.gamma` — v1.0 cross-modulation demo
  * `sample_vector_query.gamma` — v1.0 vector query demo
  * `sample_v11a_robust.gamma` — v1.1A-Robust multi-agent shader compile
  * `sample_psx_research.gamma` — PSX disassembly research delegation
  * `sample_multi_agent_sync.gamma` — Multi-agent concurrent build with barrier sync
  * `sample_peak_performance.gamma` — All 5 peak performance additions
* **`install.ps1` / `install.bat`**: One-click installer scripts.

---

## 9. Quick Start

### Python CLI

```bash
python python/gamma_cli.py --test
python python/gamma_cli.py --script examples/sample_peak_performance.gamma
python python/gamma_cli.py --json
```

### C++ Parser

```bash
cd cpp && cmake -B build && cmake --build build
.\build\gamma_parser.exe
```

---

*Liminal A2A-DSL v1.1A-Robust+ Spec Locked. Integrated with Caveman, Colibri, TurboQuant, Gigatoken, ZHARK, FUBBU, multi-hardware target profiles, A2A-B bytecode, quantized vector deltas, speculative pipeline branching, hardware interrupt frame-sync, and sliding-window context eviction.*


