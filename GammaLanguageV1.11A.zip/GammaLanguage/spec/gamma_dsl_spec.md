# Gamma Language (Gamma-DSL v1.0) Specification
## Native Token-Compressed Agentic Architecture

**Version:** 1.0  
**Target Runtimes:** VoidWalkers HD Engine, Modern_X64, Colibri MoE Router, TurboQuant Bridge, Caveman Middleware  
**Date:** August 2026  

---

## 1. Sigil Lexicon

| Sigil | Primitive Name | Usage |
| :---: | :--- | :--- |
| `!` | **State Shift** | Asserts explicit state transition (`!STATE: 0x01 [NODE_INIT]`) |
| `@` | **Invariant Guard** | Hard precondition evaluating RAM & schema bounds (`@INVARIANT: RAM <= 0.65`) |
| `$` | **Execution Block** | Scoped execution logic container (`$EXEC { ... }`) |
| `#` | **Vector Register** | Point to Float16 1536-dim vector embeddings (`#VEC[0]`) |
| `%` | **Cross-Modulation Signal**| Real-time trigger for VFX & Audio (`%SIG[0] = 0.95`) |
| `~` | **MCP Transceiver Pipe** | Direct high-throughput tool call pipe (`~MCP("vwforge_build", REG[0])`) |
| `&` | **Colibri Expert Directives**| Expert pinning/unpinning/heartbeat (`&PIN_EXPERT("lux-architect")`) |
| `^` | **Gigatoken Streamer** | High-density context packing directive (`^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048)`) |

---

## 2. Formal EBNF Grammar

```ebnf
program              ::= state_decl invariant_section colibri_directives execution_block ;
state_decl           ::= "!" "STATE:" hex_literal "[" identifier "]" newline ;
invariant_section    ::= ( "@INVARIANT:" condition_expr newline )* ;
colibri_directives   ::= ( "&" colibri_op "(" string_literal ")" newline )* ;
execution_block      ::= "$" "EXEC" "{" newline statement_list "}" ;
statement_list       ::= ( statement ";" newline )* ;
statement            ::= assignment_stmt | match_stmt | mcp_pipe_stmt | gigatoken_stmt | signal_emit_stmt | abort_stmt ;
assignment_stmt      ::= target_register "=" expr ;
target_register      ::= "REG[" int_literal "]" | "#VEC[" int_literal "]" | "%SIG[" int_literal "]" | "CTX[" int_literal "]" ;
expr                 ::= vector_fn | caveman_compress_fn | load_fn | scalar_op | literal ;
vector_fn            ::= "COSINE_SIM(" "#VEC[" int_literal "]" "," "#VEC[" int_literal "]" ")"
                       | "QUERY_VECTOR_DB(" "#VEC[" int_literal "]" "," "TOP_K=" int_literal ")"
                       | "LOAD_EMBEDDING(" string_literal ")" ;
caveman_compress_fn  ::= "CAVEMAN_SHRINK(" ( string_literal | "CTX[" int_literal "]" ) "," "LEVEL=" caveman_level ")" ;
caveman_level        ::= "LITE" | "FULL" | "ULTRA" | "WENYAN" ;
colibri_op           ::= "PIN_EXPERT" | "UNPIN_EXPERT" | "SWAP_EXPERT" | "HEARTBEAT" ;
gigatoken_stmt       ::= "^" "GIGATOKEN_PACK(" "CTX[" int_literal "]" "," "MAX_TOKENS=" int_literal ")" ;
mcp_pipe_stmt        ::= "~" "MCP(" string_literal "," target_register ")" ;
match_stmt           ::= "MATCH" target_register "->" "{" newline match_branches "}" ;
match_branches       ::= ( match_pattern ":" statement_list )+ ;
match_pattern        ::= hex_literal | int_literal | "_" ;
signal_emit_stmt     ::= "EMIT_SIGNAL(" hex_literal "," string_literal ")" ;
abort_stmt           ::= "ABORT_TRANSITION(" hex_literal "," string_literal ")" ;
condition_expr       ::= identifier binary_relop operand ;
binary_relop         ::= "<=" | ">=" | "==" | "!=" | "<" | ">" ;
operand              ::= float_literal | int_literal | hex_literal | string_literal ;
```
