# Implementation Plan — Liminal Lore V1.1A Gamma Integration (Pro 3.1 Optimization)

This plan details the implementation of the advanced architectural upgrades for Liminal Lore V1.1A and the native Gamma Language engine.

## User Review Required

> [!IMPORTANT]
> This upgrade shifts inter-process communication (IPC) for local components away from WebSocket/HTTP towards **Zero-Copy Memory-Mapped Ring Buffers**.
> We will also introduce **GPU Compute Shaders** for heavy `#VEC` vector database queries and cosine similarity operations.

> [!WARNING]
> Implementing AST Memoization (Cross-Module Caching) will require strict ownership rules over AST nodes to avoid use-after-free bugs when sharing pointers between FUBBU and ZHARK.

## Open Questions

- For the GPU Compute offload, do you prefer we target DirectX 12, Vulkan, or both? (Assuming Vulkan for maximum cross-platform compatibility if not specified).

## Proposed Changes

### 1. C++ Core Pro Optimizations (`Modern_X64/tools/a2a_parser`)

#### [NEW] [A2ASharedMemory.h](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2ASharedMemory.h) & [A2ASharedMemory.cpp](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2ASharedMemory.cpp)
- Implement `AST_RingBuffer` using Windows memory-mapped files (`CreateFileMapping`, `MapViewOfFile`) for zero-copy IPC.
- This will allow FUBBU, ZHARK, and VW Nexus to read binary AST nodes without serialization latency.

#### [NEW] [A2AGPUCompute.h](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2AGPUCompute.h) & [A2AGPUCompute.cpp](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2AGPUCompute.cpp)
- Implement Vulkan-based Compute Shaders for executing `GPU_COSINE_SIM` on `#VEC` arrays.
- Add hardware fallback to AVX-512 CPU intrinsics if no suitable GPU is found.

#### [MODIFY] [A2AST.h](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2AST.h) & [A2AEvaluator.cpp](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/a2a_parser/A2AEvaluator.cpp)
- Add `AST_Memoizer` to hash instruction blocks and cache `ASTNode*` pointers for reuse across different agents (ZHARK / FUBBU).
- Update the evaluator to offload vector ops to `A2AGPUCompute`.

### 2. Python Toolchain & Agent Logic (`Modern_X64/tools`)

#### [MODIFY] [Colibri Routing Logic](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/colibri/routing.py) (Conceptual Path)
- Update `&PIN_EXPERT` parser logic to handle probabilistic arrays (e.g., `&PIN_EXPERT([("nex", 0.7), ("lux", 0.3)])`).

#### [MODIFY] [VW Nexus Service](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/vw_nexus/vw_nexus_service.py) (Conceptual Path)
- Add bindings to read/write to the `AST_RingBuffer` shared memory instead of exclusively relying on Port 8652 WebSockets.

### 3. Liminal Lore GUI (`Modern_X64/tools/Liminal_Lore_V101C/liminal_lore_vw_deck/VoidWalkers_Chat_GUI.html`)

#### [MODIFY] [VoidWalkers_Chat_GUI.html](file:///C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/Liminal_Lore_V101C/liminal_lore_vw_deck/VoidWalkers_Chat_GUI.html)
- Add a "Gamma AST Terminal" tab.
- Implement live rendering of the Zero-Copy AST packets.

---

## Verification Plan

### Automated Tests
1. **Shared Memory Test**: Create a producer/consumer benchmark bridging C++ and Python to verify nanosecond-latency AST packet transfers.
2. **GPU vs CPU Benchmark**: Run `#VEC` similarity queries comparing the Vulkan Compute path vs AVX-512 path to confirm throughput advantages.

### Manual Verification
- Deploy the updated VoidWalkers HD Engine and monitor TurboQuant memory constraints through the new GUI telemetry tab.
- Test FUBBU and ZHARK loops handling cross-module caching successfully.
