import sys
import os
import json
from gamma_bridge import GammaBridge

def main():
    bridge = GammaBridge()
    args = sys.argv[1:]

    sample_script = R"""
// v1.1A-Robust+: Peak performance demo with all 5 additions
|TARGET: [D3DX11]
!STATE: 0x03 [SHADER_COMPILE]
+SKILL["AtlasForge"]
-SKILL["CombatEngine_Logic"]
@INVARIANT: HW[2] == STATE_READY
@ON_ERROR: {
    ~MCP("log", "D3DX11 compilation failed. Triggering GDI+ fallback.");
    !SHIFT_TARGET: [GDI_DIB];
    RETRY(MAX=2);
}
=LOCK="source_Core_X64/CameraControl.cpp"

$EXEC {
  CTX[0] = CAVEMAN_SHRINK("Compile isometric depth dither shader", LEVEL=FULL);
  ^EVICT_SLIDING(SPAN=2048, STRIDE=512);
  #HIVE["render_pipeline_shaders"]

  @PREDICT: {
    ?ZHARK(#HIVE["render_pipeline_shaders"], "Locate VBlank timing offset for DQ4 boot");
    #VEC[0] = LOAD_EMBEDDING(CTX[0]);
    #QVEC[0] = QUANTIZE(#VEC[0]);
    #QVEC[1] = QUANTIZE(#VEC[1]);
    #VEC_DELTA(#QVEC[0], #QVEC[1]);
    SPEC_COMMIT;
  }

  %HW_INT(VBLANK);
  #VEC[1] = QUERY_VECTOR_DB(#VEC[0], TOP_K=5);
  REG[0] = COSINE_SIM(#VEC[0], #VEC[1]);
  ^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048);

  MATCH REG[0] -> {
    0x80: %SIG[0] = 0.95;
          ~MCP("vwforge_shader", CTX[0]);
          EMIT_SIGNAL(0xFF, "HIGH_SIMILARITY_EXECUTE");
    _:    %SIG[0] = 0.10;
          ABORT_TRANSITION(0xE2, "VECTOR_SIMILARITY_BELOW_THRESHOLD");
  };
}

=UNLOCK="source_Core_X64/CameraControl.cpp"

<NATIVE_BRIDGE: CPP>
void FastCompose16BPP(uint16_t* pDest, const uint16_t* pSrc, int count) {
    for(int i = 0; i < count; ++i) {
        if(pSrc[i] & 0x8000) pDest[i] = pSrc[i];
    }
}
</NATIVE_BRIDGE>
"""

    if "--script" in args:
        idx = args.index("--script")
        if idx + 1 < len(args):
            with open(args[idx + 1], "r", encoding="utf-8") as f:
                sample_script = f.read()

    result = bridge.compile_gamma(sample_script)

    if "--json" in args or "--agent" in args:
        print(json.dumps(result, indent=2))
    else:
        print("\n[ Gamma Language CLI v1.1A-Robust+ ]")
        print(f"[*] State ID: {result['state_id']}")
        print(f"[*] Invariants Checked: {result['invariants_checked']}")
        print(f"[*] AST Nodes Compiled: {result['ast_node_count']}")
        print(f"[*] Colibri Directives: {result['colibri_directives']}")
        print(f"[*] Skill Directives: {len(result['skill_directives'])}")
        print(f"[*] Sync Directives: {len(result['sync_directives'])}")
        print(f"[*] Target Directives: {len(result['target_directives'])}")
        print(f"[*] Hive Directives: {len(result['hive_directives'])}")
        print(f"[*] Research Delegations: {len(result['research_directives'])}")
        print(f"[*] Native Bridges: {result['native_bridge_count']}")
        print(f"[*] Error Blocks: {result['error_block_count']}")
        pf = result['peak_features']
        print(f"[*] Peak Features: QVec={pf['qvec_ops']} Predict={pf['predict_blocks']} Commit={pf['spec_commits']} HWInt={pf['hw_interrupts']} Evict={pf['evictions']}")
        print(f"[*] TurboQuant Status: {result['turboquant_status']['status']} ({result['turboquant_status']['mode']})")
        print(f"[*] Estimated Token Savings: {result['estimated_token_savings']}")
        print("[+] Gamma Script Compiled & Validated Successfully.\n")

if __name__ == "__main__":
    main()
