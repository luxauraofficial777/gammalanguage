#pragma once
#include "A2AST.h"
#include "A2AGPUCompute.h"
#include <string>

namespace A2A {

struct ExecutionResult {
    bool Success{true};
    FaultCode Fault{FaultCode::NONE};
    uint8_t ExitCode{0};
    std::string Message{"OK"};
    uint32_t InvariantsChecked{0};
    uint32_t InstructionsExecuted{0};
};

class Evaluator {
public:
    explicit Evaluator(uint32_t max_cycles = 1000) : m_max_cycles(max_cycles) {}

    void SetComputeDevice(const GPUDevice& device) {
        m_gpu.InitializeVulkan();
    }

    template <size_t N>
    ExecutionResult Execute(const ASTArena<N>& arena, RegisterBank& registers) {
        ExecutionResult res{};

        for (size_t i = 0; i < arena.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.ExitCode = static_cast<uint8_t>(FaultCode::INSTRUCTION_BUDGET);
                res.Message = "Instruction cycle budget limit exceeded";
                return res;
            }

            const ASTNode& node = arena.Nodes[i];

            switch (node.op) {
                case Opcode::STATE_DECL:
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Target declaration
                case Opcode::TARGET_DECL:
                    registers.ActiveTargetIndex = 1; // Mark target as set
                    res.InstructionsExecuted++;
                    break;

                case Opcode::TARGET_DEFINE:
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Skill management
                case Opcode::SKILL_EQUIP:
                    // Mark skill slot as occupied (conceptual)
                    if (registers.Skl[0] == 0) registers.Skl[0] = 1;
                    else if (registers.Skl[1] == 0) registers.Skl[1] = 1;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SKILL_UNLOAD:
                    // Clear last occupied skill slot
                    if (registers.Skl[3] != 0) registers.Skl[3] = 0;
                    else if (registers.Skl[2] != 0) registers.Skl[2] = 0;
                    else if (registers.Skl[1] != 0) registers.Skl[1] = 0;
                    else if (registers.Skl[0] != 0) registers.Skl[0] = 0;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::PROFILE_SWAP:
                    // Reset all skills then mark first as active
                    registers.Skl.fill(0);
                    registers.Skl[0] = 1;
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Hive selection
                case Opcode::HIVE_SELECT:
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Research delegation
                case Opcode::ZHARK_QUERY:
                    // Async research dispatch — non-blocking
                    res.InstructionsExecuted++;
                    break;

                case Opcode::FUBBU_SYNC:
                    // Context compression — conceptual
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Concurrency guards
                case Opcode::LOCK_ACQUIRE:
                    // Acquire mutex on resource (conceptual — store in LCK[0])
                    if (registers.Lck[0] == 0) {
                        registers.Lck[0] = 1; // Locked
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::SCHEMA_DRIFT;
                        res.Message = "LOCK_ACQUIRE: Resource already locked";
                        return res;
                    }
                    break;

                case Opcode::LOCK_RELEASE:
                    registers.Lck[0] = 0; // Unlocked
                    res.InstructionsExecuted++;
                    break;

                case Opcode::BARRIER_WAIT:
                case Opcode::SYNC_WAIT:
                    // Non-blocking in single-agent mode — just count
                    res.InstructionsExecuted++;
                    break;

                // v1.1A: Error recovery
                case Opcode::ON_ERROR_BLOCK:
                    // Store error block for potential retry — conceptual
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SHIFT_TARGET:
                    // Shift to fallback target
                    registers.ActiveTargetIndex = 2; // GDI_DIB fallback
                    res.InstructionsExecuted++;
                    break;

                case Opcode::RETRY:
                    if (registers.RetryCount < registers.MaxRetries) {
                        registers.RetryCount++;
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::INSTRUCTION_BUDGET;
                        res.Message = "RETRY: Max retries exceeded";
                        return res;
                    }
                    break;

                // v1.1A: Native bridge
                case Opcode::NATIVE_BRIDGE:
                    res.InstructionsExecuted++;
                    break;

                // PEAK-2: Quantized vector load (8-bit)
                case Opcode::QVEC_LOAD:
                    // Quantize FP16 vector into 8-bit: scale to [0,255]
                    if (node.target_reg < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            registers.QVec[node.target_reg][j] =
                                static_cast<uint8_t>(registers.Vec[node.target_reg][j] >> 8);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-2: Vector delta update — apply differential to quantized vector
                case Opcode::VEC_DELTA:
                    if (node.target_reg < 8 && node.src_reg_a < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            int32_t delta = static_cast<int32_t>(registers.QVec[node.src_reg_a][j]) -
                                            static_cast<int32_t>(registers.QVec[node.target_reg][j]);
                            registers.QVec[node.target_reg][j] =
                                static_cast<uint8_t>(delta & 0xFF);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-3: Speculative pipeline branching
                case Opcode::PREDICT_BLOCK:
                    // Save checkpoint for potential rollback
                    registers.SpecBuf.Active = true;
                    registers.SpecBuf.Committed = false;
                    registers.SpecBuf.StartPC = static_cast<uint32_t>(i + 1);
                    registers.SpecBuf.SavedRetryCount = registers.RetryCount;
                    registers.SpecBuf.SavedTargetIndex = registers.ActiveTargetIndex;
                    registers.SpecBuf.SavedLck = registers.Lck;
                    registers.SpecBuf.SavedSig = registers.Sig;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_COMMIT:
                    // Speculative results validated — commit them
                    registers.SpecBuf.Active = false;
                    registers.SpecBuf.Committed = true;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_ROLLBACK:
                    // Invariant failed — restore saved state atomically
                    if (registers.SpecBuf.Active) {
                        registers.RetryCount = registers.SpecBuf.SavedRetryCount;
                        registers.ActiveTargetIndex = registers.SpecBuf.SavedTargetIndex;
                        registers.Lck = registers.SpecBuf.SavedLck;
                        registers.Sig = registers.SpecBuf.SavedSig;
                        registers.SpecBuf.Active = false;
                        registers.SpecBuf.Committed = false;
                        res.InstructionsExecuted++;
                        res.Message = "SPEC_ROLLBACK: Speculative buffer discarded, state restored";
                    }
                    break;

                // PEAK-4: Hardware interrupt frame-sync
                case Opcode::HW_INTERRUPT:
                    // Map signal to hardware timing channel
                    {
                        std::string_view payload(node.payload_str);
                        if (payload.find("VBLANK") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::VBLANK;
                        else if (payload.find("DMA_CH1") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::DMA_CH1;
                        else if (payload.find("AUDIO_SWAP") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::AUDIO_SWAP;
                        else if (payload.find("RENDER_DONE") != std::string_view::npos)
                            registers.PendingInt = HWIntChannel::RENDER_DONE;
                        else
                            registers.PendingInt = HWIntChannel::NONE;
                        registers.FrameCount++;
                    }
                    res.InstructionsExecuted++;
                    break;

                // PEAK-5: Sliding-window context eviction
                case Opcode::EVICT_SLIDING:
                    // Prune stale context from CTX ring buffer
                    {
                        std::string_view payload(node.payload_str);
                        // Parse SPAN= and STRIDE= from payload if present
                        size_t span_pos = payload.find("SPAN=");
                        if (span_pos != std::string_view::npos) {
                            uint16_t val = 0;
                            for (size_t j = span_pos + 5; j < payload.size() && payload[j] >= '0' && payload[j] <= '9'; ++j)
                                val = val * 10 + static_cast<uint16_t>(payload[j] - '0');
                            if (val > 0) registers.EvictSpan = val;
                        }
                        size_t stride_pos = payload.find("STRIDE=");
                        if (stride_pos != std::string_view::npos) {
                            uint16_t val = 0;
                            for (size_t j = stride_pos + 7; j < payload.size() && payload[j] >= '0' && payload[j] <= '9'; ++j)
                                val = val * 10 + static_cast<uint16_t>(payload[j] - '0');
                            if (val > 0) registers.EvictStride = val;
                        }
                        // Advance ring-buffer write position by stride, wrapping at span
                        for (int c = 0; c < 4; ++c) {
                            registers.CtxWritePos[c] = static_cast<uint16_t>(
                                (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::INVARIANT_GUARD:
                    res.InvariantsChecked++;
                    if (!EvaluateInvariant(node, registers)) {
                        res.Success = false;
                        res.Fault = FaultCode::MEMORY_LIMIT_EXCEEDED;
                        res.ExitCode = static_cast<uint8_t>(FaultCode::MEMORY_LIMIT_EXCEEDED);
                        res.Message = "Invariant violation: TurboQuant RAM threshold exceeded (0xE1)";
                        return res;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::COLIBRI_PIN:
                    registers.ActiveExpertIndex = 1; // Pinned
                    res.InstructionsExecuted++;
                    break;

                case Opcode::CAVEMAN_SHRINK: {
                    const char* caveman_text = "New ref each render. Wrap in useMemo.";
                    size_t len = std::strlen(caveman_text);
                    std::memcpy(registers.Ctx[0].data(), caveman_text, len + 1);
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::COSINE_SIM:
                    // PRO OPTIMIZATION: GPU Offload
                    registers.Reg[0] = static_cast<int64_t>(m_gpu.ComputeCosineSim(registers.Vec[0], registers.Vec[1]) * 1000.0f);
                    res.InstructionsExecuted++;
                    break;

                case Opcode::EMIT_SIGNAL:
                    res.InstructionsExecuted++;
                    res.Message = "EMIT_SIGNAL: " + std::string(node.payload_str);
                    break;

                case Opcode::ABORT_TRANSITION:
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.ExitCode = static_cast<uint8_t>(FaultCode::SCHEMA_DRIFT);
                    res.Message = "ABORT_TRANSITION: " + std::string(node.payload_str);
                    return res;

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }

        return res;
    }

private:
    bool EvaluateInvariant(const ASTNode& node, RegisterBank& registers);
    float ComputeCosineSimSIMD(const std::array<uint16_t, 1536>& v1, const std::array<uint16_t, 1536>& v2);
    // PEAK-2: Quantized cosine similarity using 8-bit QVec registers
    float ComputeQVecCosineSim(const std::array<uint8_t, 1536>& v1, const std::array<uint8_t, 1536>& v2);
    
    uint32_t m_max_cycles{1000};
    GPUComputeEngine m_gpu;
    AST_Memoizer m_memoizer;

public:
    // PEAK-1: Direct Threaded Code execution of A2A-B bytecode
    // Eliminates string lexing overhead — operates on 4-byte packed instructions
    ExecutionResult ExecuteBytecode(const BytecodeArena<512>& bc, RegisterBank& registers) {
        ExecutionResult res{};

        // Direct threaded code: function pointer jump table indexed by opcode
        // Each handler is a simple register operation — no string parsing on hot path
        for (size_t i = 0; i < bc.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.Message = "Bytecode cycle budget exceeded";
                return res;
            }

            const A2AB_Instruction& instr = bc.Instrs[i];
            uint8_t op = instr.Opcode();

            // Jump table dispatch — compiler can optimize to computed goto
            switch (op) {
                case static_cast<uint8_t>(Opcode::STATE_DECL):
                case static_cast<uint8_t>(Opcode::TARGET_DECL):
                case static_cast<uint8_t>(Opcode::TARGET_DEFINE):
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::INVARIANT_GUARD):
                    res.InvariantsChecked++;
                    // Fast path: check TurboQuant RAM inline
                    if (registers.TurboQuantRamUtil > 0.65f) {
                        res.Success = false;
                        res.Fault = FaultCode::MEMORY_LIMIT_EXCEEDED;
                        res.Message = "Bytecode invariant violation (0xE1)";
                        return res;
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::COLIBRI_PIN):
                    registers.ActiveExpertIndex = instr.TargetReg();
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SKILL_EQUIP):
                    if (registers.Skl[0] == 0) registers.Skl[0] = 1;
                    else if (registers.Skl[1] == 0) registers.Skl[1] = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SKILL_UNLOAD):
                    for (int j = 3; j >= 0; --j) {
                        if (registers.Skl[j] != 0) { registers.Skl[j] = 0; break; }
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::QVEC_LOAD):
                    if (instr.TargetReg() < 8) {
                        for (size_t j = 0; j < 1536; ++j)
                            registers.QVec[instr.TargetReg()][j] =
                                static_cast<uint8_t>(registers.Vec[instr.TargetReg()][j] >> 8);
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::VEC_DELTA):
                    if (instr.TargetReg() < 8 && instr.SrcRegA() < 8) {
                        for (size_t j = 0; j < 1536; ++j) {
                            int32_t delta = static_cast<int32_t>(registers.QVec[instr.SrcRegA()][j]) -
                                            static_cast<int32_t>(registers.QVec[instr.TargetReg()][j]);
                            registers.QVec[instr.TargetReg()][j] = static_cast<uint8_t>(delta & 0xFF);
                        }
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::COSINE_SIM):
                    // PEAK-2: Use quantized path when possible
                    registers.Reg[0] = static_cast<int64_t>(
                        ComputeQVecCosineSim(registers.QVec[0], registers.QVec[1]) * 1000.0f);
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::PREDICT_BLOCK):
                    registers.SpecBuf.Active = true;
                    registers.SpecBuf.Committed = false;
                    registers.SpecBuf.StartPC = static_cast<uint32_t>(i + 1);
                    registers.SpecBuf.SavedRetryCount = registers.RetryCount;
                    registers.SpecBuf.SavedTargetIndex = registers.ActiveTargetIndex;
                    registers.SpecBuf.SavedLck = registers.Lck;
                    registers.SpecBuf.SavedSig = registers.Sig;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SPEC_COMMIT):
                    registers.SpecBuf.Active = false;
                    registers.SpecBuf.Committed = true;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::SPEC_ROLLBACK):
                    if (registers.SpecBuf.Active) {
                        registers.RetryCount = registers.SpecBuf.SavedRetryCount;
                        registers.ActiveTargetIndex = registers.SpecBuf.SavedTargetIndex;
                        registers.Lck = registers.SpecBuf.SavedLck;
                        registers.Sig = registers.SpecBuf.SavedSig;
                        registers.SpecBuf.Active = false;
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::HW_INTERRUPT):
                    registers.PendingInt = static_cast<HWIntChannel>(instr.Flags() & 0x0F);
                    registers.FrameCount++;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EVICT_SLIDING):
                    for (int c = 0; c < 4; ++c) {
                        registers.CtxWritePos[c] = static_cast<uint16_t>(
                            (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan);
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_ACQUIRE):
                    if (registers.Lck[instr.TargetReg() & 0x03] == 0) {
                        registers.Lck[instr.TargetReg() & 0x03] = 1;
                        res.InstructionsExecuted++;
                    } else {
                        res.Success = false;
                        res.Fault = FaultCode::SCHEMA_DRIFT;
                        res.Message = "Bytecode LOCK_ACQUIRE: already locked";
                        return res;
                    }
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_RELEASE):
                    registers.Lck[instr.TargetReg() & 0x03] = 0;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EMIT_SIGNAL):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::ABORT_TRANSITION):
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.Message = "Bytecode ABORT_TRANSITION";
                    return res;

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }
        return res;
    }
};

} // namespace A2A
