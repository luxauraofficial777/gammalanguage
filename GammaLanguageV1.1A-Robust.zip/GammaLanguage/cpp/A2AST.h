#pragma once
#include <cstdint>
#include <array>
#include <string_view>
#include <cstring>
#include <cstddef>

namespace A2A {

// Fault code masks
enum class FaultCode : uint8_t {
    NONE                    = 0x00,
    SCHEMA_DRIFT            = 0xE0,
    MEMORY_LIMIT_EXCEEDED   = 0xE1,
    INSTRUCTION_BUDGET      = 0xE2,
    VECTOR_SIMILARITY_LOW   = 0xE3
};

// Opcode definitions matching Gamma Language v1.1A-Robust spec
enum class Opcode : uint8_t {
    NOP                 = 0x00,
    // v1.0 opcodes
    STATE_DECL          = 0x01,
    INVARIANT_GUARD     = 0x02,
    COLIBRI_PIN         = 0x03,
    COLIBRI_UNPIN       = 0x04,
    COLIBRI_SWAP        = 0x05,
    COLIBRI_HEARTBEAT   = 0x06,

    ASSIGN_SCALAR       = 0x0A,
    ASSIGN_STRING       = 0x0B,

    VECTOR_LOAD         = 0x10,
    VECTOR_QUERY        = 0x11,
    COSINE_SIM          = 0x12,

    CAVEMAN_SHRINK      = 0x20,
    GIGATOKEN_PACK      = 0x30,
    MCP_CALL            = 0x40,

    MATCH_BEGIN         = 0x50,
    MATCH_BRANCH        = 0x51,

    EMIT_SIGNAL         = 0xFE,
    ABORT_TRANSITION    = 0xFF,
    // v1.1A-Robust new opcodes
    TARGET_DECL         = 0x07,
    TARGET_DEFINE       = 0x08,
    SKILL_EQUIP         = 0x09,
    SKILL_UNLOAD        = 0x0C,
    PROFILE_SWAP        = 0x0D,
    HIVE_SELECT         = 0x15,
    ZHARK_QUERY         = 0x16,
    FUBBU_SYNC          = 0x17,
    LOCK_ACQUIRE        = 0x60,
    LOCK_RELEASE        = 0x61,
    BARRIER_WAIT        = 0x62,
    SYNC_WAIT           = 0x63,
    ON_ERROR_BLOCK      = 0x70,
    SHIFT_TARGET        = 0x71,
    RETRY               = 0x72,
    NATIVE_BRIDGE       = 0x80,
    // v1.1A-Robust Peak Performance opcodes
    QVEC_LOAD           = 0x18,   // PEAK-2: Load 8-bit quantized vector
    VEC_DELTA            = 0x19,   // PEAK-2: Differential vector update
    PREDICT_BLOCK        = 0x73,   // PEAK-3: Speculative pipeline branch
    SPEC_COMMIT          = 0x74,   // PEAK-3: Commit speculative buffer
    SPEC_ROLLBACK        = 0x75,   // PEAK-3: Rollback speculative buffer
    HW_INTERRUPT         = 0x90,   // PEAK-4: Hardware interrupt frame-sync
    EVICT_SLIDING        = 0x31    // PEAK-5: Sliding-window context eviction
};

enum class CavemanLevel : uint8_t {
    LITE = 0,
    FULL = 1,
    ULTRA = 2,
    WENYAN = 3
};

// PEAK-4: Hardware interrupt channels for frame-sync runtimes
enum class HWIntChannel : uint8_t {
    NONE        = 0x00,
    VBLANK      = 0x01,
    DMA_CH1     = 0x02,
    AUDIO_SWAP  = 0x03,
    RENDER_DONE = 0x04
};

// PEAK-3: Speculative execution buffer state
struct SpeculativeBuffer {
    bool Active{false};        // True inside a @PREDICT block
    bool Committed{false};     // True if speculative results were committed
    uint32_t StartPC{0};       // Arena index at @PREDICT entry
    uint32_t SavedRetryCount{0};
    uint8_t SavedTargetIndex{0};
    std::array<uint64_t, 4> SavedLck{};
    std::array<float, 8> SavedSig{};
};

// 64-byte aligned register bank to fit L1 cache lines perfectly
// v1.1A-Robust: 7 register banks (added HW, SKL, LCK)
// PEAK-2: Added QVec (8-bit quantized vectors, 75% bandwidth reduction)
struct alignas(64) RegisterBank {
    std::array<int64_t, 16> Reg{};                         // REG[0..15] 128 bytes
    std::array<uint64_t, 8> Hw{};                          // HW[0..7] system defs (GPU/VDP/MMIO)
    std::array<uint64_t, 4> Skl{};                         // SKL[0..3] skill pointers
    std::array<std::array<uint16_t, 1536>, 8> Vec{};        // #VEC[0..7] 24,576 bytes FP16 vector embeddings
    std::array<std::array<uint8_t, 1536>, 8> QVec{};        // PEAK-2: #QVEC[0..7] 12,288 bytes 8-bit quantized vectors
    std::array<float, 8> Sig{};                             // %SIG[0..7] 32 bytes Cross-modulation floats
    std::array<std::array<char, 2048>, 4> Ctx{};            // CTX[0..3] 8,192 bytes Gigatoken context buffers
    std::array<uint64_t, 4> Lck{};                          // LCK[0..3] mutex handles for multi-agent sync
    uint8_t ActiveExpertIndex{0};                           // Currently pinned Colibri expert
    float TurboQuantRamUtil{0.0f};                          // Latest RAM pressure reading
    uint8_t ActiveTargetIndex{0};                           // v1.1A: current target profile index
    uint8_t RetryCount{0};                                  // v1.1A: retry counter for @ON_ERROR
    uint8_t MaxRetries{2};                                  // v1.1A: max retries before abort
    // PEAK-4: Hardware interrupt state
    HWIntChannel PendingInt{HWIntChannel::NONE};            // Current pending hardware interrupt
    uint32_t FrameCount{0};                                 // Frame counter for frame-sync targets
    // PEAK-5: Sliding-window eviction metadata
    uint16_t EvictSpan{2048};                               // Eviction window span in tokens
    uint16_t EvictStride{512};                              // Eviction stride in tokens
    uint16_t CtxWritePos[4]{0, 0, 0, 0};                    // Ring-buffer write positions for CTX[0..3]
    // PEAK-3: Speculative buffer
    SpeculativeBuffer SpecBuf;
};

// 256-byte aligned AST node for cache line performance & zero-allocation execution
struct alignas(64) ASTNode {
    Opcode op{Opcode::NOP};
    uint8_t target_reg{0};
    uint8_t src_reg_a{0};
    uint8_t src_reg_b{0};
    CavemanLevel caveman_lvl{CavemanLevel::FULL};
    float scalar_imm{0.0f};
    int64_t int_imm{0};
    char payload_str[228]{};                                // Padded so sizeof(ASTNode) == 256 bytes

    void SetPayload(std::string_view sv) {
        size_t len = (sv.length() < sizeof(payload_str) - 1) ? sv.length() : (sizeof(payload_str) - 1);
        std::memcpy(payload_str, sv.data(), len);
        payload_str[len] = '\0';
    }
};

static_assert(sizeof(ASTNode) == 256, "ASTNode must be exactly 256 bytes for 64-byte alignment");
static_assert(sizeof(ASTNode) % 64 == 0, "ASTNode size must be a multiple of 64 bytes");

// Contiguous memory arena buffer for zero dynamic heap allocation during parsing
template <size_t MaxCapacity = 256>
struct ASTArena {
    std::array<ASTNode, MaxCapacity> Nodes{};
    size_t Count{0};

    bool Push(const ASTNode& node) {
        if (Count >= MaxCapacity) return false;
        Nodes[Count++] = node;
        return true;
    }

    void Clear() {
        Count = 0;
    }
};

// 64-byte aligned structure for AST Memoization (Cross-Module Caching)
struct alignas(64) AST_Memoizer {
    static constexpr size_t CACHE_SIZE = 1024;
    
    struct CacheEntry {
        uint64_t hash_key;
        const ASTNode* node_ptr;
    };
    
    std::array<CacheEntry, CACHE_SIZE> Entries{};
    
    uint64_t HashPayload(std::string_view sv) const {
        uint64_t hash = 5381;
        for (char c : sv) {
            hash = ((hash << 5) + hash) + c;
        }
        return hash;
    }
    
    void CacheNode(std::string_view payload, const ASTNode* node) {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        Entries[index] = {key, node};
    }
    
    const ASTNode* Lookup(std::string_view payload) const {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        if (Entries[index].hash_key == key && Entries[index].node_ptr) {
            return Entries[index].node_ptr;
        }
        return nullptr;
    }
};

// ===================================================================
// PEAK-1: A2A-B Binary Bytecode Format (32-bit packed instructions)
// ===================================================================
//
// While ASCII sigil syntax is ideal for LLM text generation, compiling
// incoming DSL streams into bit-packed arrays at the MCP boundary allows
// the C++ VM to execute via Direct Threaded Code jump tables — completely
// eliminating string lexing overhead on the hot path.
//
// Layout (32 bits):
//   [31:24]  Opcode (8 bits)  — maps 1:1 to enum class Opcode
//   [23:20]  Target Reg (4 bits) — register bank index
//   [19:16]  Src Reg A (4 bits)  — first source register
//   [15:12]  Src Reg B (4 bits)  — second source register
//   [11:8]   Flags (4 bits)      — CavemanLevel, HWIntChannel, etc.
//   [7:0]    Immediate (8 bits)  — small inline constant
//
// For larger immediates, a trailing uint32_t follows the instruction.

struct A2AB_Instruction {
    uint32_t packed;

    constexpr A2AB_Instruction() : packed(0) {}

    constexpr A2AB_Instruction(uint8_t op, uint8_t tgt, uint8_t srcA, uint8_t srcB,
                                uint8_t flags, uint8_t imm)
        : packed((uint32_t(op) << 24) | (uint32_t(tgt) << 20) |
                 (uint32_t(srcA) << 16) | (uint32_t(srcB) << 12) |
                 (uint32_t(flags) << 8) | uint32_t(imm)) {}

    constexpr uint8_t Opcode()     const { return (packed >> 24) & 0xFF; }
    constexpr uint8_t TargetReg()  const { return (packed >> 20) & 0x0F; }
    constexpr uint8_t SrcRegA()    const { return (packed >> 16) & 0x0F; }
    constexpr uint8_t SrcRegB()    const { return (packed >> 12) & 0x0F; }
    constexpr uint8_t Flags()      const { return (packed >> 8)  & 0x0F; }
    constexpr uint8_t Immediate()  const { return  packed        & 0xFF; }
};

static_assert(sizeof(A2AB_Instruction) == 4, "A2AB_Instruction must be exactly 4 bytes");

// Bytecode arena — contiguous array of 32-bit instructions
// Uses 64x less memory than ASTArena (4 bytes/instruction vs 256 bytes/node)
template <size_t MaxCapacity = 512>
struct BytecodeArena {
    std::array<A2AB_Instruction, MaxCapacity> Instrs{};
    size_t Count{0};

    bool Emit(const A2AB_Instruction& instr) {
        if (Count >= MaxCapacity) return false;
        Instrs[Count++] = instr;
        return true;
    }

    void Clear() { Count = 0; }
};

// AST → Bytecode compiler: converts 256-byte ASTNodes into 4-byte instructions
// Called once at the MCP boundary, then the hot path uses BytecodeVM::Execute
struct BytecodeCompiler {
    template <size_t N>
    static size_t Compile(const ASTArena<N>& ast, BytecodeArena<512>& bc) {
        bc.Clear();
        for (size_t i = 0; i < ast.Count; ++i) {
            const ASTNode& node = ast.Nodes[i];
            uint8_t flags = static_cast<uint8_t>(node.caveman_lvl) & 0x0F;
            A2AB_Instruction instr(
                static_cast<uint8_t>(node.op),
                node.target_reg & 0x0F,
                node.src_reg_a & 0x0F,
                node.src_reg_b & 0x0F,
                flags,
                0
            );
            if (!bc.Emit(instr)) break;
        }
        return bc.Count;
    }
};

} // namespace A2A
