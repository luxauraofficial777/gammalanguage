#pragma once
#include "A2AST.h"
#include <string_view>

namespace A2A {

class Lexer {
public:
    explicit Lexer(std::string_view stream);
    
    // Parses entire string stream into static arena without heap allocations
    template <size_t N>
    bool ParseIntoArena(ASTArena<N>& arena) {
        arena.Clear();
        while (m_cursor < m_stream.length()) {
            SkipWhitespaceAndComments();
            if (m_cursor >= m_stream.length()) break;

            char sigil = m_stream[m_cursor];
            ASTNode node{};

            if (sigil == '!') { // State Shift !STATE: 0x01 [NAME] or !SHIFT_TARGET: [NAME]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("SHIFT_TARGET") != std::string_view::npos) {
                    node.op = Opcode::SHIFT_TARGET;
                } else {
                    node.op = Opcode::STATE_DECL;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '@') { // Invariant Guard @INVARIANT:, @ON_ERROR:, or @PREDICT
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("ON_ERROR") != std::string_view::npos) {
                    node.op = Opcode::ON_ERROR_BLOCK;
                    // Read until closing brace
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') m_cursor++;
                    if (m_cursor < m_stream.length()) m_cursor++; // consume }
                } else if (line.find("PREDICT") != std::string_view::npos) {
                    node.op = Opcode::PREDICT_BLOCK;
                } else {
                    node.op = Opcode::INVARIANT_GUARD;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '&') { // Colibri Directives &PIN_EXPERT("name")
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("PIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_PIN;
                else if (line.find("UNPIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_UNPIN;
                else if (line.find("SWAP_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_SWAP;
                else node.op = Opcode::COLIBRI_HEARTBEAT;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '|') { // Target Context |TARGET: [NAME] or |TARGET_DEFINE: [NAME] { ... }
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("TARGET_DEFINE") != std::string_view::npos) {
                    node.op = Opcode::TARGET_DEFINE;
                    // Skip past the definition block { ... }
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') m_cursor++;
                    if (m_cursor < m_stream.length()) m_cursor++; // consume }
                    if (m_cursor < m_stream.length() && m_stream[m_cursor] == '\n') m_cursor++;
                } else {
                    node.op = Opcode::TARGET_DECL;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '+') { // Skill Equip +SKILL["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_EQUIP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '-') { // Skill Unload -SKILL["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_UNLOAD;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '*') { // Profile Swap *PROFILE["name"]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::PROFILE_SWAP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '=') { // Sync Guard =LOCK=, =UNLOCK=, =BARRIER=, =SYNC(
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("LOCK=") != std::string_view::npos && line.find("UNLOCK=") == std::string_view::npos)
                    node.op = Opcode::LOCK_ACQUIRE;
                else if (line.find("UNLOCK=") != std::string_view::npos)
                    node.op = Opcode::LOCK_RELEASE;
                else if (line.find("BARRIER=") != std::string_view::npos)
                    node.op = Opcode::BARRIER_WAIT;
                else if (line.find("SYNC(") != std::string_view::npos)
                    node.op = Opcode::SYNC_WAIT;
                else
                    node.op = Opcode::LOCK_ACQUIRE; // default
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '?') { // ZHARK Query ?ZHARK(...)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::ZHARK_QUERY;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (static_cast<unsigned char>(sigil) == 0xC2 && m_cursor + 1 < m_stream.length()
                     && static_cast<unsigned char>(m_stream[m_cursor + 1]) == 0xBF) {
                // FUBBU Sync ¿ (UTF-8: 0xC2 0xBF)
                m_cursor += 2; // Skip 2-byte UTF-8 sequence
                std::string_view line = ReadUntil(';');
                node.op = Opcode::FUBBU_SYNC;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '<') { // Native Bridge <NATIVE_BRIDGE: LANG>
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::NATIVE_BRIDGE;
                // Skip until </NATIVE_BRIDGE>
                while (m_cursor + 16 < m_stream.length()) {
                    if (m_stream[m_cursor] == '<' && m_stream[m_cursor+1] == '/') {
                        // Found closing tag
                        while (m_cursor < m_stream.length() && m_stream[m_cursor] != '\n') m_cursor++;
                        break;
                    }
                    m_cursor++;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '$') { // Exec Block $EXEC { ... }
                m_cursor++;
                ReadUntil('{');
            }
            else if (sigil == '#') { // Vector/Hive/Quantized ops: #VEC, #QVEC, #VEC_DELTA, #HIVE
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("HIVE") != std::string_view::npos) {
                    node.op = Opcode::HIVE_SELECT;
                } else if (line.find("QVEC") != std::string_view::npos && line.find("VEC_DELTA") == std::string_view::npos) {
                    node.op = Opcode::QVEC_LOAD;
                } else if (line.find("VEC_DELTA") != std::string_view::npos) {
                    node.op = Opcode::VEC_DELTA;
                } else if (line.find("LOAD_EMBEDDING") != std::string_view::npos) {
                    node.op = Opcode::VECTOR_LOAD;
                } else if (line.find("QUERY_VECTOR_DB") != std::string_view::npos) {
                    node.op = Opcode::VECTOR_QUERY;
                } else {
                    node.op = Opcode::VECTOR_LOAD;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '%') { // Signal Assignment or HW Interrupt: %SIG[0]=, %HW_INT(
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("HW_INT") != std::string_view::npos) {
                    node.op = Opcode::HW_INTERRUPT;
                } else {
                    node.op = Opcode::ASSIGN_SCALAR;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '~') { // MCP Pipe ~MCP("tool", payload)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::MCP_CALL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '^') { // Gigatoken Pack or Eviction: ^GIGATOKEN_PACK, ^EVICT_SLIDING
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("EVICT_SLIDING") != std::string_view::npos) {
                    node.op = Opcode::EVICT_SLIDING;
                } else {
                    node.op = Opcode::GIGATOKEN_PACK;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else {
                std::string_view word = ReadWord();
                if (word == "CTX[0]" || word.rfind("CTX", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    if (line.find("CAVEMAN_SHRINK") != std::string_view::npos) node.op = Opcode::CAVEMAN_SHRINK;
                    else node.op = Opcode::ASSIGN_STRING;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "REG[0]" || word.rfind("REG", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    if (line.find("COSINE_SIM") != std::string_view::npos) node.op = Opcode::COSINE_SIM;
                    else node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "HW[0]" || word.rfind("HW", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SKL[0]" || word.rfind("SKL", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "LCK[0]" || word.rfind("LCK", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "EMIT_SIGNAL") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::EMIT_SIGNAL;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "ABORT_TRANSITION") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ABORT_TRANSITION;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "MATCH") {
                    std::string_view line = ReadUntil('{');
                    node.op = Opcode::MATCH_BEGIN;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SPEC_COMMIT") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::SPEC_COMMIT;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "SPEC_ROLLBACK") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::SPEC_ROLLBACK;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "RETRY") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::RETRY;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else {
                    m_cursor++; // Consume character to advance
                }
            }
        }
        return true;
    }

private:
    void SkipWhitespaceAndComments();
    std::string_view ReadUntil(char delimiter);
    std::string_view ReadWord();
    
    std::string_view m_stream;
    size_t m_cursor{0};
};

} // namespace A2A
