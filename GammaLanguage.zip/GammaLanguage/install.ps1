# Gamma Language (v1.0) Automated Windows PowerShell Installer

Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host "         Gamma Language (Gamma-DSL v1.0) Installer" -ForegroundColor Cyan
Write-Host "==========================================================================" -ForegroundColor Cyan

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -Path $ScriptDir

# Step 1: Create binary bin directory
$BinDir = Join-Path -Path $ScriptDir -ChildPath "cpp\bin"
if (-not (Test-Path -Path $BinDir)) {
    New-Item -ItemType Directory -Path $BinDir | Out-Null
}

# Step 2: Compile C++ Engine
Write-Host "[1/3] Compiling C++ SIMD Vectorized Parser Engine..." -ForegroundColor Yellow

$CppDir = Join-Path -Path $ScriptDir -ChildPath "cpp"
Set-Location -Path $CppDir

$CompilerFound = $false

# Try MSVC / cl.exe if available
if (Get-Command "cl.exe" -ErrorAction SilentlyContinue) {
    Write-Host "    [+] Found MSVC (cl.exe). Compiling with /std:c++17 /O2..." -ForegroundColor Green
    cl.exe /std:c++17 /O2 /EHsc /Fe:bin\gamma_parser.exe test_a2a_parser.cpp A2ALexer.cpp A2AEvaluator.cpp
    if ($LASTEXITCODE -eq 0) { $CompilerFound = $true }
}
# Fallback to g++ if available
if (-not $CompilerFound -and (Get-Command "g++" -ErrorAction SilentlyContinue)) {
    Write-Host "    [+] Found g++. Compiling with -O3 -std=c++17..." -ForegroundColor Green
    g++ -O3 -std=c++17 test_a2a_parser.cpp A2ALexer.cpp A2AEvaluator.cpp -o bin\gamma_parser.exe
    if ($LASTEXITCODE -eq 0) { $CompilerFound = $true }
}

Set-Location -Path $ScriptDir

if ($CompilerFound -and (Test-Path -Path "cpp\bin\gamma_parser.exe")) {
    Write-Host "    [PASS] C++ Native Binary compiled: cpp\bin\gamma_parser.exe" -ForegroundColor Green
} else {
    Write-Host "    [WARN] No C++ compiler found or build deferred. (Precompiled/Source ready in cpp/)" -ForegroundColor DarkYellow
}

# Step 3: Test C++ Native Parser Execution
if (Test-Path -Path "cpp\bin\gamma_parser.exe") {
    Write-Host "[2/3] Running Zero-Allocation C++ Test & Throughput Benchmark..." -ForegroundColor Yellow
    & "cpp\bin\gamma_parser.exe"
} else {
    Write-Host "[2/3] Skipping C++ Binary Test (No binary built)." -ForegroundColor DarkYellow
}

# Step 4: Verify Python CLI Bridge
Write-Host "[3/3] Testing Python Gamma Language Bridge..." -ForegroundColor Yellow
python python\gamma_cli.py --test

Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host " [SUCCESS] Gamma Language (v1.0) Installation & Verification Complete!" -ForegroundColor Green
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host " Location: $ScriptDir" -ForegroundColor White
Write-Host " Spec:     $ScriptDir\spec\gamma_dsl_spec.md" -ForegroundColor White
Write-Host " C++ Src:  $ScriptDir\cpp\" -ForegroundColor White
Write-Host " Python:   $ScriptDir\python\" -ForegroundColor White
Write-Host " Examples: $ScriptDir\examples\" -ForegroundColor White
Write-Host " Run CLI:  python python\gamma_cli.py --test" -ForegroundColor White
Write-Host "==========================================================================" -ForegroundColor Cyan
