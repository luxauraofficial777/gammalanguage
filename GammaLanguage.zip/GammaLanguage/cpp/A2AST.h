#pragma once
#include <cstdint>
#include <array>
#include <string_view>
#include <cstring>
#include <cstddef>

namespace A2A {

// Fault code masks
enum class FaultCode : uint8_t {
    NONE                    = 0x00,
    SCHEMA_DRIFT            = 0xE0,
    MEMORY_LIMIT_EXCEEDED   = 0xE1,
    INSTRUCTION_BUDGET      = 0xE2,
    VECTOR_SIMILARITY_LOW   = 0xE3
};

// Opcode definitions matching Gamma Language v1.0 spec
enum class Opcode : uint8_t {
    NOP                 = 0x00,
    STATE_DECL          = 0x01,
    INVARIANT_GUARD     = 0x02,
    COLIBRI_PIN         = 0x03,
    COLIBRI_UNPIN       = 0x04,
    COLIBRI_SWAP        = 0x05,
    COLIBRI_HEARTBEAT   = 0x06,
    
    ASSIGN_SCALAR       = 0x0A,
    ASSIGN_STRING       = 0x0B,
    
    VECTOR_LOAD         = 0x10,
    VECTOR_QUERY        = 0x11,
    COSINE_SIM          = 0x12,
    
    CAVEMAN_SHRINK      = 0x20,
    GIGATOKEN_PACK      = 0x30,
    MCP_CALL            = 0x40,
    
    MATCH_BEGIN         = 0x50,
    MATCH_BRANCH        = 0x51,
    
    EMIT_SIGNAL         = 0xFE,
    ABORT_TRANSITION    = 0xFF
};

enum class CavemanLevel : uint8_t {
    LITE = 0,
    FULL = 1,
    ULTRA = 2,
    WENYAN = 3
};

// 64-byte aligned register bank to fit L1 cache lines perfectly
struct alignas(64) RegisterBank {
    std::array<int64_t, 16> Reg{};                         // 128 bytes
    std::array<std::array<uint16_t, 1536>, 8> Vec{};        // 24,576 bytes FP16 vector embeddings
    std::array<float, 8> Sig{};                             // 32 bytes Cross-modulation floats
    std::array<std::array<char, 2048>, 4> Ctx{};            // 8,192 bytes Gigatoken context buffers
    uint8_t ActiveExpertIndex{0};                           // Currently pinned Colibri expert
    float TurboQuantRamUtil{0.0f};                          // Latest RAM pressure reading
};

// 256-byte aligned AST node for cache line performance & zero-allocation execution
struct alignas(64) ASTNode {
    Opcode op{Opcode::NOP};
    uint8_t target_reg{0};
    uint8_t src_reg_a{0};
    uint8_t src_reg_b{0};
    CavemanLevel caveman_lvl{CavemanLevel::FULL};
    float scalar_imm{0.0f};
    int64_t int_imm{0};
    char payload_str[228]{};                                // Padded so sizeof(ASTNode) == 256 bytes

    void SetPayload(std::string_view sv) {
        size_t len = (sv.length() < sizeof(payload_str) - 1) ? sv.length() : (sizeof(payload_str) - 1);
        std::memcpy(payload_str, sv.data(), len);
        payload_str[len] = '\0';
    }
};

static_assert(sizeof(ASTNode) == 256, "ASTNode must be exactly 256 bytes for 64-byte alignment");
static_assert(sizeof(ASTNode) % 64 == 0, "ASTNode size must be a multiple of 64 bytes");

// Contiguous memory arena buffer for zero dynamic heap allocation during parsing
template <size_t MaxCapacity = 256>
struct ASTArena {
    std::array<ASTNode, MaxCapacity> Nodes{};
    size_t Count{0};

    bool Push(const ASTNode& node) {
        if (Count >= MaxCapacity) return false;
        Nodes[Count++] = node;
        return true;
    }

    void Clear() {
        Count = 0;
    }
};

// 64-byte aligned structure for AST Memoization (Cross-Module Caching)
struct alignas(64) AST_Memoizer {
    static constexpr size_t CACHE_SIZE = 1024;
    
    struct CacheEntry {
        uint64_t hash_key;
        const ASTNode* node_ptr;
    };
    
    std::array<CacheEntry, CACHE_SIZE> Entries{};
    
    uint64_t HashPayload(std::string_view sv) const {
        uint64_t hash = 5381;
        for (char c : sv) {
            hash = ((hash << 5) + hash) + c;
        }
        return hash;
    }
    
    void CacheNode(std::string_view payload, const ASTNode* node) {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        Entries[index] = {key, node};
    }
    
    const ASTNode* Lookup(std::string_view payload) const {
        uint64_t key = HashPayload(payload);
        size_t index = key % CACHE_SIZE;
        if (Entries[index].hash_key == key && Entries[index].node_ptr) {
            return Entries[index].node_ptr;
        }
        return nullptr;
    }
};

} // namespace A2A
