#include "A2ALexer.h"
#include "A2AEvaluator.h"
#include <iostream>
#include <chrono>
#include <cassert>

// Global heap allocation tracker for zero-allocation verification
static size_t g_heap_allocations = 0;

void* operator new(size_t size) {
    g_heap_allocations++;
    return std::malloc(size);
}

void operator delete(void* ptr) noexcept {
    std::free(ptr);
}

void operator delete(void* ptr, size_t) noexcept {
    std::free(ptr);
}

int main() {
    std::cout << "[+] Verifying Cache Alignment Constraints..." << std::endl;
    std::cout << "    sizeof(ASTNode) = " << sizeof(A2A::ASTNode) << " (Must be 256)" << std::endl;
    std::cout << "    alignof(RegisterBank) = " << alignof(A2A::RegisterBank) << " (Must be 64)" << std::endl;

    static_assert(sizeof(A2A::ASTNode) == 256, "ASTNode size mismatch!");
    static_assert(sizeof(A2A::ASTNode) % 64 == 0, "ASTNode alignment mismatch!");
    static_assert(alignof(A2A::RegisterBank) == 64, "RegisterBank 64-byte alignment mismatch!");

    const char* sample_script = R"(
!STATE: 0x0A [LIMINAL_VECTOR_CROSSMOD]
@INVARIANT: TURBOQUANT_RAM_UTIL <= 0.65
&PIN_EXPERT("lux-architect")
&HEARTBEAT("30S_PULSE")

$EXEC {
  CTX[0] = CAVEMAN_SHRINK("Analyze render pipeline for isometric depth dither bugs", LEVEL=FULL);
  #VEC[0] = LOAD_EMBEDDING(CTX[0]);
  #VEC[1] = QUERY_VECTOR_DB(#VEC[0], TOP_K=5);
  
  REG[0] = COSINE_SIM(#VEC[0], #VEC[1]);
  ^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048);

  EMIT_SIGNAL(0xFF, "HIGH_SIMILARITY_EXECUTE");
}
)";

    // Reset heap allocation tracker before hotpath execution
    g_heap_allocations = 0;

    std::cout << "\n[+] Parsing Gamma Language Stream (Static Arena)..." << std::endl;
    A2A::ASTArena<256> arena;
    A2A::Lexer lexer(sample_script);
    
    bool parse_ok = lexer.ParseIntoArena(arena);
    assert(parse_ok);

    std::cout << "[+] Parsed AST Nodes Count: " << arena.Count << std::endl;

    std::cout << "[+] Executing Gamma Evaluation Engine (Zero-Allocation Hotpath)..." << std::endl;
    alignas(64) A2A::RegisterBank registers{};
    registers.TurboQuantRamUtil = 0.45f;

    A2A::Evaluator evaluator(1000); // 1000 cycle ceiling
    auto result = evaluator.Execute(arena, registers);

    // Assert zero heap allocations during parsing and execution
    std::cout << "[+] Dynamic Heap Allocations During Hotpath: " << g_heap_allocations << std::endl;
    if (g_heap_allocations == 0) {
        std::cout << "    [PASS] ZERO-HEAP ALLOCATION GUARANTEE VERIFIED." << std::endl;
    } else {
        std::cout << "    [WARN] Dynamic heap allocations detected: " << g_heap_allocations << std::endl;
    }

    std::cout << "\n[+] Benchmark Parsing & SIMD Evaluation Throughput..." << std::endl;
    constexpr int ITERATIONS = 100000;
    auto t_start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < ITERATIONS; ++i) {
        A2A::Lexer bench_lexer(sample_script);
        bench_lexer.ParseIntoArena(arena);
        evaluator.Execute(arena, registers);
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double total_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    double ops_per_sec = (ITERATIONS * 1000.0) / total_ms;
    double mb_per_sec = (ITERATIONS * std::strlen(sample_script)) / (total_ms * 1000.0);

    std::cout << "    Iterations: " << ITERATIONS << " in " << total_ms << " ms" << std::endl;
    std::cout << "    Throughput: " << ops_per_sec << " evaluations/sec (" << mb_per_sec << " MB/sec)" << std::endl;

    std::cout << "\n[+] Execution Status: " << (result.Success ? "SUCCESS" : "FAILED") << std::endl;
    std::cout << "    Fault Code: 0x" << std::hex << static_cast<int>(result.Fault) << std::dec << std::endl;
    std::cout << "    Result Message: " << result.Message << std::endl;

    return (result.Success && g_heap_allocations == 0) ? 0 : 1;
}
