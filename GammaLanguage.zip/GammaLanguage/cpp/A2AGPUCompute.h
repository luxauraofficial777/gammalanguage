#pragma once
#include "A2AST.h"
#include <cstdint>
#include <vector>

namespace A2A {

// GPU Device context
struct GPUDevice {
    bool is_initialized{false};
    void* vk_instance{nullptr};
    void* vk_physical_device{nullptr};
    void* vk_device{nullptr};
    void* vk_compute_queue{nullptr};
    
    // Shader resources
    void* vk_pipeline{nullptr};
    void* vk_pipeline_layout{nullptr};
};

class GPUComputeEngine {
public:
    GPUComputeEngine();
    ~GPUComputeEngine();

    bool InitializeVulkan();
    void Cleanup();

    // Executes Cosine Similarity on the GPU using Compute Shaders
    // Calculates sim(vecA, vecB) for all pairs if batched
    float ComputeCosineSim(const std::array<uint16_t, 1536>& vecA, const std::array<uint16_t, 1536>& vecB);

private:
    GPUDevice m_device;
};

// Global helper
GPUDevice GetOptimalGPUDevice();

} // namespace A2A
