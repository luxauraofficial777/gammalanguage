#pragma once
#include "A2AST.h"
#include <string_view>

namespace A2A {

class Lexer {
public:
    explicit Lexer(std::string_view stream);
    
    // Parses entire string stream into static arena without heap allocations
    template <size_t N>
    bool ParseIntoArena(ASTArena<N>& arena) {
        arena.Clear();
        while (m_cursor < m_stream.length()) {
            SkipWhitespaceAndComments();
            if (m_cursor >= m_stream.length()) break;

            char sigil = m_stream[m_cursor];
            ASTNode node{};

            if (sigil == '!') { // State Shift !STATE: 0x01 [NAME]
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::STATE_DECL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '@') { // Invariant Guard @INVARIANT: condition
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::INVARIANT_GUARD;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '&') { // Colibri Directives &PIN_EXPERT("name")
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("PIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_PIN;
                else if (line.find("UNPIN_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_UNPIN;
                else if (line.find("SWAP_EXPERT") != std::string_view::npos) node.op = Opcode::COLIBRI_SWAP;
                else node.op = Opcode::COLIBRI_HEARTBEAT;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '$') { // Exec Block $EXEC { ... }
                m_cursor++;
                ReadUntil('{');
            }
            else if (sigil == '#') { // Vector Operation #VEC[0] = ...
                m_cursor++;
                std::string_view line = ReadUntil(';');
                if (line.find("LOAD_EMBEDDING") != std::string_view::npos) node.op = Opcode::VECTOR_LOAD;
                else if (line.find("QUERY_VECTOR_DB") != std::string_view::npos) node.op = Opcode::VECTOR_QUERY;
                else node.op = Opcode::VECTOR_LOAD;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '%') { // Signal Assignment %SIG[0] = 0.95
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::ASSIGN_SCALAR;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '~') { // MCP Pipe ~MCP("tool", payload)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::MCP_CALL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '^') { // Gigatoken Pack ^GIGATOKEN_PACK(...)
                m_cursor++;
                std::string_view line = ReadUntil(';');
                node.op = Opcode::GIGATOKEN_PACK;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else {
                std::string_view word = ReadWord();
                if (word == "CTX[0]" || word.rfind("CTX", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    if (line.find("CAVEMAN_SHRINK") != std::string_view::npos) node.op = Opcode::CAVEMAN_SHRINK;
                    else node.op = Opcode::ASSIGN_STRING;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "REG[0]" || word.rfind("REG", 0) == 0) {
                    std::string_view line = ReadUntil(';');
                    if (line.find("COSINE_SIM") != std::string_view::npos) node.op = Opcode::COSINE_SIM;
                    else node.op = Opcode::ASSIGN_SCALAR;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "EMIT_SIGNAL") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::EMIT_SIGNAL;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "ABORT_TRANSITION") {
                    std::string_view line = ReadUntil(';');
                    node.op = Opcode::ABORT_TRANSITION;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else if (word == "MATCH") {
                    std::string_view line = ReadUntil('{');
                    node.op = Opcode::MATCH_BEGIN;
                    node.SetPayload(line);
                    if (!arena.Push(node)) return false;
                }
                else {
                    m_cursor++; // Consume character to advance
                }
            }
        }
        return true;
    }

private:
    void SkipWhitespaceAndComments();
    std::string_view ReadUntil(char delimiter);
    std::string_view ReadWord();
    
    std::string_view m_stream;
    size_t m_cursor{0};
};

} // namespace A2A
