#pragma once
#include "A2AST.h"
#include "A2AGPUCompute.h"
#include <string>

namespace A2A {

struct ExecutionResult {
    bool Success{true};
    FaultCode Fault{FaultCode::NONE};
    uint8_t ExitCode{0};
    std::string Message{"OK"};
    uint32_t InvariantsChecked{0};
    uint32_t InstructionsExecuted{0};
};

class Evaluator {
public:
    explicit Evaluator(uint32_t max_cycles = 1000) : m_max_cycles(max_cycles) {}

    void SetComputeDevice(const GPUDevice& device) {
        m_gpu.InitializeVulkan();
    }

    template <size_t N>
    ExecutionResult Execute(const ASTArena<N>& arena, RegisterBank& registers) {
        ExecutionResult res{};

        for (size_t i = 0; i < arena.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.ExitCode = static_cast<uint8_t>(FaultCode::INSTRUCTION_BUDGET);
                res.Message = "Instruction cycle budget limit exceeded";
                return res;
            }

            const ASTNode& node = arena.Nodes[i];

            switch (node.op) {
                case Opcode::STATE_DECL:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::INVARIANT_GUARD:
                    res.InvariantsChecked++;
                    if (!EvaluateInvariant(node, registers)) {
                        res.Success = false;
                        res.Fault = FaultCode::MEMORY_LIMIT_EXCEEDED;
                        res.ExitCode = static_cast<uint8_t>(FaultCode::MEMORY_LIMIT_EXCEEDED);
                        res.Message = "Invariant violation: TurboQuant RAM threshold exceeded (0xE1)";
                        return res;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::COLIBRI_PIN:
                    registers.ActiveExpertIndex = 1; // Pinned
                    res.InstructionsExecuted++;
                    break;

                case Opcode::CAVEMAN_SHRINK: {
                    const char* caveman_text = "New ref each render. Wrap in useMemo.";
                    size_t len = std::strlen(caveman_text);
                    std::memcpy(registers.Ctx[0].data(), caveman_text, len + 1);
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::COSINE_SIM:
                    // PRO OPTIMIZATION: GPU Offload
                    registers.Reg[0] = static_cast<int64_t>(m_gpu.ComputeCosineSim(registers.Vec[0], registers.Vec[1]) * 1000.0f);
                    res.InstructionsExecuted++;
                    break;

                case Opcode::EMIT_SIGNAL:
                    res.InstructionsExecuted++;
                    res.Message = "EMIT_SIGNAL: " + std::string(node.payload_str);
                    break;

                case Opcode::ABORT_TRANSITION:
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.ExitCode = static_cast<uint8_t>(FaultCode::SCHEMA_DRIFT);
                    res.Message = "ABORT_TRANSITION: " + std::string(node.payload_str);
                    return res;

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }

        return res;
    }

private:
    bool EvaluateInvariant(const ASTNode& node, RegisterBank& registers);
    float ComputeCosineSimSIMD(const std::array<uint16_t, 1536>& v1, const std::array<uint16_t, 1536>& v2);
    
    uint32_t m_max_cycles{1000};
    GPUComputeEngine m_gpu;
    AST_Memoizer m_memoizer;
};

} // namespace A2A
