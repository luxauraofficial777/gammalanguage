import sys
import os
import json
from gamma_bridge import GammaBridge

def main():
    bridge = GammaBridge()
    args = sys.argv[1:]

    sample_script = R"""
!STATE: 0x0A [LIMINAL_VECTOR_CROSSMOD]
@INVARIANT: TURBOQUANT_RAM_UTIL <= 0.65
&PIN_EXPERT("lux-architect")
&HEARTBEAT("30S_PULSE")

$EXEC {
  CTX[0] = CAVEMAN_SHRINK("Analyze render pipeline for isometric depth dither bugs", LEVEL=FULL);
  #VEC[0] = LOAD_EMBEDDING(CTX[0]);
  #VEC[1] = QUERY_VECTOR_DB(#VEC[0], TOP_K=5);
  
  REG[0] = COSINE_SIM(#VEC[0], #VEC[1]);
  ^GIGATOKEN_PACK(CTX[0], MAX_TOKENS=2048);

  EMIT_SIGNAL(0xFF, "HIGH_SIMILARITY_EXECUTE");
}
"""

    if "--script" in args:
        idx = args.index("--script")
        if idx + 1 < len(args):
            with open(args[idx + 1], "r", encoding="utf-8") as f:
                sample_script = f.read()

    result = bridge.compile_gamma(sample_script)

    if "--json" in args or "--agent" in args:
        print(json.dumps(result, indent=2))
    else:
        print("\n[ Gamma Language CLI v1.0 ]")
        print(f"[*] State ID: {result['state_id']}")
        print(f"[*] Invariants Checked: {result['invariants_checked']}")
        print(f"[*] AST Nodes Compiled: {result['ast_node_count']}")
        print(f"[*] Colibri Directives: {result['colibri_directives']}")
        print(f"[*] TurboQuant Status: {result['turboquant_status']['status']} ({result['turboquant_status']['mode']})")
        print(f"[*] Estimated Token Savings: {result['estimated_token_savings']}")
        print("[+] Gamma Script Compiled & Validated Successfully.\n")

if __name__ == "__main__":
    main()
